#ifndef CARRAYLIST_H
#define CARRAYLIST_H
#include <stdexcept>
#include "carta.h"
#include <iostream>

template <class A> class CArrayList
{
    public:
        CArrayList();
        CArrayList(int pMax);
        A getValue();
        int getPos();
        int getSize();
        void goToStart();
        void goToEnd();
        void goToPos(int pos);
        void next();
        void previous();
        void append(A pElement);
        void insertar(A pElement);
        A remove();
        void printList();
        ~CArrayList();
        A* elements;

    protected:
        int size;
        int max;
        int pos;


};
#endif // CARRAYLIST_H
