#ifndef PANTALLA_H
#define PANTALLA_H


class Pantalla
{
public:
    Pantalla();
};

#endif // PANTALLA_H
