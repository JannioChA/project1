#include "boton.h"
#include <QDebug>
#include "controladora.h"
#include <iostream>
#include <string>

using namespace std;

Boton::Boton(QString Name, QString Url, int pos1, int pos2)
{
    setPixmap(Url);
    textBoton = new QGraphicsTextItem(Name,this);
    this->setPos(pos1,pos2);
    this->imagen = Url;
    setAcceptHoverEvents(true);
}
Boton::Boton(QString Url, int pos1, int pos2)//Recibe la URL de la imagen y su posición en la escena
{
    setPixmap(Url);
    textBoton = new QGraphicsTextItem("",this);
    this->setPos(pos1,pos2);
    this->imagen = Url;


    setAcceptHoverEvents(true);
}
void Boton::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
   emit clicked();

}
void Boton::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    this->setScale(1.02); // Hace la carta un poco más grande cuando el mouse pasa por encima de ésta
}
void Boton::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    this->setScale(1.0);// Devuelve la carta a su tamaño normal cuando el mouse la abandona
}
void Boton::setImagen(QString nuevaImagen)//Permite añadirle otra imagen a una instancia ya creada
{
    this->setPixmap(nuevaImagen);
    this->imagen = nuevaImagen;
}
QString Boton::getImagen()
{
    return this->imagen;
}
