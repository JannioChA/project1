#include "carta.h"

Carta::Carta(QString nombre)
{
    this->nombre = nombre;
    this->fichaPuesta = 0;
    this->perteneceSecuencia=false;
}
int Carta::getFichaPuesta()
{
    return this->fichaPuesta;
}
QString Carta::getNombre()
{
    return this->nombre;
}
bool Carta::getPerteneceSecuencia()
{
    return this->perteneceSecuencia;
}
void Carta::setPerteneceSecuencia(bool valor)
{
    this->perteneceSecuencia=valor;
}
void Carta::setFichaPuesta(int valor)
{
    this->fichaPuesta = valor;
}
void Carta::setNombre(QString nombre)
{
    this->nombre = nombre;
}


