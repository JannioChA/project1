#include "controladora.h"
#include "imagen.h"
#include "boton.h"
#include "carta.h"
#include "arraylist.h"
#include "arraylistm.h"


Controladora::Controladora()
{
    Scena();
    //CargarImagen();
    Boton *jugador2 = new Boton("hola", ":/img/botonJugador.png",100,400);
    connect(jugador2, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(jugador2);

    Boton *jugador3 = new Boton("hola", ":/img/botonJugador.png",500,400);
    connect(jugador3, SIGNAL(clicked()), this, SLOT(clean()));
    scene->addItem(jugador3);


    Boton *jugador4 = new Boton("hola", ":/img/botonJugador.png",900,400);
    connect(jugador4, SIGNAL(clicked()), this, SLOT(clean()));
    scene->addItem(jugador4);

    ArrayList<Carta*> cartas;
    cartas.append(new Carta (":/img/4esquinas.png"));
    cartas.append(new Carta (":/img/ace_of_clubs.png"));
    cartas.append(new Carta (":/img/king_of_clubs2.png"));
    cartas.append(new Carta (":/img/queen_of_clubs.png"));
    cartas.append(new Carta (":/img/10_of_clubs.png"));
    cartas.append(new Carta (":/img/9_of_clubs.png"));
    cartas.append(new Carta (":/img/8_of_clubs.png"));
    cartas.append(new Carta (":/img/7_of_clubs.png"));
    cartas.append(new Carta (":/img/6_of_clubs.png"));
    cartas.append(new Carta (":/img/4esquinas.png"));
    cartas.append(new Carta (":/img/ace_of_diamonts.png"));
    cartas.append(new Carta (":/img/7_of_spades.png"));
    cartas.append(new Carta (":/img/8_of_spades.png"));
    cartas.append(new Carta (":/img/9_of_spades.png"));
    cartas.append(new Carta (":/img/10_of_spades.png"));
    cartas.append(new Carta (":/img/queen_of_spades.png"));
    cartas.append(new Carta (":/img/king_of_spades.png"));
    cartas.append(new Carta (":/img/ace_of_spades.png"));
    cartas.append(new Carta (":/img/5_of_clubs.png"));
    cartas.append(new Carta (":/img/2_of_spades.png"));
    cartas.append(new Carta (":/img/king_of_diamonts.png"));
    cartas.append(new Carta (":/img/6_of_spades.png"));
    cartas.append(new Carta (":/img/10_of_clubs.png"));
    cartas.append(new Carta (":/img/9_of_clubs.png"));
    cartas.append(new Carta (":/img/8_of_clubs.png"));
    cartas.append(new Carta (":/img/7_of_clubs.png"));
    cartas.append(new Carta (":/img/6_of_clubs.png"));
    cartas.append(new Carta (":/img/2_of_diamonts.png"));
    cartas.append(new Carta (":/img/4_of_clubs.png"));
    cartas.append(new Carta (":/img/3_of_spades.png"));
    cartas.append(new Carta (":/img/queen_of_diamonts.png"));
    cartas.append(new Carta (":/img/5_of_spades.png"));
    cartas.append(new Carta (":/img/queen_of_clubs.png"));
    cartas.append(new Carta (":/img/8_of_hearts.png"));
    cartas.append(new Carta (":/img/7_of_hearts.png"));
    cartas.append(new Carta (":/img/6_of_hearts.png"));
    cartas.append(new Carta (":/img/5_of_clubs.png"));
    cartas.append(new Carta (":/img/3_of_diamonts.png"));
    cartas.append(new Carta (":/img/3_of_clubs.png"));
    cartas.append(new Carta (":/img/4_of_spades.png"));
    cartas.append(new Carta (":/img/10_of_diamonts.png"));
    cartas.append(new Carta (":/img/4_of_spades.png"));
    cartas.append(new Carta (":/img/king_of_clubs.png"));
    cartas.append(new Carta (":/img/9_of_hearts.png"));
    cartas.append(new Carta (":/img/2_of_hearts.png"));
    cartas.append(new Carta (":/img/5_of_hearts.png"));
    cartas.append(new Carta (":/img/4_of_clubs.png"));
    cartas.append(new Carta (":/img/4_of_diamonts.png"));
    cartas.append(new Carta (":/img/2_of_clubs.png"));
    cartas.append(new Carta (":/img/5_of_spades.png"));

    cartas.append(new Carta (":/img/9_of_diamonds.png"));
    cartas.append(new Carta (":/img/3_of_spades.png"));
    cartas.append(new Carta (":/img/ace_of_clubs.png"));
    cartas.append(new Carta (":/img/10_of_hearts.png"));
    cartas.append(new Carta (":/img/3_of_hearts.png"));
    cartas.append(new Carta (":/img/4_of_hearts.png"));
    cartas.append(new Carta (":/img/3_of_clubs.png"));
    cartas.append(new Carta (":/img/5_of_diamonds.png"));
    cartas.append(new Carta (":/img/ace_of_hearts.png"));
    cartas.append(new Carta (":/img/6_of_spades.png"));
    cartas.append(new Carta (":/img/8_of_diamonds.png"));
    cartas.append(new Carta (":/img/2_of_spades.png"));
    cartas.append(new Carta (":/img/ace_of_diamonds.png"));
    cartas.append(new Carta (":/img/queen_of_hearts.png"));
    cartas.append(new Carta (":/img/king_of_hearts.png"));
    cartas.append(new Carta (":/img/ace_of_hearts.png"));
    cartas.append(new Carta (":/img/2_of_clubs.png"));
    cartas.append(new Carta (":/img/6_of_diamonds.png"));
    cartas.append(new Carta (":/img/king_of_hearts.png"));
    cartas.append(new Carta (":/img/7_of_spades.png"));
    cartas.append(new Carta (":/img/7_of_diamonds.png"));
    cartas.append(new Carta (":/img/2_of_hearts.png"));
    cartas.append(new Carta (":/img/king_of_diamonds.png"));
    cartas.append(new Carta (":/img/queen_of_diamonds.png"));
    cartas.append(new Carta (":/img/10_of_diamonds.png"));
    cartas.append(new Carta (":/img/9_of_diamonds.png"));
    cartas.append(new Carta (":/img/8_of_diamonds.png"));
    cartas.append(new Carta (":/img/7_of_diamonds.png"));
    cartas.append(new Carta (":/img/queen_of_hearts.png"));
    cartas.append(new Carta (":/img/8_of_spades.png"));
    cartas.append(new Carta (":/img/6_of_diamonds.png"));
    cartas.append(new Carta (":/img/3_of_hearts.png"));
    cartas.append(new Carta (":/img/4_of_hearts.png"));
    cartas.append(new Carta (":/img/5_of_hearts.png"));
    cartas.append(new Carta (":/img/6_of_hearts.png"));
    cartas.append(new Carta (":/img/7_of_hearts.png"));
    cartas.append(new Carta (":/img/8_of_hearts.png"));
    cartas.append(new Carta (":/img/9_of_hearts.png"));
    cartas.append(new Carta (":/img/10_of_hearts.png"));
    cartas.append(new Carta (":/img/9_of_spades.png"));
    cartas.append(new Carta (":/img/4esquinas.png"));
    cartas.append(new Carta (":/img/5_of_diamonds.png"));
    cartas.append(new Carta (":/img/4_of_diamonds.png"));
    cartas.append(new Carta (":/img/3_of_diamonds.png"));
    cartas.append(new Carta (":/img/2_of_diamonds.png"));
    cartas.append(new Carta (":/img/ace_of_spades.png"));
    cartas.append(new Carta (":/img/king_of_spades.png"));
    cartas.append(new Carta (":/img/queen_of_spades.png"));
    cartas.append(new Carta (":/img/10_of_spades.png"));
    cartas.append(new Carta (":/img/4esquinas.png"));



    for(int j=20;j<720;j=j+70){
                for(int i=200;i<1210;i=i+101){
                    CargarImagen(i,j);
                }
            }

    //x->//hide();//Esconde las cosas
}
////////////////////////////////Metodos Generales////////////////////////////////////////////////////////////////////
void Controladora::Scena()
{
    //Crea un escenario
    scene = new QGraphicsScene();
    scene->setSceneRect(0,0,1470,950);
    scene->setBackgroundBrush(Qt::blue);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setFixedSize(1470,950);
    scene->setBackgroundBrush(QBrush(QImage(":/img/f.png"))); //Cambia el fondo de la scena
    setScene(scene);
}
void Controladora::CargarImagen(int i, int j)
{
    //Crea una imagen
    Imagen *imagen = new Imagen(":/img/2_of_hearts.png");
    imagen->setPos(i,j);
    //imagen->setScale(0);
    //imagen->setRotation(0);
    scene->addItem(imagen);
    //scene->removeItem(imagen);//remueve el elemento
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////Metodos SLOT/////////////////////////////////////////////////////////////////////////////////
void Controladora::clean()
{
    //Limpia la scena
    scene->clear();
}

void Controladora::IniciarJuego()
{
    scene->clear();
    // Aqui se llaman los METODOS para crear cartas, el maso, los jugadores
    // y poner a ejecutar el juego o iniciarlo junto con todos los componenes que tiene
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*void Controladora::agregarTablero()
{
    for(int j=20;j<720;j=j+70){
            for(int i=200;i<1210;i=i+101){
                CargarImagen(i,j);
            }
        }
}*/
