#include "arraylistm.h"

using namespace std;

template <class A>
ArrayListM<A>::ArrayListM()
{
    max=1024;
    size=0;
    pos=0;
    elements2=new A[max];
}

template <class A>
ArrayListM<A>::ArrayListM(int pMax)
{
    max=pMax;
    size=0;
    pos=0;
    elements2=new A[pMax];
}

template <class A>
A ArrayListM<A>::getValue(){
    if(pos<0 || pos>size){
        throw runtime_error("Index out of bounds");
    }
    return elements2[pos-1];
}

template <class A>
int ArrayListM<A>::getPos(){
    return pos;
}

template <class A>
int ArrayListM<A>::getSize(){
    return size;
}

template <class A>
void ArrayListM<A>::goToStart(){
    pos=0;
}

template <class A>
void ArrayListM<A>::goToEnd(){
    pos=size+1;
}

template <class A>
void ArrayListM<A>::goToPos(int pos){
    if(pos>size || pos<0){
        throw runtime_error("Index out of bounds");
    }
    pos=pos;
}

template <class A>
void ArrayListM<A>::next(){
    if(pos>size){
        throw runtime_error("Index out of bounds");
    }
    pos++;
}

template <class A>
void ArrayListM<A>::previous(){
    if(pos<=0){
        throw runtime_error("Index out of bounds");
    }
    pos--;
}

template <class A>
void ArrayListM<A>::append(A pElement){
    if(size==max){
        throw runtime_error("List Full");
    }
    elements2[size]=pElement;
    size++;
}

//Posicionar a Pos en la posicion a insertar
template <class A>
void ArrayListM<A>::insertar(A pElement){
    for(int i=size;i>pos-1;i--){
        elements2[i]=elements2[i-1];
    }
    elements2[pos-1]=pElement;
    size++;
}

//Pos apuntando al elemento a eliminar
template <class A>
A ArrayListM<A>::remove(){
    if(size==0){
        throw runtime_error("Empty list");
    }
    A deleted=elements2[pos-1];
    for(int i=pos-1;i<size;i++){
        elements2[i]=elements2[i+1];
    };
    size--;
    return (deleted);
}


/*void ArrayListM<A>::printList(){
    cout << "(";
    for(int i=0;i<size;i++){
        cout<<elements[i];
        if(i<size-1)
        {
            cout<<"<-";
        }
    }
    cout << ")";
}*/

template <class A>
ArrayListM<A>::~ArrayListM()
{
   size=0;
   pos=0;
   delete[] elements2;
}

template class ArrayListM<int>;
template class ArrayListM< ArrayList<Carta*> >;

