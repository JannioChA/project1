#ifndef CONTROLADORA_H
#define CONTROLADORA_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include "imagen.h"
#include "boton.h"
#include <QDebug>
#include "iostream"
#include "arraylist.h"

using namespace std;

class Controladora: public QGraphicsView
{
    Q_OBJECT
public:
    Controladora();
    void Scena();
    void CargarImagen(int i, int j);
    void agregarPanelJuego();// hace la divicion entre el tablero y las cosas que puede tocar el jugador
    void colocaJugadorActivo();
    void setJugadorActivo();// recive el jugador siguiente
    void colocarManoCartas();
    void colocarCementerio();
    void creaLista();
    void creaTablero();
    void menuInicio();
    ArrayList<Carta*> cartas;
    int clickeado;
    int numeroJugadores;
    // y todo lo demas que ocupe

    QGraphicsScene* scene;

public slots:
    void clean();
    void tipoTablero2();
    void tipoTablero3();
    void tipoTablero4();
    void IniciarJuego();
    void tableroNormal();
    void tableroAleatorio();
    void setImagen(QString);
    void click1();
    void click2();
    void click3();
    void click4();
    void click5();
    void click6();
    void click7();
    void click8();
    void click9();
    void click10();
    void click11();
    void click12();
    void click13();
    void click14();
    void click15();
    void click16();
    void click17();
    void click18();
    void click19();
    void click20();
    void click21();
    void click22();
    void click23();
    void click24();
    void click25();
    void click26();
    void click27();
    void click28();
    void click29();
    void click30();
    void click31();
    void click32();
    void click33();
    void click34();
    void click35();
    void click36();
    void click37();
    void click38();
    void click39();
    void click40();
    void click41();
    void click42();
    void click43();
    void click44();
    void click45();
    void click46();
    void click47();
    void click48();
    void click49();
    void click50();
    void click51();
    void click52();
    void click53();
    void click54();
    void click55();
    void click56();
    void click57();
    void click58();
    void click59();
    void click60();
    void click61();
    void click62();
    void click63();
    void click64();
    void click65();
    void click66();
    void click67();
    void click68();
    void click69();
    void click70();
    void click71();
    void click72();
    void click73();
    void click74();
    void click75();
    void click76();
    void click77();
    void click78();
    void click79();
    void click80();
    void click81();
    void click82();
    void click83();
    void click84();
    void click85();
    void click86();
    void click87();
    void click88();
    void click89();
    void click90();
    void click91();
    void click92();
    void click93();
    void click94();
    void click95();
    void click96();
    void click97();
    void click98();
    void click99();
    void click100();
    void imprimir();
    //void agregarTablero();

};

#endif // CONTROLADORA_H
