#ifndef CONTROLADORA_H
#define CONTROLADORA_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsRectItem>

#include "imagen.h"
#include "boton.h"
#include <QDebug>
#include "iostream"
#include "arraylist.h"

using namespace std;

class Controladora: public QGraphicsView
{
    Q_OBJECT
public:
    Controladora();
    void Scena();
    void CargarImagen(int i, int j);
    void agregarPanelJuego();// hace la divicion entre el tablero y las cosas que puede tocar el jugador
    void colocaJugadorActivo();
    void setJugadorActivo();// recive el jugador siguiente
    void colocarManoCartas();
    void colocarCementerio();
    void creaLista();
    void creaTablero();
    ArrayList<Carta*> cartas;
    // y todo lo demas que ocupe

    QGraphicsScene* scene;

public slots:
    void clean();
    void IniciarJuego();
    void getPosicion(QString);
    //void agregarTablero();

};

#endif // CONTROLADORA_H
