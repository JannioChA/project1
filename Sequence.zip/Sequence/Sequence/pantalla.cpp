#include "pantalla.h"

Pantalla::Pantalla()
{

}
