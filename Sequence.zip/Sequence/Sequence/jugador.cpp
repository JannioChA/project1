#include "jugador.h"

Jugador::Jugador()
{
    this->maximoConsecutivo = 0;
}

