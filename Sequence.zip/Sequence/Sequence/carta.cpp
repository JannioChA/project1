#include "carta.h"

Carta::Carta(QString nombre)
{
    this->nombre = nombre;
    this->fichaPuesta = 0;
}
int Carta::getFichaPuesta()
{
    return this->fichaPuesta;
}
QString Carta::getNombre()
{
    return this->nombre;
}
void Carta::setFichaPuesta(int valor)
{
    this->fichaPuesta = valor;
}
void Carta::setNombre(QString nombre)
{
    this->nombre = nombre;
}


