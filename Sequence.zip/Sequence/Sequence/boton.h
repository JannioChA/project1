#ifndef BOTON_H
#define BOTON_H

#include <QGraphicsSceneMouseEvent>
#include <QBrush>
#include <QGraphicsTextItem>
#include <QGraphicsPixmapItem>

using namespace std;

class Boton: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    Boton(QString Name, QString Url, int pos1, int pos2);
    Boton(QString Url, int pos1, int pos2);
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);
    QString getImagen();

signals:
    void clicked();

private:
    QGraphicsTextItem *textBoton;
    QString imagen;
};

#endif // BOTON_H
