#include "CArrayList.h"
#include <Carta.h>
#include <Boton.h>
#include <Jugador.h>

using namespace std;

template <class A>
CArrayList<A>::CArrayList()
{
    max=1024;
    size=0;
    pos=0;
    elements=new A[max];
}

template <class A>
CArrayList<A>::CArrayList(int pMax)
{
    max=pMax;
    size=0;
    pos=0;
    elements=new A[pMax];
}

template <class A>
A CArrayList<A>::getValue(){
    if(pos<0 || pos>size){
        throw runtime_error("Index out of bounds");
    }
    return elements[pos-1];
}

template <class A>
int CArrayList<A>::getPos(){
    return pos;
}

template <class A>
int CArrayList<A>::getSize(){
    return size;
}

template <class A>
void CArrayList<A>::goToStart(){
    pos=0;
}

template <class A>
void CArrayList<A>::goToEnd(){
    pos=size+1;
}

template <class A>
void CArrayList<A>::goToPos(int pos){
    if(pos>size || pos<0){
        throw runtime_error("Index out of bounds");
    }
    pos=pos;
}

template <class A>
void CArrayList<A>::next(){
    if(pos==size-1){
        pos=0;
    }
    else{
       pos++;
    }
}

template <class A>
void CArrayList<A>::previous(){
    if(pos==0){
        pos=size-1;
    }
    else {
       pos--;
    }
}

template <class A>
void CArrayList<A>::append(A pElement){
    if(size==max){
        throw runtime_error("List Full");
    }
    elements[size]=pElement;
    size++;
}

//Posicionar a Pos en la posicion a insertar
template <class A>
void CArrayList<A>::insertar(A pElement){
    for(int i=size;i>pos-1;i--){
        elements[i]=elements[i-1];
    }
    elements[pos-1]=pElement;
    size++;
}

//Pos apuntando al elemento a eliminar
template <class A>
A CArrayList<A>::remove(){
    if(size==0){
        throw runtime_error("Empty list");
    }
    A deleted=elements[pos-1];
    for(int i=pos-1;i<size;i++){
        elements[i]=elements[i+1];
    }
    size--;
    return (deleted);
}

//template <class A>
/*void ArrayList<A>::printList(){
    cout << "(";
    for(int i=0;i<size;i++){
        cout<<elements[i];
        if(i<size-1)
        {
            cout<<"<-";
        }
    }
    cout << ")";
}*/

template <class A>
CArrayList<A>::~CArrayList()
{
   size=0;
   pos=0;
   delete[] elements;
}
template class CArrayList<int>;
template class CArrayList<QString>;
template class CArrayList<Boton*>;
template class CArrayList<Carta*>;
template class CArrayList<Jugador*>;
template class CArrayList< CArrayList<Carta*> >;
