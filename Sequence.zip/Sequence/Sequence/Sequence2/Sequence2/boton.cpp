#include "boton.h"
#include <QDebug>
#include "controladora.h"
#include <iostream>
#include <string>
//#extern Controladora *Controladora;

using namespace std;


Boton::Boton(QString Name, QString Url, int pos1, int pos2)
{
    setPixmap(Url);
    //qDebug()<<Name;// Imprimir QSTRINGS
    textBoton = new QGraphicsTextItem(Name,this);
    this->setPos(pos1,pos2);
    this->imagen = Url;


    setAcceptHoverEvents(true);
}
Boton::Boton(QString Url, int pos1, int pos2)
{
    setPixmap(Url);
    //qDebug()<<Name;// Imprimir QSTRINGS
    textBoton = new QGraphicsTextItem("",this);
    this->setPos(pos1,pos2);
    this->imagen = Url;


    setAcceptHoverEvents(true);
}
void Boton::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
   emit clicked();

}
void Boton::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    this->setScale(1.02); // Hace que se haga transparente
}
void Boton::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    this->setScale(1.0);
}
void Boton::setImagen(QString nuevaImagen)
{
    this->setPixmap(nuevaImagen);
    this->imagen = nuevaImagen;
}

QString Boton::getImagen()
{
    return this->imagen;
}
