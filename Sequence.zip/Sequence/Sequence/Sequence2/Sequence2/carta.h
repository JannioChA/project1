#ifndef CARTA_H
#define CARTA_H
#include <QGraphicsTextItem>
#include <QDebug>


class Carta
{
public:
    Carta(QString nombre);
    int getFichaPuesta();
    QString getNombre();
    bool getPerteneceSecuencia();
    void setNombre(QString nombre);
    void setFichaPuesta(int valor);
    void setPerteneceSecuencia(bool valor);

private:
    int fichaPuesta;
    QString nombre;
    bool perteneceSecuencia;
};
#endif // CARTA_H
