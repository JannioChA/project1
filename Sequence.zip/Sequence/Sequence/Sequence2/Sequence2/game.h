#ifndef GAME_H
#define GAME_H

#include <QGraphicsPixmapItem>
#include <QObject>

#include "controladora.h"



class Game
{
public:
    Game();
};

#endif // GAME_H
