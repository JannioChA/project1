#include "ArrayList.h"
#include <Carta.h>
#include <Boton.h>

using namespace std;

template <class A>
ArrayList<A>::ArrayList()
{
    max=1024;
    size=0;
    pos=0;
    elements=new A[max];
}

template <class A>
ArrayList<A>::ArrayList(int pMax)
{
    max=pMax;
    size=0;
    pos=0;
    elements=new A[pMax];
}

template <class A>
A ArrayList<A>::getValue(){
    if(pos<0 || pos>size){
        //throw runtime_error("Index out of bounds");
        cout << "Index out of bounds";
    }
    return elements[pos-1];
}

template <class A>
int ArrayList<A>::getPos(){
    return pos;
}

template <class A>
int ArrayList<A>::getSize(){
    return size;
}

template <class A>
void ArrayList<A>::goToStart(){
    pos=0;
}

template <class A>
void ArrayList<A>::goToEnd(){
    pos=size+1;
}

template <class A>
void ArrayList<A>::goToPos(int pos){
    if(pos>size || pos<0){
        //throw runtime_error("Index out of bounds");
        cout << "Index out of bounds";
    }
    pos=pos;
}

template <class A>
void ArrayList<A>::next(){
    if(pos>size){
        //throw runtime_error("Index out of bounds");
        cout << "Index out of bounds";
    }
    pos++;
}

template <class A>
void ArrayList<A>::previous(){
    if(pos<=0){
        //throw runtime_error("Index out of bounds");
        cout << "Index out of bounds";
    }
    pos--;
}

template <class A>
void ArrayList<A>::append(A pElement){
    if(size==max){
        //throw runtime_error("List Full");
        cout << "List Full";
    }
    elements[size]=pElement;
    size++;
}

//Posicionar a Pos en la posicion a insertar
template <class A>
void ArrayList<A>::insertar(A pElement){
    for(int i=size;i>pos-1;i--){
        elements[i]=elements[i-1];
    }
    elements[pos-1]=pElement;
    size++;
}

//Pos apuntando al elemento a eliminar
template <class A>
A ArrayList<A>::remove(){
    if(size==0){
        //throw runtime_error("Empty list");
        cout << "Empty List";
    }
    A deleted=elements[pos-1];
    for(int i=pos-1;i<size;i++){
        elements[i]=elements[i+1];
    }
    size--;
    return (deleted);
}

//template <class A>
/*void ArrayList<A>::printList(){
    cout << "(";
    for(int i=0;i<size;i++){
        qDebug()<<elements[i];
        if(i<size-1)
        {
            cout<<"<-";
        }
    }
    cout << ")";
}*/

template <class A>
ArrayList<A>::~ArrayList()
{
   size=0;
   pos=0;
   delete[] elements;
}
template class ArrayList<int>;
template class ArrayList<bool>;
template class ArrayList<QString>;
template class ArrayList<Boton*>;
template class ArrayList<Carta*>;
template class ArrayList< ArrayList<Carta*> >;



