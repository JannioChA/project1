#include "imagen.h"

Imagen::Imagen(QString ruta_imagen)
{
    setPixmap(QPixmap(ruta_imagen));

}


