#ifndef ARRAYLISTM_H
#define ARRAYLISTM_H


#include <stdexcept>
#include "carta.h"
#include "arraylist.h"
#include <iostream>

template <class A> class ArrayListM
{
    public:
        ArrayListM();
        ArrayListM(int pMax);
        A getValue();
        int getPos();
        int getSize();
        void goToStart();
        void goToEnd();
        void goToPos(int pos);
        void next();
        void previous();
        void append(A pElement);
        void insertar(A pElement);
        A remove();
        void printList();
        ~ArrayListM();

    protected:
        int size;
        int max;
        int pos;
    public:
        A* elements2;
};
#endif // ARRAYLISTM_H

