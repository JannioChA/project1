#ifndef CARTA_H
#define CARTA_H
#include <QGraphicsTextItem>
#include <QDebug>


class Carta
{
public:
    Carta(QString nombre);
    int getFichaPuesta();
    QString getNombre();
    void setNombre(QString nombre);
    void setFichaPuesta(int valor);

private:
    int fichaPuesta;
    QString nombre;
};
#endif // CARTA_H
