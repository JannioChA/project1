#include "controladora.h"
#include "imagen.h"
#include "boton.h"
#include "carta.h"
#include "arraylist.h"
#include "carraylist.h"
#include "arraystack.h"


QString imagen;

Controladora::Controladora()
{
    Scena();
    creaLista();
    menuInicio();
    //CargarImagen();
    //x->hide();//Esconde las cosas
}

void Controladora::menuInicio()
{
    Boton *jugadores2 = new Boton(":/img/botonJugador.png",100,400);
    connect(jugadores2, SIGNAL(clicked()), this, SLOT(tipoTablero2()));
    scene->addItem(jugadores2);

    Boton *jugadores3 = new Boton(":/img/botonJugador.png",500,400);
    connect(jugadores3, SIGNAL(clicked()), this, SLOT(tipoTablero3()));
    scene->addItem(jugadores3);


    Boton *jugadores4 = new Boton(":/img/botonJugador.png",900,400);
    connect(jugadores4, SIGNAL(clicked()), this, SLOT(tipoTablero4()));
    scene->addItem(jugadores4);
}

void Controladora::creaLista()
{
    this->cartas.append(new Carta (":/img/4esquinas.png"));
    this->cartas.append(new Carta (":/img/ace_of_clubs.png"));
    this->cartas.append(new Carta (":/img/king_of_clubs2.png"));
    this->cartas.append(new Carta (":/img/queen_of_clubs.png"));
    this->cartas.append(new Carta (":/img/10_of_clubs.png"));
    this->cartas.append(new Carta (":/img/9_of_clubs.png"));
    this->cartas.append(new Carta (":/img/8_of_clubs.png"));
    this->cartas.append(new Carta (":/img/7_of_clubs.png"));
    this->cartas.append(new Carta (":/img/6_of_clubs.png"));
    this->cartas.append(new Carta (":/img/4esquinas.png"));
    this->cartas.append(new Carta (":/img/ace_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/7_of_spades.png"));
    this->cartas.append(new Carta (":/img/8_of_spades.png"));
    this->cartas.append(new Carta (":/img/9_of_spades.png"));
    this->cartas.append(new Carta (":/img/10_of_spades.png"));
    this->cartas.append(new Carta (":/img/queen_of_spades.png"));
    this->cartas.append(new Carta (":/img/king_of_spades.png"));
    this->cartas.append(new Carta (":/img/ace_of_spades.png"));
    this->cartas.append(new Carta (":/img/5_of_clubs.png"));
    this->cartas.append(new Carta (":/img/2_of_spades.png"));
    this->cartas.append(new Carta (":/img/king_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/6_of_spades.png"));
    this->cartas.append(new Carta (":/img/10_of_clubs.png"));
    this->cartas.append(new Carta (":/img/9_of_clubs.png"));
    this->cartas.append(new Carta (":/img/8_of_clubs.png"));
    this->cartas.append(new Carta (":/img/7_of_clubs.png"));
    this->cartas.append(new Carta (":/img/6_of_clubs.png"));
    this->cartas.append(new Carta (":/img/2_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/4_of_clubs.png"));
    this->cartas.append(new Carta (":/img/3_of_spades.png"));
    this->cartas.append(new Carta (":/img/queen_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/5_of_spades.png"));
    this->cartas.append(new Carta (":/img/queen_of_clubs.png"));
    this->cartas.append(new Carta (":/img/8_of_hearts.png"));
    this->cartas.append(new Carta (":/img/7_of_hearts.png"));
    this->cartas.append(new Carta (":/img/6_of_hearts.png"));
    this->cartas.append(new Carta (":/img/5_of_clubs.png"));
    this->cartas.append(new Carta (":/img/3_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/3_of_clubs.png"));
    this->cartas.append(new Carta (":/img/4_of_spades.png"));
    this->cartas.append(new Carta (":/img/10_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/4_of_spades.png"));
    this->cartas.append(new Carta (":/img/king_of_clubs.png"));
    this->cartas.append(new Carta (":/img/9_of_hearts.png"));
    this->cartas.append(new Carta (":/img/2_of_hearts.png"));
    this->cartas.append(new Carta (":/img/5_of_hearts.png"));
    this->cartas.append(new Carta (":/img/4_of_clubs.png"));
    this->cartas.append(new Carta (":/img/4_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/2_of_clubs.png"));
    this->cartas.append(new Carta (":/img/5_of_spades.png"));
    this->cartas.append(new Carta (":/img/9_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/3_of_spades.png"));
    this->cartas.append(new Carta (":/img/ace_of_clubs.png"));
    this->cartas.append(new Carta (":/img/10_of_hearts.png"));
    this->cartas.append(new Carta (":/img/3_of_hearts.png"));
    this->cartas.append(new Carta (":/img/4_of_hearts.png"));
    this->cartas.append(new Carta (":/img/3_of_clubs.png"));
    this->cartas.append(new Carta (":/img/5_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/ace_of_hearts.png"));
    this->cartas.append(new Carta (":/img/6_of_spades.png"));
    this->cartas.append(new Carta (":/img/8_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/2_of_spades.png"));
    this->cartas.append(new Carta (":/img/ace_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/queen_of_hearts.png"));
    this->cartas.append(new Carta (":/img/king_of_hearts.png"));
    this->cartas.append(new Carta (":/img/ace_of_hearts.png"));
    this->cartas.append(new Carta (":/img/2_of_clubs.png"));
    this->cartas.append(new Carta (":/img/6_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/king_of_hearts.png"));
    this->cartas.append(new Carta (":/img/7_of_spades.png"));
    this->cartas.append(new Carta (":/img/7_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/2_of_hearts.png"));
    this->cartas.append(new Carta (":/img/king_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/queen_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/10_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/9_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/8_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/7_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/queen_of_hearts.png"));
    this->cartas.append(new Carta (":/img/8_of_spades.png"));
    this->cartas.append(new Carta (":/img/6_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/3_of_hearts.png"));
    this->cartas.append(new Carta (":/img/4_of_hearts.png"));
    this->cartas.append(new Carta (":/img/5_of_hearts.png"));
    this->cartas.append(new Carta (":/img/6_of_hearts.png"));
    this->cartas.append(new Carta (":/img/7_of_hearts.png"));
    this->cartas.append(new Carta (":/img/8_of_hearts.png"));
    this->cartas.append(new Carta (":/img/9_of_hearts.png"));
    this->cartas.append(new Carta (":/img/10_of_hearts.png"));
    this->cartas.append(new Carta (":/img/9_of_spades.png"));
    this->cartas.append(new Carta (":/img/4esquinas.png"));
    this->cartas.append(new Carta (":/img/5_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/4_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/3_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/2_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/ace_of_spades.png"));
    this->cartas.append(new Carta (":/img/king_of_spades.png"));
    this->cartas.append(new Carta (":/img/queen_of_spades.png"));
    this->cartas.append(new Carta (":/img/10_of_spades.png"));
    this->cartas.append(new Carta (":/img/4esquinas.png"));
    //this->cartas = cartas;
}

void Controladora::creaTablero()
{
    int imagen = 0;
    int i = 220;
    int j = 20;

    Boton *tablero1 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero1, SIGNAL(clicked()), this, SLOT(click1()));
    scene->addItem(tablero1);
    imagen++;
    i = i+101;

    Boton *tablero2 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero2, SIGNAL(clicked()), this, SLOT(click2()));
    scene->addItem(tablero2);
    imagen++;
    i = i+101;

    Boton *tablero3 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero3, SIGNAL(clicked()), this, SLOT(click3()));
    scene->addItem(tablero3);
    imagen++;
    i = i+101;

    Boton *tablero4 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero4, SIGNAL(clicked()), this, SLOT(click4()));
    scene->addItem(tablero4);
    imagen++;
    i = i+101;

    Boton *tablero5 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero5, SIGNAL(clicked()), this, SLOT(click5()));
    scene->addItem(tablero5);
    imagen++;
    i = i+101;

    Boton *tablero6 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero6, SIGNAL(clicked()), this, SLOT(click6()));
    scene->addItem(tablero6);
    imagen++;
    i = i+101;

    Boton *tablero7 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero7, SIGNAL(clicked()), this, SLOT(click7()));
    scene->addItem(tablero7);
    imagen++;
    i = i+101;

    Boton *tablero8 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero8, SIGNAL(clicked()), this, SLOT(click8()));
    scene->addItem(tablero8);
    imagen++;
    i = i+101;

    Boton *tablero9 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero9, SIGNAL(clicked()), this, SLOT(click9()));
    scene->addItem(tablero9);
    imagen++;
    i = i+101;

    Boton *tablero10 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero10, SIGNAL(clicked()), this, SLOT(click10()));
    scene->addItem(tablero10);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero11 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero11, SIGNAL(clicked()), this, SLOT(click11()));
    connect(tablero11, SIGNAL(clicked()), this, SLOT(imprimir()));
    scene->addItem(tablero11);
    imagen++;
    i = i+101;

    Boton *tablero12 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero12, SIGNAL(clicked()), this, SLOT(click12()));
    scene->addItem(tablero12);
    imagen++;
    i = i+101;

    Boton *tablero13 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero13, SIGNAL(clicked()), this, SLOT(click13()));
    scene->addItem(tablero13);
    imagen++;
    i = i+101;

    Boton *tablero14 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero14, SIGNAL(clicked()), this, SLOT(click14()));
    scene->addItem(tablero14);
    imagen++;
    i = i+101;

    Boton *tablero15 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero15, SIGNAL(clicked()), this, SLOT(click15()));
    scene->addItem(tablero15);
    imagen++;
    i = i+101;

    Boton *tablero16 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero16, SIGNAL(clicked()), this, SLOT(click16()));
    scene->addItem(tablero16);
    imagen++;
    i = i+101;

    Boton *tablero17 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero17, SIGNAL(clicked()), this, SLOT(click17()));
    scene->addItem(tablero17);
    imagen++;
    i = i+101;

    Boton *tablero18 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero18, SIGNAL(clicked()), this, SLOT(click18()));
    scene->addItem(tablero18);
    imagen++;
    i = i+101;

    Boton *tablero19 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero19, SIGNAL(clicked()), this, SLOT(click19()));
    scene->addItem(tablero19);
    imagen++;
    i = i+101;

    Boton *tablero20 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero20, SIGNAL(clicked()), this, SLOT(click20()));
    scene->addItem(tablero20);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero21 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero21, SIGNAL(clicked()), this, SLOT(click21()));
    scene->addItem(tablero21);
    imagen++;
    i = i+101;

    Boton *tablero22 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero22, SIGNAL(clicked()), this, SLOT(click22()));
    scene->addItem(tablero22);
    imagen++;
    i = i+101;

    Boton *tablero23 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero23, SIGNAL(clicked()), this, SLOT(click23()));
    scene->addItem(tablero23);
    imagen++;
    i = i+101;

    Boton *tablero24 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero24, SIGNAL(clicked()), this, SLOT(click24()));
    scene->addItem(tablero24);
    imagen++;
    i = i+101;

    Boton *tablero25 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero25, SIGNAL(clicked()), this, SLOT(click25()));
    scene->addItem(tablero25);
    imagen++;
    i = i+101;

    Boton *tablero26 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero26, SIGNAL(clicked()), this, SLOT(click26()));
    scene->addItem(tablero26);
    imagen++;
    i = i+101;

    Boton *tablero27 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero27, SIGNAL(clicked()), this, SLOT(click27()));
    scene->addItem(tablero27);
    imagen++;
    i = i+101;

    Boton *tablero28 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero28, SIGNAL(clicked()), this, SLOT(click28()));
    scene->addItem(tablero28);
    imagen++;
    i = i+101;

    Boton *tablero29 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero29, SIGNAL(clicked()), this, SLOT(click29()));
    scene->addItem(tablero29);
    imagen++;
    i = i+101;

    Boton *tablero30 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero30, SIGNAL(clicked()), this, SLOT(click30()));
    scene->addItem(tablero30);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero31 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero31, SIGNAL(clicked()), this, SLOT(click31()));
    scene->addItem(tablero31);
    imagen++;
    i = i+101;

    Boton *tablero32 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero32, SIGNAL(clicked()), this, SLOT(click32()));
    scene->addItem(tablero32);
    imagen++;
    i = i+101;

    Boton *tablero33 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero33, SIGNAL(clicked()), this, SLOT(click33()));
    scene->addItem(tablero33);
    imagen++;
    i = i+101;

    Boton *tablero34 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero34, SIGNAL(clicked()), this, SLOT(click34()));
    scene->addItem(tablero34);
    imagen++;
    i = i+101;

    Boton *tablero35 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero35, SIGNAL(clicked()), this, SLOT(click35()));
    scene->addItem(tablero35);
    imagen++;
    i = i+101;

    Boton *tablero36 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero36, SIGNAL(clicked()), this, SLOT(click36()));
    scene->addItem(tablero36);
    imagen++;
    i = i+101;

    Boton *tablero37 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero37, SIGNAL(clicked()), this, SLOT(click37()));
    scene->addItem(tablero37);
    imagen++;
    i = i+101;

    Boton *tablero38 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero38, SIGNAL(clicked()), this, SLOT(click38()));
    scene->addItem(tablero38);
    imagen++;
    i = i+101;

    Boton *tablero39 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero39, SIGNAL(clicked()), this, SLOT(click39()));
    scene->addItem(tablero39);
    imagen++;
    i = i+101;

    Boton *tablero40 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero40, SIGNAL(clicked()), this, SLOT(click40()));
    scene->addItem(tablero40);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero41 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero41, SIGNAL(clicked()), this, SLOT(click41()));
    scene->addItem(tablero41);
    imagen++;
    i = i+101;

    Boton *tablero42 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero42, SIGNAL(clicked()), this, SLOT(click42()));
    scene->addItem(tablero42);
    imagen++;
    i = i+101;

    Boton *tablero43 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero43, SIGNAL(clicked()), this, SLOT(click43()));
    scene->addItem(tablero43);
    imagen++;
    i = i+101;

    Boton *tablero44 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero44, SIGNAL(clicked()), this, SLOT(click44()));
    scene->addItem(tablero44);
    imagen++;
    i = i+101;

    Boton *tablero45 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero45, SIGNAL(clicked()), this, SLOT(click45()));
    scene->addItem(tablero45);
    imagen++;
    i = i+101;

    Boton *tablero46 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero46, SIGNAL(clicked()), this, SLOT(click46()));
    scene->addItem(tablero46);
    imagen++;
    i = i+101;

    Boton *tablero47 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero47, SIGNAL(clicked()), this, SLOT(click47()));
    scene->addItem(tablero47);
    imagen++;
    i = i+101;

    Boton *tablero48 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero48, SIGNAL(clicked()), this, SLOT(click48()));
    scene->addItem(tablero48);
    imagen++;
    i = i+101;

    Boton *tablero49 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero49, SIGNAL(clicked()), this, SLOT(click49()));
    scene->addItem(tablero49);
    imagen++;
    i = i+101;

    Boton *tablero50 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero50, SIGNAL(clicked()), this, SLOT(click50()));
    scene->addItem(tablero50);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero51 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero51, SIGNAL(clicked()), this, SLOT(click51()));
    scene->addItem(tablero51);
    imagen++;
    i = i+101;

    Boton *tablero52 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero52, SIGNAL(clicked()), this, SLOT(click52()));
    scene->addItem(tablero52);
    imagen++;
    i = i+101;

    Boton *tablero53 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero53, SIGNAL(clicked()), this, SLOT(click53()));
    scene->addItem(tablero53);
    imagen++;
    i = i+101;

    Boton *tablero54 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero54, SIGNAL(clicked()), this, SLOT(click54()));
    scene->addItem(tablero54);
    imagen++;
    i = i+101;

    Boton *tablero55 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero55, SIGNAL(clicked()), this, SLOT(click55()));
    scene->addItem(tablero55);
    imagen++;
    i = i+101;

    Boton *tablero56 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero56, SIGNAL(clicked()), this, SLOT(click56()));
    scene->addItem(tablero56);
    imagen++;
    i = i+101;

    Boton *tablero57 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero57, SIGNAL(clicked()), this, SLOT(click57()));
    scene->addItem(tablero57);
    imagen++;
    i = i+101;

    Boton *tablero58 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero58, SIGNAL(clicked()), this, SLOT(click58()));
    scene->addItem(tablero58);
    imagen++;
    i = i+101;

    Boton *tablero59 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero59, SIGNAL(clicked()), this, SLOT(click59()));
    scene->addItem(tablero59);
    imagen++;
    i = i+101;

    Boton *tablero60 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero60, SIGNAL(clicked()), this, SLOT(click60()));
    scene->addItem(tablero60);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero61 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero61, SIGNAL(clicked()), this, SLOT(click61()));
    scene->addItem(tablero61);
    imagen++;
    i = i+101;

    Boton *tablero62 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero62, SIGNAL(clicked()), this, SLOT(click62()));
    scene->addItem(tablero62);
    imagen++;
    i = i+101;

    Boton *tablero63 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero63, SIGNAL(clicked()), this, SLOT(click63()));
    scene->addItem(tablero63);
    imagen++;
    i = i+101;

    Boton *tablero64 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero64, SIGNAL(clicked()), this, SLOT(click64()));
    scene->addItem(tablero64);
    imagen++;
    i = i+101;

    Boton *tablero65 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero65, SIGNAL(clicked()), this, SLOT(click65()));
    scene->addItem(tablero65);
    imagen++;
    i = i+101;

    Boton *tablero66 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero66, SIGNAL(clicked()), this, SLOT(click66()));
    scene->addItem(tablero66);
    imagen++;
    i = i+101;

    Boton *tablero67 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero67, SIGNAL(clicked()), this, SLOT(click67()));
    scene->addItem(tablero67);
    imagen++;
    i = i+101;

    Boton *tablero68 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero68, SIGNAL(clicked()), this, SLOT(click68()));
    scene->addItem(tablero68);
    imagen++;
    i = i+101;

    Boton *tablero69 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero69, SIGNAL(clicked()), this, SLOT(click69()));
    scene->addItem(tablero69);
    imagen++;
    i = i+101;

    Boton *tablero70 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero70, SIGNAL(clicked()), this, SLOT(click70()));
    scene->addItem(tablero70);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero71 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero71, SIGNAL(clicked()), this, SLOT(click71()));
    scene->addItem(tablero71);
    imagen++;
    i = i+101;

    Boton *tablero72 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero72, SIGNAL(clicked()), this, SLOT(click72()));
    scene->addItem(tablero72);
    imagen++;
    i = i+101;

    Boton *tablero73 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero73, SIGNAL(clicked()), this, SLOT(click73()));
    scene->addItem(tablero73);
    imagen++;
    i = i+101;

    Boton *tablero74 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero74, SIGNAL(clicked()), this, SLOT(click74()));
    scene->addItem(tablero74);
    imagen++;
    i = i+101;

    Boton *tablero75 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero75, SIGNAL(clicked()), this, SLOT(click75()));
    scene->addItem(tablero75);
    imagen++;
    i = i+101;

    Boton *tablero76 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero76, SIGNAL(clicked()), this, SLOT(click76()));
    scene->addItem(tablero76);
    imagen++;
    i = i+101;

    Boton *tablero77 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero77, SIGNAL(clicked()), this, SLOT(click77()));
    scene->addItem(tablero77);
    imagen++;
    i = i+101;

    Boton *tablero78 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero78, SIGNAL(clicked()), this, SLOT(click78()));
    scene->addItem(tablero78);
    imagen++;
    i = i+101;

    Boton *tablero79 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero79, SIGNAL(clicked()), this, SLOT(click79()));
    scene->addItem(tablero79);
    imagen++;
    i = i+101;

    Boton *tablero80 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero80, SIGNAL(clicked()), this, SLOT(click80()));
    scene->addItem(tablero80);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero81 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero81, SIGNAL(clicked()), this, SLOT(click81()));
    scene->addItem(tablero81);
    imagen++;
    i = i+101;

    Boton *tablero82 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero82, SIGNAL(clicked()), this, SLOT(click82()));
    scene->addItem(tablero82);
    imagen++;
    i = i+101;

    Boton *tablero83 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero83, SIGNAL(clicked()), this, SLOT(click83()));
    scene->addItem(tablero83);
    imagen++;
    i = i+101;

    Boton *tablero84 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero84, SIGNAL(clicked()), this, SLOT(click84()));
    scene->addItem(tablero84);
    imagen++;
    i = i+101;

    Boton *tablero85 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero85, SIGNAL(clicked()), this, SLOT(click85()));
    scene->addItem(tablero85);
    imagen++;
    i = i+101;

    Boton *tablero86 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero86, SIGNAL(clicked()), this, SLOT(click86()));
    scene->addItem(tablero86);
    imagen++;
    i = i+101;

    Boton *tablero87 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero87, SIGNAL(clicked()), this, SLOT(click87()));
    scene->addItem(tablero87);
    imagen++;
    i = i+101;

    Boton *tablero88 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero88, SIGNAL(clicked()), this, SLOT(click88()));
    scene->addItem(tablero88);
    imagen++;
    i = i+101;

    Boton *tablero89 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero89, SIGNAL(clicked()), this, SLOT(click89()));
    scene->addItem(tablero89);
    imagen++;
    i = i+101;

    Boton *tablero90 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero90, SIGNAL(clicked()), this, SLOT(click90()));
    scene->addItem(tablero90);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero91 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero91, SIGNAL(clicked()), this, SLOT(click91()));
    scene->addItem(tablero91);
    imagen++;
    i = i+101;

    Boton *tablero92 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero92, SIGNAL(clicked()), this, SLOT(click92()));
    scene->addItem(tablero92);
    imagen++;
    i = i+101;

    Boton *tablero93 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero93, SIGNAL(clicked()), this, SLOT(click93()));
    scene->addItem(tablero93);
    imagen++;
    i = i+101;

    Boton *tablero94 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero94, SIGNAL(clicked()), this, SLOT(click94()));
    scene->addItem(tablero94);
    imagen++;
    i = i+101;

    Boton *tablero95 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero95, SIGNAL(clicked()), this, SLOT(click95()));
    scene->addItem(tablero95);
    imagen++;
    i = i+101;

    Boton *tablero96 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero96, SIGNAL(clicked()), this, SLOT(click96()));
    scene->addItem(tablero96);
    imagen++;
    i = i+101;

    Boton *tablero97 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero97, SIGNAL(clicked()), this, SLOT(click97()));
    scene->addItem(tablero97);
    imagen++;
    i = i+101;

    Boton *tablero98 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero98, SIGNAL(clicked()), this, SLOT(click98()));
    scene->addItem(tablero98);
    imagen++;
    i = i+101;

    Boton *tablero99 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero99, SIGNAL(clicked()), this, SLOT(click99()));
    scene->addItem(tablero99);
    imagen++;
    i = i+101;

    Boton *tablero100 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero100, SIGNAL(clicked()), this, SLOT(click100()));
    scene->addItem(tablero100);
}

////////////////////////////////Metodos Generales////////////////////////////////////////////////////////////////////
void Controladora::Scena()
{
    //Crea un escenario
    scene = new QGraphicsScene();
    scene->setSceneRect(0,0,1470,950);
    scene->setBackgroundBrush(Qt::blue);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setFixedSize(1470,950);
    scene->setBackgroundBrush(QBrush(QImage(":/img/f.png"))); //Cambia el fondo de la scena
    setScene(scene);
}
void Controladora::CargarImagen(int i, int j)
{
    //Crea una imagen
    Imagen *imagen = new Imagen(":/img/2_of_diamonds.png");
    imagen->setPos(i,j);
    //imagen->setScale(0);
    //imagen->setRotation(0);
    scene->addItem(imagen);
    //scene->removeItem(imagen);//remueve el elemento
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////Metodos SLOT/////////////////////////////////////////////////////////////////////////////////
void Controladora::clean()
{
    //Limpia la scena
    scene->clear();
}

void Controladora::tipoTablero2()
{
    this->clean();

    Boton *tableroNormal = new Boton(":/img/botonJugador.png",100,400);
    connect(tableroNormal, SIGNAL(clicked()), this, SLOT(tableroNormal()));
    scene->addItem(tableroNormal);

    Boton *tableroAleatorio = new Boton(":/img/botonJugador.png",900,400);
    connect(tableroAleatorio, SIGNAL(clicked()), this, SLOT(tableroAleatorio()));
    scene->addItem(tableroAleatorio);

    this->numeroJugadores=2;
}

void Controladora::tipoTablero3()
{
    this->clean();

    Boton *tableroNormal = new Boton(":/img/botonJugador.png",100,400);
    connect(tableroNormal, SIGNAL(clicked()), this, SLOT(tableroNormal()));
    scene->addItem(tableroNormal);

    Boton *tableroAleatorio = new Boton(":/img/botonJugador.png",900,400);
    connect(tableroAleatorio, SIGNAL(clicked()), this, SLOT(tableroAleatorio()));
    scene->addItem(tableroAleatorio);

    this->numeroJugadores=3;
}

void Controladora::tipoTablero4()
{
    this->clean();

    Boton *tableroNormal = new Boton(":/img/botonJugador.png",100,400);
    connect(tableroNormal, SIGNAL(clicked()), this, SLOT(tableroNormal()));
    scene->addItem(tableroNormal);

    Boton *tableroAleatorio = new Boton(":/img/botonJugador.png",900,400);
    connect(tableroAleatorio, SIGNAL(clicked()), this, SLOT(tableroAleatorio()));
    scene->addItem(tableroAleatorio);

    this->numeroJugadores=4;
}

void Controladora::tableroNormal()
{
    this->clean();
    creaTablero();
}

void Controladora::tableroAleatorio()
{
    this->clean();
    //randomiza la lista
    creaTablero();
}

void Controladora::IniciarJuego()
{
    scene->clear();
    // Aqui se llaman los METODOS para crear cartas, el maso, los jugadores
    // y poner a ejecutar el juego o iniciarlo junto con todos los componenes que tiene
}

void Controladora::setImagen(QString pImagen)
{
    imagen = pImagen;
}

void Controladora::imprimir()
{
    Imagen *imagen = new Imagen(":/img/10_of_diamonds.png");
    imagen->setPos(0,0);
    scene->addItem(imagen);
}



void Controladora::click1(){this->clickeado=1;}
void Controladora::click2(){this->clickeado=2;}
void Controladora::click3(){this->clickeado=3;}
void Controladora::click4(){this->clickeado=4;}
void Controladora::click5(){this->clickeado=5;}
void Controladora::click6(){this->clickeado=6;}
void Controladora::click7(){this->clickeado=7;}
void Controladora::click8(){this->clickeado=8;}
void Controladora::click9(){this->clickeado=9;}
void Controladora::click10(){this->clickeado=10;}
void Controladora::click11(){this->clickeado=11;}
void Controladora::click12(){this->clickeado=12;}
void Controladora::click13(){this->clickeado=13;}
void Controladora::click14(){this->clickeado=14;}
void Controladora::click15(){this->clickeado=15;}
void Controladora::click16(){this->clickeado=16;}
void Controladora::click17(){this->clickeado=17;}
void Controladora::click18(){this->clickeado=18;}
void Controladora::click19(){this->clickeado=19;}
void Controladora::click20(){this->clickeado=20;}
void Controladora::click21(){this->clickeado=21;}
void Controladora::click22(){this->clickeado=22;}
void Controladora::click23(){this->clickeado=23;}
void Controladora::click24(){this->clickeado=24;}
void Controladora::click25(){this->clickeado=25;}
void Controladora::click26(){this->clickeado=26;}
void Controladora::click27(){this->clickeado=27;}
void Controladora::click28(){this->clickeado=28;}
void Controladora::click29(){this->clickeado=29;}
void Controladora::click30(){this->clickeado=30;}
void Controladora::click31(){this->clickeado=31;}
void Controladora::click32(){this->clickeado=32;}
void Controladora::click33(){this->clickeado=33;}
void Controladora::click34(){this->clickeado=34;}
void Controladora::click35(){this->clickeado=35;}
void Controladora::click36(){this->clickeado=36;}
void Controladora::click37(){this->clickeado=37;}
void Controladora::click38(){this->clickeado=38;}
void Controladora::click39(){this->clickeado=39;}
void Controladora::click40(){this->clickeado=40;}
void Controladora::click41(){this->clickeado=41;}
void Controladora::click42(){this->clickeado=42;}
void Controladora::click43(){this->clickeado=43;}
void Controladora::click44(){this->clickeado=44;}
void Controladora::click45(){this->clickeado=45;}
void Controladora::click46(){this->clickeado=46;}
void Controladora::click47(){this->clickeado=47;}
void Controladora::click48(){this->clickeado=48;}
void Controladora::click49(){this->clickeado=49;}
void Controladora::click50(){this->clickeado=50;}
void Controladora::click51(){this->clickeado=51;}
void Controladora::click52(){this->clickeado=52;}
void Controladora::click53(){this->clickeado=53;}
void Controladora::click54(){this->clickeado=54;}
void Controladora::click55(){this->clickeado=55;}
void Controladora::click56(){this->clickeado=56;}
void Controladora::click57(){this->clickeado=57;}
void Controladora::click58(){this->clickeado=58;}
void Controladora::click59(){this->clickeado=59;}
void Controladora::click60(){this->clickeado=60;}
void Controladora::click61(){this->clickeado=61;}
void Controladora::click62(){this->clickeado=62;}
void Controladora::click63(){this->clickeado=63;}
void Controladora::click64(){this->clickeado=64;}
void Controladora::click65(){this->clickeado=65;}
void Controladora::click66(){this->clickeado=66;}
void Controladora::click67(){this->clickeado=67;}
void Controladora::click68(){this->clickeado=68;}
void Controladora::click69(){this->clickeado=69;}
void Controladora::click70(){this->clickeado=70;}
void Controladora::click71(){this->clickeado=71;}
void Controladora::click72(){this->clickeado=72;}
void Controladora::click73(){this->clickeado=73;}
void Controladora::click74(){this->clickeado=74;}
void Controladora::click75(){this->clickeado=75;}
void Controladora::click76(){this->clickeado=76;}
void Controladora::click77(){this->clickeado=77;}
void Controladora::click78(){this->clickeado=78;}
void Controladora::click79(){this->clickeado=79;}
void Controladora::click80(){this->clickeado=80;}
void Controladora::click81(){this->clickeado=81;}
void Controladora::click82(){this->clickeado=82;}
void Controladora::click83(){this->clickeado=83;}
void Controladora::click84(){this->clickeado=84;}
void Controladora::click85(){this->clickeado=85;}
void Controladora::click86(){this->clickeado=86;}
void Controladora::click87(){this->clickeado=87;}
void Controladora::click88(){this->clickeado=88;}
void Controladora::click89(){this->clickeado=89;}
void Controladora::click90(){this->clickeado=90;}
void Controladora::click91(){this->clickeado=91;}
void Controladora::click92(){this->clickeado=92;}
void Controladora::click93(){this->clickeado=93;}
void Controladora::click94(){this->clickeado=94;}
void Controladora::click95(){this->clickeado=95;}
void Controladora::click96(){this->clickeado=96;}
void Controladora::click97(){this->clickeado=97;}
void Controladora::click98(){this->clickeado=98;}
void Controladora::click99(){this->clickeado=99;}
void Controladora::click100(){this->clickeado=100;}




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*void Controladora::agregarTablero()
{
    for(int j=20;j<720;j=j+70){
            for(int i=200;i<1210;i=i+101){
                CargarImagen(i,j);
            }
        }
}*/
