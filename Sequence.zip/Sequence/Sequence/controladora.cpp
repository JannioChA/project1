#include "controladora.h"
#include "imagen.h"
#include "boton.h"
#include "carta.h"
#include "arraylist.h"

Controladora::Controladora()
{
    Scena();\
    creaLista();
    creaTablero();
    //CargarImagen();
    Boton *jugador2 = new Boton("hola", ":/img/botonJugador.png",100,400);
    connect(jugador2, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    //scene->addItem(jugador2);

    Boton *jugador3 = new Boton("hola", ":/img/botonJugador.png",500,400);
    connect(jugador3, SIGNAL(clicked()), this, SLOT(clean()));
    //scene->addItem(jugador3);


    Boton *jugador4 = new Boton("hola", ":/img/botonJugador.png",900,400);
    connect(jugador4, SIGNAL(clicked()), this, SLOT(clean()));
    //scene->addItem(jugador4);

    qDebug()<<cartas.elements[0]->getNombre();

    //x->//hide();//Esconde las cosas
}

void Controladora::creaLista()
{
    this->cartas.append(new Carta (":/img/4esquinas.png"));
    this->cartas.append(new Carta (":/img/ace_of_clubs.png"));
    this->cartas.append(new Carta (":/img/king_of_clubs2.png"));
    this->cartas.append(new Carta (":/img/queen_of_clubs.png"));
    this->cartas.append(new Carta (":/img/10_of_clubs.png"));
    this->cartas.append(new Carta (":/img/9_of_clubs.png"));
    this->cartas.append(new Carta (":/img/8_of_clubs.png"));
    this->cartas.append(new Carta (":/img/7_of_clubs.png"));
    this->cartas.append(new Carta (":/img/6_of_clubs.png"));
    this->cartas.append(new Carta (":/img/4esquinas.png"));
    this->cartas.append(new Carta (":/img/ace_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/7_of_spades.png"));
    this->cartas.append(new Carta (":/img/8_of_spades.png"));
    this->cartas.append(new Carta (":/img/9_of_spades.png"));
    this->cartas.append(new Carta (":/img/10_of_spades.png"));
    this->cartas.append(new Carta (":/img/queen_of_spades.png"));
    this->cartas.append(new Carta (":/img/king_of_spades.png"));
    this->cartas.append(new Carta (":/img/ace_of_spades.png"));
    this->cartas.append(new Carta (":/img/5_of_clubs.png"));
    this->cartas.append(new Carta (":/img/2_of_spades.png"));
    this->cartas.append(new Carta (":/img/king_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/6_of_spades.png"));
    this->cartas.append(new Carta (":/img/10_of_clubs.png"));
    this->cartas.append(new Carta (":/img/9_of_clubs.png"));
    this->cartas.append(new Carta (":/img/8_of_clubs.png"));
    this->cartas.append(new Carta (":/img/7_of_clubs.png"));
    this->cartas.append(new Carta (":/img/6_of_clubs.png"));
    this->cartas.append(new Carta (":/img/2_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/4_of_clubs.png"));
    this->cartas.append(new Carta (":/img/3_of_spades.png"));
    this->cartas.append(new Carta (":/img/queen_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/5_of_spades.png"));
    this->cartas.append(new Carta (":/img/queen_of_clubs.png"));
    this->cartas.append(new Carta (":/img/8_of_hearts.png"));
    this->cartas.append(new Carta (":/img/7_of_hearts.png"));
    this->cartas.append(new Carta (":/img/6_of_hearts.png"));
    this->cartas.append(new Carta (":/img/5_of_clubs.png"));
    this->cartas.append(new Carta (":/img/3_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/3_of_clubs.png"));
    this->cartas.append(new Carta (":/img/4_of_spades.png"));
    this->cartas.append(new Carta (":/img/10_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/4_of_spades.png"));
    this->cartas.append(new Carta (":/img/king_of_clubs.png"));
    this->cartas.append(new Carta (":/img/9_of_hearts.png"));
    this->cartas.append(new Carta (":/img/2_of_hearts.png"));
    this->cartas.append(new Carta (":/img/5_of_hearts.png"));
    this->cartas.append(new Carta (":/img/4_of_clubs.png"));
    this->cartas.append(new Carta (":/img/4_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/2_of_clubs.png"));
    this->cartas.append(new Carta (":/img/5_of_spades.png"));

    this->cartas.append(new Carta (":/img/9_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/3_of_spades.png"));
    this->cartas.append(new Carta (":/img/ace_of_clubs.png"));
    this->cartas.append(new Carta (":/img/10_of_hearts.png"));
    this->cartas.append(new Carta (":/img/3_of_hearts.png"));
    this->cartas.append(new Carta (":/img/4_of_hearts.png"));
    this->cartas.append(new Carta (":/img/3_of_clubs.png"));
    this->cartas.append(new Carta (":/img/5_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/ace_of_hearts.png"));
    this->cartas.append(new Carta (":/img/6_of_spades.png"));
    this->cartas.append(new Carta (":/img/8_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/2_of_spades.png"));
    this->cartas.append(new Carta (":/img/ace_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/queen_of_hearts.png"));
    this->cartas.append(new Carta (":/img/king_of_hearts.png"));
    this->cartas.append(new Carta (":/img/ace_of_hearts.png"));
    this->cartas.append(new Carta (":/img/2_of_clubs.png"));
    this->cartas.append(new Carta (":/img/6_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/king_of_hearts.png"));
    this->cartas.append(new Carta (":/img/7_of_spades.png"));
    this->cartas.append(new Carta (":/img/7_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/2_of_hearts.png"));
    this->cartas.append(new Carta (":/img/king_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/queen_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/10_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/9_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/8_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/7_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/queen_of_hearts.png"));
    this->cartas.append(new Carta (":/img/8_of_spades.png"));
    this->cartas.append(new Carta (":/img/6_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/3_of_hearts.png"));
    this->cartas.append(new Carta (":/img/4_of_hearts.png"));
    this->cartas.append(new Carta (":/img/5_of_hearts.png"));
    this->cartas.append(new Carta (":/img/6_of_hearts.png"));
    this->cartas.append(new Carta (":/img/7_of_hearts.png"));
    this->cartas.append(new Carta (":/img/8_of_hearts.png"));
    this->cartas.append(new Carta (":/img/9_of_hearts.png"));
    this->cartas.append(new Carta (":/img/10_of_hearts.png"));
    this->cartas.append(new Carta (":/img/9_of_spades.png"));
    this->cartas.append(new Carta (":/img/4esquinas.png"));
    this->cartas.append(new Carta (":/img/5_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/4_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/3_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/2_of_diamonds.png"));
    this->cartas.append(new Carta (":/img/ace_of_spades.png"));
    this->cartas.append(new Carta (":/img/king_of_spades.png"));
    this->cartas.append(new Carta (":/img/queen_of_spades.png"));
    this->cartas.append(new Carta (":/img/10_of_spades.png"));
    this->cartas.append(new Carta (":/img/4esquinas.png"));
    //this->cartas = cartas;
}

void Controladora::creaTablero()
{
    int imagen = 0;
    int i = 220;
    int j = 20;

    Boton *tablero1 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    QString prueba = tablero1->getImagen();
    connect(tablero1, SIGNAL(clicked()), this, SLOT(getPosicion(QString)));
    scene->addItem(tablero1);
    imagen++;
    i = i+101;

    Boton *tablero2 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero2, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero2);
    imagen++;
    i = i+101;

    Boton *tablero3 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero3, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero3);
    imagen++;
    i = i+101;

    Boton *tablero4 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero4, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero4);
    imagen++;
    i = i+101;

    Boton *tablero5 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero5, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero5);
    imagen++;
    i = i+101;

    Boton *tablero6 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero6, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero6);
    imagen++;
    i = i+101;

    Boton *tablero7 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero7, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero7);
    imagen++;
    i = i+101;

    Boton *tablero8 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero8, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero8);
    imagen++;
    i = i+101;

    Boton *tablero9 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero9, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero9);
    imagen++;
    i = i+101;

    Boton *tablero10 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero10, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero10);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero11 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero11, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero11);
    imagen++;
    i = i+101;

    Boton *tablero12 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero12, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero12);
    imagen++;
    i = i+101;

    Boton *tablero13 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero13, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero13);
    imagen++;
    i = i+101;

    Boton *tablero14 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero14, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero14);
    imagen++;
    i = i+101;

    Boton *tablero15 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero15, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero15);
    imagen++;
    i = i+101;

    Boton *tablero16 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero16, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero16);
    imagen++;
    i = i+101;

    Boton *tablero17 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero17, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero17);
    imagen++;
    i = i+101;

    Boton *tablero18 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero18, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero18);
    imagen++;
    i = i+101;

    Boton *tablero19 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero19, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero19);
    imagen++;
    i = i+101;

    Boton *tablero20 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero20, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero20);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero21 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero21, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero21);
    imagen++;
    i = i+101;

    Boton *tablero22 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero22, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero22);
    imagen++;
    i = i+101;

    Boton *tablero23 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero23, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero23);
    imagen++;
    i = i+101;

    Boton *tablero24 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero24, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero24);
    imagen++;
    i = i+101;

    Boton *tablero25 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero25, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero25);
    imagen++;
    i = i+101;

    Boton *tablero26 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero26, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero26);
    imagen++;
    i = i+101;

    Boton *tablero27 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero27, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero27);
    imagen++;
    i = i+101;

    Boton *tablero28 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero28, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero28);
    imagen++;
    i = i+101;

    Boton *tablero29 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero29, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero29);
    imagen++;
    i = i+101;

    Boton *tablero30 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero30, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero30);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero31 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero31, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero31);
    imagen++;
    i = i+101;

    Boton *tablero32 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero32, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero32);
    imagen++;
    i = i+101;

    Boton *tablero33 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero33, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero33);
    imagen++;
    i = i+101;

    Boton *tablero34 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero34, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero34);
    imagen++;
    i = i+101;

    Boton *tablero35 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero35, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero35);
    imagen++;
    i = i+101;

    Boton *tablero36 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero36, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero36);
    imagen++;
    i = i+101;

    Boton *tablero37 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero37, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero37);
    imagen++;
    i = i+101;

    Boton *tablero38 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero38, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero38);
    imagen++;
    i = i+101;

    Boton *tablero39 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero39, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero39);
    imagen++;
    i = i+101;

    Boton *tablero40 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero40, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero40);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero41 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero41, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero41);
    imagen++;
    i = i+101;

    Boton *tablero42 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero42, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero42);
    imagen++;
    i = i+101;

    Boton *tablero43 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero43, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero43);
    imagen++;
    i = i+101;

    Boton *tablero44 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero44, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero44);
    imagen++;
    i = i+101;

    Boton *tablero45 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero45, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero45);
    imagen++;
    i = i+101;

    Boton *tablero46 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero46, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero46);
    imagen++;
    i = i+101;

    Boton *tablero47 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero47, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero47);
    imagen++;
    i = i+101;

    Boton *tablero48 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero48, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero48);
    imagen++;
    i = i+101;

    Boton *tablero49 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero49, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero49);
    imagen++;
    i = i+101;

    Boton *tablero50 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero50, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero50);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero51 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero51, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero51);
    imagen++;
    i = i+101;

    Boton *tablero52 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero52, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero52);
    imagen++;
    i = i+101;

    Boton *tablero53 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero53, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero53);
    imagen++;
    i = i+101;

    Boton *tablero54 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero54, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero54);
    imagen++;
    i = i+101;

    Boton *tablero55 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero55, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero55);
    imagen++;
    i = i+101;

    Boton *tablero56 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero56, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero56);
    imagen++;
    i = i+101;

    Boton *tablero57 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero57, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero57);
    imagen++;
    i = i+101;

    Boton *tablero58 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero58, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero58);
    imagen++;
    i = i+101;

    Boton *tablero59 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero59, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero59);
    imagen++;
    i = i+101;

    Boton *tablero60 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero60, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero60);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero61 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero61, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero61);
    imagen++;
    i = i+101;

    Boton *tablero62 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero62, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero62);
    imagen++;
    i = i+101;

    Boton *tablero63 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero63, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero63);
    imagen++;
    i = i+101;

    Boton *tablero64 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero64, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero64);
    imagen++;
    i = i+101;

    Boton *tablero65 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero65, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero65);
    imagen++;
    i = i+101;

    Boton *tablero66 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero66, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero66);
    imagen++;
    i = i+101;

    Boton *tablero67 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero67, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero67);
    imagen++;
    i = i+101;

    Boton *tablero68 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero68, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero68);
    imagen++;
    i = i+101;

    Boton *tablero69 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero69, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero69);
    imagen++;
    i = i+101;

    Boton *tablero70 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero70, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero70);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero71 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero71, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero71);
    imagen++;
    i = i+101;

    Boton *tablero72 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero72, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero72);
    imagen++;
    i = i+101;

    Boton *tablero73 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero73, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero73);
    imagen++;
    i = i+101;

    Boton *tablero74 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero74, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero74);
    imagen++;
    i = i+101;

    Boton *tablero75 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero75, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero75);
    imagen++;
    i = i+101;

    Boton *tablero76 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero76, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero76);
    imagen++;
    i = i+101;

    Boton *tablero77 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero77, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero77);
    imagen++;
    i = i+101;

    Boton *tablero78 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero78, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero78);
    imagen++;
    i = i+101;

    Boton *tablero79 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero79, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero79);
    imagen++;
    i = i+101;

    Boton *tablero80 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero80, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero80);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero81 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero81, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero81);
    imagen++;
    i = i+101;

    Boton *tablero82 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero82, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero82);
    imagen++;
    i = i+101;

    Boton *tablero83 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero83, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero83);
    imagen++;
    i = i+101;

    Boton *tablero84 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero84, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero84);
    imagen++;
    i = i+101;

    Boton *tablero85 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero85, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero85);
    imagen++;
    i = i+101;

    Boton *tablero86 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero86, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero86);
    imagen++;
    i = i+101;

    Boton *tablero87 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero87, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero87);
    imagen++;
    i = i+101;

    Boton *tablero88 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero88, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero88);
    imagen++;
    i = i+101;

    Boton *tablero89 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero89, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero89);
    imagen++;
    i = i+101;

    Boton *tablero90 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero90, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero90);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero91 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero91, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero91);
    imagen++;
    i = i+101;

    Boton *tablero92 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero92, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero92);
    imagen++;
    i = i+101;

    Boton *tablero93 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero93, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero93);
    imagen++;
    i = i+101;

    Boton *tablero94 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero94, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero94);
    imagen++;
    i = i+101;

    Boton *tablero95 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero95, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero95);
    imagen++;
    i = i+101;

    Boton *tablero96 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero96, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero96);
    imagen++;
    i = i+101;

    Boton *tablero97 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero97, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero97);
    imagen++;
    i = i+101;

    Boton *tablero98 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero98, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero98);
    imagen++;
    i = i+101;

    Boton *tablero99 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero99, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero99);
    imagen++;
    i = i+101;

    Boton *tablero100 = new Boton(this->cartas.elements[imagen]->getNombre(),i,j);
    connect(tablero100, SIGNAL(clicked()), this, SLOT(IniciarJuego()));
    scene->addItem(tablero100);
}

////////////////////////////////Metodos Generales////////////////////////////////////////////////////////////////////
void Controladora::Scena()
{
    //Crea un escenario
    scene = new QGraphicsScene();
    scene->setSceneRect(0,0,1470,950);
    scene->setBackgroundBrush(Qt::blue);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setFixedSize(1470,950);
    scene->setBackgroundBrush(QBrush(QImage(":/img/f.png"))); //Cambia el fondo de la scena
    setScene(scene);
}
void Controladora::CargarImagen(int i, int j)
{
    //Crea una imagen
    Imagen *imagen = new Imagen(":/img/2_of_diamonds.png");
    imagen->setPos(i,j);
    //imagen->setScale(0);
    //imagen->setRotation(0);
    scene->addItem(imagen);
    //scene->removeItem(imagen);//remueve el elemento
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////Metodos SLOT/////////////////////////////////////////////////////////////////////////////////
void Controladora::clean()
{
    //Limpia la scena
    scene->clear();
}

void Controladora::IniciarJuego()
{
    scene->clear();
    // Aqui se llaman los METODOS para crear cartas, el maso, los jugadores
    // y poner a ejecutar el juego o iniciarlo junto con todos los componenes que tiene
}

void Controladora::getPosicion(QString nombre)
{
    int i = 0;
    int pos;

    while(i<this->cartas.getSize())
    {
        if(nombre==(this->cartas.elements[i]->getNombre()))
        {
            pos = i;
            break;
        }
        else i++;
    }

    cout << pos;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*void Controladora::agregarTablero()
{
    for(int j=20;j<720;j=j+70){
            for(int i=200;i<1210;i=i+101){
                CargarImagen(i,j);
            }
        }
}*/
