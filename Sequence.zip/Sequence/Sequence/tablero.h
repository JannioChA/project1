#ifndef TABLERO_H
#define TABLERO_H


class Tablero
{
public:
    Tablero();
};

#endif // TABLERO_H