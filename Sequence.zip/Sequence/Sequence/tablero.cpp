#include "tablero.h"

Tablero::Tablero()
{

}
