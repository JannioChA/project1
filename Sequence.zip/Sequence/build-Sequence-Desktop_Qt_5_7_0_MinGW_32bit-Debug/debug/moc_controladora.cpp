/****************************************************************************
** Meta object code from reading C++ file 'controladora.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Sequence/controladora.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'controladora.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Controladora_t {
    QByteArrayData data[111];
    char stringdata0[914];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Controladora_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Controladora_t qt_meta_stringdata_Controladora = {
    {
QT_MOC_LITERAL(0, 0, 12), // "Controladora"
QT_MOC_LITERAL(1, 13, 5), // "clean"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 12), // "tipoTablero2"
QT_MOC_LITERAL(4, 33, 12), // "tipoTablero3"
QT_MOC_LITERAL(5, 46, 12), // "tipoTablero4"
QT_MOC_LITERAL(6, 59, 12), // "IniciarJuego"
QT_MOC_LITERAL(7, 72, 13), // "tableroNormal"
QT_MOC_LITERAL(8, 86, 16), // "tableroAleatorio"
QT_MOC_LITERAL(9, 103, 9), // "setImagen"
QT_MOC_LITERAL(10, 113, 6), // "click1"
QT_MOC_LITERAL(11, 120, 6), // "click2"
QT_MOC_LITERAL(12, 127, 6), // "click3"
QT_MOC_LITERAL(13, 134, 6), // "click4"
QT_MOC_LITERAL(14, 141, 6), // "click5"
QT_MOC_LITERAL(15, 148, 6), // "click6"
QT_MOC_LITERAL(16, 155, 6), // "click7"
QT_MOC_LITERAL(17, 162, 6), // "click8"
QT_MOC_LITERAL(18, 169, 6), // "click9"
QT_MOC_LITERAL(19, 176, 7), // "click10"
QT_MOC_LITERAL(20, 184, 7), // "click11"
QT_MOC_LITERAL(21, 192, 7), // "click12"
QT_MOC_LITERAL(22, 200, 7), // "click13"
QT_MOC_LITERAL(23, 208, 7), // "click14"
QT_MOC_LITERAL(24, 216, 7), // "click15"
QT_MOC_LITERAL(25, 224, 7), // "click16"
QT_MOC_LITERAL(26, 232, 7), // "click17"
QT_MOC_LITERAL(27, 240, 7), // "click18"
QT_MOC_LITERAL(28, 248, 7), // "click19"
QT_MOC_LITERAL(29, 256, 7), // "click20"
QT_MOC_LITERAL(30, 264, 7), // "click21"
QT_MOC_LITERAL(31, 272, 7), // "click22"
QT_MOC_LITERAL(32, 280, 7), // "click23"
QT_MOC_LITERAL(33, 288, 7), // "click24"
QT_MOC_LITERAL(34, 296, 7), // "click25"
QT_MOC_LITERAL(35, 304, 7), // "click26"
QT_MOC_LITERAL(36, 312, 7), // "click27"
QT_MOC_LITERAL(37, 320, 7), // "click28"
QT_MOC_LITERAL(38, 328, 7), // "click29"
QT_MOC_LITERAL(39, 336, 7), // "click30"
QT_MOC_LITERAL(40, 344, 7), // "click31"
QT_MOC_LITERAL(41, 352, 7), // "click32"
QT_MOC_LITERAL(42, 360, 7), // "click33"
QT_MOC_LITERAL(43, 368, 7), // "click34"
QT_MOC_LITERAL(44, 376, 7), // "click35"
QT_MOC_LITERAL(45, 384, 7), // "click36"
QT_MOC_LITERAL(46, 392, 7), // "click37"
QT_MOC_LITERAL(47, 400, 7), // "click38"
QT_MOC_LITERAL(48, 408, 7), // "click39"
QT_MOC_LITERAL(49, 416, 7), // "click40"
QT_MOC_LITERAL(50, 424, 7), // "click41"
QT_MOC_LITERAL(51, 432, 7), // "click42"
QT_MOC_LITERAL(52, 440, 7), // "click43"
QT_MOC_LITERAL(53, 448, 7), // "click44"
QT_MOC_LITERAL(54, 456, 7), // "click45"
QT_MOC_LITERAL(55, 464, 7), // "click46"
QT_MOC_LITERAL(56, 472, 7), // "click47"
QT_MOC_LITERAL(57, 480, 7), // "click48"
QT_MOC_LITERAL(58, 488, 7), // "click49"
QT_MOC_LITERAL(59, 496, 7), // "click50"
QT_MOC_LITERAL(60, 504, 7), // "click51"
QT_MOC_LITERAL(61, 512, 7), // "click52"
QT_MOC_LITERAL(62, 520, 7), // "click53"
QT_MOC_LITERAL(63, 528, 7), // "click54"
QT_MOC_LITERAL(64, 536, 7), // "click55"
QT_MOC_LITERAL(65, 544, 7), // "click56"
QT_MOC_LITERAL(66, 552, 7), // "click57"
QT_MOC_LITERAL(67, 560, 7), // "click58"
QT_MOC_LITERAL(68, 568, 7), // "click59"
QT_MOC_LITERAL(69, 576, 7), // "click60"
QT_MOC_LITERAL(70, 584, 7), // "click61"
QT_MOC_LITERAL(71, 592, 7), // "click62"
QT_MOC_LITERAL(72, 600, 7), // "click63"
QT_MOC_LITERAL(73, 608, 7), // "click64"
QT_MOC_LITERAL(74, 616, 7), // "click65"
QT_MOC_LITERAL(75, 624, 7), // "click66"
QT_MOC_LITERAL(76, 632, 7), // "click67"
QT_MOC_LITERAL(77, 640, 7), // "click68"
QT_MOC_LITERAL(78, 648, 7), // "click69"
QT_MOC_LITERAL(79, 656, 7), // "click70"
QT_MOC_LITERAL(80, 664, 7), // "click71"
QT_MOC_LITERAL(81, 672, 7), // "click72"
QT_MOC_LITERAL(82, 680, 7), // "click73"
QT_MOC_LITERAL(83, 688, 7), // "click74"
QT_MOC_LITERAL(84, 696, 7), // "click75"
QT_MOC_LITERAL(85, 704, 7), // "click76"
QT_MOC_LITERAL(86, 712, 7), // "click77"
QT_MOC_LITERAL(87, 720, 7), // "click78"
QT_MOC_LITERAL(88, 728, 7), // "click79"
QT_MOC_LITERAL(89, 736, 7), // "click80"
QT_MOC_LITERAL(90, 744, 7), // "click81"
QT_MOC_LITERAL(91, 752, 7), // "click82"
QT_MOC_LITERAL(92, 760, 7), // "click83"
QT_MOC_LITERAL(93, 768, 7), // "click84"
QT_MOC_LITERAL(94, 776, 7), // "click85"
QT_MOC_LITERAL(95, 784, 7), // "click86"
QT_MOC_LITERAL(96, 792, 7), // "click87"
QT_MOC_LITERAL(97, 800, 7), // "click88"
QT_MOC_LITERAL(98, 808, 7), // "click89"
QT_MOC_LITERAL(99, 816, 7), // "click90"
QT_MOC_LITERAL(100, 824, 7), // "click91"
QT_MOC_LITERAL(101, 832, 7), // "click92"
QT_MOC_LITERAL(102, 840, 7), // "click93"
QT_MOC_LITERAL(103, 848, 7), // "click94"
QT_MOC_LITERAL(104, 856, 7), // "click95"
QT_MOC_LITERAL(105, 864, 7), // "click96"
QT_MOC_LITERAL(106, 872, 7), // "click97"
QT_MOC_LITERAL(107, 880, 7), // "click98"
QT_MOC_LITERAL(108, 888, 7), // "click99"
QT_MOC_LITERAL(109, 896, 8), // "click100"
QT_MOC_LITERAL(110, 905, 8) // "imprimir"

    },
    "Controladora\0clean\0\0tipoTablero2\0"
    "tipoTablero3\0tipoTablero4\0IniciarJuego\0"
    "tableroNormal\0tableroAleatorio\0setImagen\0"
    "click1\0click2\0click3\0click4\0click5\0"
    "click6\0click7\0click8\0click9\0click10\0"
    "click11\0click12\0click13\0click14\0click15\0"
    "click16\0click17\0click18\0click19\0click20\0"
    "click21\0click22\0click23\0click24\0click25\0"
    "click26\0click27\0click28\0click29\0click30\0"
    "click31\0click32\0click33\0click34\0click35\0"
    "click36\0click37\0click38\0click39\0click40\0"
    "click41\0click42\0click43\0click44\0click45\0"
    "click46\0click47\0click48\0click49\0click50\0"
    "click51\0click52\0click53\0click54\0click55\0"
    "click56\0click57\0click58\0click59\0click60\0"
    "click61\0click62\0click63\0click64\0click65\0"
    "click66\0click67\0click68\0click69\0click70\0"
    "click71\0click72\0click73\0click74\0click75\0"
    "click76\0click77\0click78\0click79\0click80\0"
    "click81\0click82\0click83\0click84\0click85\0"
    "click86\0click87\0click88\0click89\0click90\0"
    "click91\0click92\0click93\0click94\0click95\0"
    "click96\0click97\0click98\0click99\0"
    "click100\0imprimir"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Controladora[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
     109,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  559,    2, 0x0a /* Public */,
       3,    0,  560,    2, 0x0a /* Public */,
       4,    0,  561,    2, 0x0a /* Public */,
       5,    0,  562,    2, 0x0a /* Public */,
       6,    0,  563,    2, 0x0a /* Public */,
       7,    0,  564,    2, 0x0a /* Public */,
       8,    0,  565,    2, 0x0a /* Public */,
       9,    1,  566,    2, 0x0a /* Public */,
      10,    0,  569,    2, 0x0a /* Public */,
      11,    0,  570,    2, 0x0a /* Public */,
      12,    0,  571,    2, 0x0a /* Public */,
      13,    0,  572,    2, 0x0a /* Public */,
      14,    0,  573,    2, 0x0a /* Public */,
      15,    0,  574,    2, 0x0a /* Public */,
      16,    0,  575,    2, 0x0a /* Public */,
      17,    0,  576,    2, 0x0a /* Public */,
      18,    0,  577,    2, 0x0a /* Public */,
      19,    0,  578,    2, 0x0a /* Public */,
      20,    0,  579,    2, 0x0a /* Public */,
      21,    0,  580,    2, 0x0a /* Public */,
      22,    0,  581,    2, 0x0a /* Public */,
      23,    0,  582,    2, 0x0a /* Public */,
      24,    0,  583,    2, 0x0a /* Public */,
      25,    0,  584,    2, 0x0a /* Public */,
      26,    0,  585,    2, 0x0a /* Public */,
      27,    0,  586,    2, 0x0a /* Public */,
      28,    0,  587,    2, 0x0a /* Public */,
      29,    0,  588,    2, 0x0a /* Public */,
      30,    0,  589,    2, 0x0a /* Public */,
      31,    0,  590,    2, 0x0a /* Public */,
      32,    0,  591,    2, 0x0a /* Public */,
      33,    0,  592,    2, 0x0a /* Public */,
      34,    0,  593,    2, 0x0a /* Public */,
      35,    0,  594,    2, 0x0a /* Public */,
      36,    0,  595,    2, 0x0a /* Public */,
      37,    0,  596,    2, 0x0a /* Public */,
      38,    0,  597,    2, 0x0a /* Public */,
      39,    0,  598,    2, 0x0a /* Public */,
      40,    0,  599,    2, 0x0a /* Public */,
      41,    0,  600,    2, 0x0a /* Public */,
      42,    0,  601,    2, 0x0a /* Public */,
      43,    0,  602,    2, 0x0a /* Public */,
      44,    0,  603,    2, 0x0a /* Public */,
      45,    0,  604,    2, 0x0a /* Public */,
      46,    0,  605,    2, 0x0a /* Public */,
      47,    0,  606,    2, 0x0a /* Public */,
      48,    0,  607,    2, 0x0a /* Public */,
      49,    0,  608,    2, 0x0a /* Public */,
      50,    0,  609,    2, 0x0a /* Public */,
      51,    0,  610,    2, 0x0a /* Public */,
      52,    0,  611,    2, 0x0a /* Public */,
      53,    0,  612,    2, 0x0a /* Public */,
      54,    0,  613,    2, 0x0a /* Public */,
      55,    0,  614,    2, 0x0a /* Public */,
      56,    0,  615,    2, 0x0a /* Public */,
      57,    0,  616,    2, 0x0a /* Public */,
      58,    0,  617,    2, 0x0a /* Public */,
      59,    0,  618,    2, 0x0a /* Public */,
      60,    0,  619,    2, 0x0a /* Public */,
      61,    0,  620,    2, 0x0a /* Public */,
      62,    0,  621,    2, 0x0a /* Public */,
      63,    0,  622,    2, 0x0a /* Public */,
      64,    0,  623,    2, 0x0a /* Public */,
      65,    0,  624,    2, 0x0a /* Public */,
      66,    0,  625,    2, 0x0a /* Public */,
      67,    0,  626,    2, 0x0a /* Public */,
      68,    0,  627,    2, 0x0a /* Public */,
      69,    0,  628,    2, 0x0a /* Public */,
      70,    0,  629,    2, 0x0a /* Public */,
      71,    0,  630,    2, 0x0a /* Public */,
      72,    0,  631,    2, 0x0a /* Public */,
      73,    0,  632,    2, 0x0a /* Public */,
      74,    0,  633,    2, 0x0a /* Public */,
      75,    0,  634,    2, 0x0a /* Public */,
      76,    0,  635,    2, 0x0a /* Public */,
      77,    0,  636,    2, 0x0a /* Public */,
      78,    0,  637,    2, 0x0a /* Public */,
      79,    0,  638,    2, 0x0a /* Public */,
      80,    0,  639,    2, 0x0a /* Public */,
      81,    0,  640,    2, 0x0a /* Public */,
      82,    0,  641,    2, 0x0a /* Public */,
      83,    0,  642,    2, 0x0a /* Public */,
      84,    0,  643,    2, 0x0a /* Public */,
      85,    0,  644,    2, 0x0a /* Public */,
      86,    0,  645,    2, 0x0a /* Public */,
      87,    0,  646,    2, 0x0a /* Public */,
      88,    0,  647,    2, 0x0a /* Public */,
      89,    0,  648,    2, 0x0a /* Public */,
      90,    0,  649,    2, 0x0a /* Public */,
      91,    0,  650,    2, 0x0a /* Public */,
      92,    0,  651,    2, 0x0a /* Public */,
      93,    0,  652,    2, 0x0a /* Public */,
      94,    0,  653,    2, 0x0a /* Public */,
      95,    0,  654,    2, 0x0a /* Public */,
      96,    0,  655,    2, 0x0a /* Public */,
      97,    0,  656,    2, 0x0a /* Public */,
      98,    0,  657,    2, 0x0a /* Public */,
      99,    0,  658,    2, 0x0a /* Public */,
     100,    0,  659,    2, 0x0a /* Public */,
     101,    0,  660,    2, 0x0a /* Public */,
     102,    0,  661,    2, 0x0a /* Public */,
     103,    0,  662,    2, 0x0a /* Public */,
     104,    0,  663,    2, 0x0a /* Public */,
     105,    0,  664,    2, 0x0a /* Public */,
     106,    0,  665,    2, 0x0a /* Public */,
     107,    0,  666,    2, 0x0a /* Public */,
     108,    0,  667,    2, 0x0a /* Public */,
     109,    0,  668,    2, 0x0a /* Public */,
     110,    0,  669,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Controladora::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Controladora *_t = static_cast<Controladora *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->clean(); break;
        case 1: _t->tipoTablero2(); break;
        case 2: _t->tipoTablero3(); break;
        case 3: _t->tipoTablero4(); break;
        case 4: _t->IniciarJuego(); break;
        case 5: _t->tableroNormal(); break;
        case 6: _t->tableroAleatorio(); break;
        case 7: _t->setImagen((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->click1(); break;
        case 9: _t->click2(); break;
        case 10: _t->click3(); break;
        case 11: _t->click4(); break;
        case 12: _t->click5(); break;
        case 13: _t->click6(); break;
        case 14: _t->click7(); break;
        case 15: _t->click8(); break;
        case 16: _t->click9(); break;
        case 17: _t->click10(); break;
        case 18: _t->click11(); break;
        case 19: _t->click12(); break;
        case 20: _t->click13(); break;
        case 21: _t->click14(); break;
        case 22: _t->click15(); break;
        case 23: _t->click16(); break;
        case 24: _t->click17(); break;
        case 25: _t->click18(); break;
        case 26: _t->click19(); break;
        case 27: _t->click20(); break;
        case 28: _t->click21(); break;
        case 29: _t->click22(); break;
        case 30: _t->click23(); break;
        case 31: _t->click24(); break;
        case 32: _t->click25(); break;
        case 33: _t->click26(); break;
        case 34: _t->click27(); break;
        case 35: _t->click28(); break;
        case 36: _t->click29(); break;
        case 37: _t->click30(); break;
        case 38: _t->click31(); break;
        case 39: _t->click32(); break;
        case 40: _t->click33(); break;
        case 41: _t->click34(); break;
        case 42: _t->click35(); break;
        case 43: _t->click36(); break;
        case 44: _t->click37(); break;
        case 45: _t->click38(); break;
        case 46: _t->click39(); break;
        case 47: _t->click40(); break;
        case 48: _t->click41(); break;
        case 49: _t->click42(); break;
        case 50: _t->click43(); break;
        case 51: _t->click44(); break;
        case 52: _t->click45(); break;
        case 53: _t->click46(); break;
        case 54: _t->click47(); break;
        case 55: _t->click48(); break;
        case 56: _t->click49(); break;
        case 57: _t->click50(); break;
        case 58: _t->click51(); break;
        case 59: _t->click52(); break;
        case 60: _t->click53(); break;
        case 61: _t->click54(); break;
        case 62: _t->click55(); break;
        case 63: _t->click56(); break;
        case 64: _t->click57(); break;
        case 65: _t->click58(); break;
        case 66: _t->click59(); break;
        case 67: _t->click60(); break;
        case 68: _t->click61(); break;
        case 69: _t->click62(); break;
        case 70: _t->click63(); break;
        case 71: _t->click64(); break;
        case 72: _t->click65(); break;
        case 73: _t->click66(); break;
        case 74: _t->click67(); break;
        case 75: _t->click68(); break;
        case 76: _t->click69(); break;
        case 77: _t->click70(); break;
        case 78: _t->click71(); break;
        case 79: _t->click72(); break;
        case 80: _t->click73(); break;
        case 81: _t->click74(); break;
        case 82: _t->click75(); break;
        case 83: _t->click76(); break;
        case 84: _t->click77(); break;
        case 85: _t->click78(); break;
        case 86: _t->click79(); break;
        case 87: _t->click80(); break;
        case 88: _t->click81(); break;
        case 89: _t->click82(); break;
        case 90: _t->click83(); break;
        case 91: _t->click84(); break;
        case 92: _t->click85(); break;
        case 93: _t->click86(); break;
        case 94: _t->click87(); break;
        case 95: _t->click88(); break;
        case 96: _t->click89(); break;
        case 97: _t->click90(); break;
        case 98: _t->click91(); break;
        case 99: _t->click92(); break;
        case 100: _t->click93(); break;
        case 101: _t->click94(); break;
        case 102: _t->click95(); break;
        case 103: _t->click96(); break;
        case 104: _t->click97(); break;
        case 105: _t->click98(); break;
        case 106: _t->click99(); break;
        case 107: _t->click100(); break;
        case 108: _t->imprimir(); break;
        default: ;
        }
    }
}

const QMetaObject Controladora::staticMetaObject = {
    { &QGraphicsView::staticMetaObject, qt_meta_stringdata_Controladora.data,
      qt_meta_data_Controladora,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Controladora::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Controladora::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Controladora.stringdata0))
        return static_cast<void*>(const_cast< Controladora*>(this));
    return QGraphicsView::qt_metacast(_clname);
}

int Controladora::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 109)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 109;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 109)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 109;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
