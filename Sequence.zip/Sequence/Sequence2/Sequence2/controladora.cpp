#include <time.h>
#include "controladora.h"
#include "imagen.h"
#include "boton.h"
#include "carta.h"
#include "jugador.h"
#include "arraylist.h"
#include "carraylist.h"
#include "arraystack.h"

QString imagen;

Controladora::Controladora()
{
    this->xActual=0;
    this->yActual=0;
    this->manoClickeada=0;
    Scena();
    this->cartas = new ArrayList<Carta*>(96);
    this->baraja = new ArrayStack<Carta*>(104);
    this->jugadores = new CArrayList<Jugador*>(4);
    creaListaCartas();
    creaBaraja();
    menuInicio();
    //CargarImagen();
    //x->hide();//Esconde las cosas
}

ArrayList<Carta*>* Controladora::getCartas(){return this->cartas;}

void Controladora::Scena()
{
    //Crea un escenario
    scene = new QGraphicsScene();
    scene->setSceneRect(0,0,1470,950);
    scene->setBackgroundBrush(Qt::blue);
    setFixedSize(1470,950);
    scene->setBackgroundBrush(QBrush(QImage(":/img/f.png"))); //Cambia el fondo de la scena
    setScene(scene);
}

void Controladora::CargarImagen(int i,int j,QString ubicacion)
{
    //Crea una imagen
    Imagen *imagen = new Imagen(ubicacion);
    imagen->setPos(i,j);
    //imagen->setScale(0);
    //imagen->setRotation(0);
    scene->addItem(imagen);
    //scene->removeItem(imagen);//remueve el elemento
}

void Controladora::creaBaraja()
{
    for(int i = 0; i < this->cartas->getSize(); i++) {this->baraja->push(this->cartas->elements[i]);}

    baraja->push(new Carta (":/img/jack_of_clubs2.png"));    baraja->push(new Carta (":/img/jack_of_diamonds2.png"));
    baraja->push(new Carta (":/img/jack_of_hearts2.png"));   baraja->push(new Carta (":/img/jack_of_spades2.png"));
    baraja->push(new Carta (":/img/jack_of_clubs2.png"));    baraja->push(new Carta (":/img/jack_of_diamonds2.png"));
    baraja->push(new Carta (":/img/jack_of_hearts2.png"));   baraja->push(new Carta (":/img/jack_of_spades2.png"));
    this->baraja = barajarBaraja(this->baraja);
}

void Controladora::creaListaCartas()
{
    //cout << "Index";
    this->cartas->append(new Carta (":/img/ace_of_clubs.png"));      this->cartas->append(new Carta (":/img/king_of_clubs.png"));
    this->cartas->append(new Carta (":/img/queen_of_clubs.png"));    this->cartas->append(new Carta (":/img/10_of_clubs.png"));
    this->cartas->append(new Carta (":/img/9_of_clubs.png"));        this->cartas->append(new Carta (":/img/8_of_clubs.png"));
    this->cartas->append(new Carta (":/img/7_of_clubs.png"));        this->cartas->append(new Carta (":/img/6_of_clubs.png"));
    this->cartas->append(new Carta (":/img/ace_of_diamonds.png"));   this->cartas->append(new Carta (":/img/7_of_spades.png"));
    this->cartas->append(new Carta (":/img/8_of_spades.png"));       this->cartas->append(new Carta (":/img/9_of_spades.png"));
    this->cartas->append(new Carta (":/img/10_of_spades.png"));      this->cartas->append(new Carta (":/img/queen_of_spades.png"));
    this->cartas->append(new Carta (":/img/king_of_spades.png"));    this->cartas->append(new Carta (":/img/ace_of_spades.png"));
    this->cartas->append(new Carta (":/img/5_of_clubs.png"));        this->cartas->append(new Carta (":/img/2_of_spades.png"));
    this->cartas->append(new Carta (":/img/king_of_diamonds.png"));  this->cartas->append(new Carta (":/img/6_of_spades.png"));
    this->cartas->append(new Carta (":/img/10_of_clubs.png"));       this->cartas->append(new Carta (":/img/9_of_clubs.png"));
    this->cartas->append(new Carta (":/img/8_of_clubs.png"));        this->cartas->append(new Carta (":/img/7_of_clubs.png"));
    this->cartas->append(new Carta (":/img/6_of_clubs.png"));        this->cartas->append(new Carta (":/img/2_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/4_of_clubs.png"));        this->cartas->append(new Carta (":/img/3_of_spades.png"));
    this->cartas->append(new Carta (":/img/queen_of_diamonds.png")); this->cartas->append(new Carta (":/img/5_of_spades.png"));
    this->cartas->append(new Carta (":/img/queen_of_clubs.png"));    this->cartas->append(new Carta (":/img/8_of_hearts.png"));
    this->cartas->append(new Carta (":/img/7_of_hearts.png"));       this->cartas->append(new Carta (":/img/6_of_hearts.png"));
    this->cartas->append(new Carta (":/img/5_of_clubs.png"));        this->cartas->append(new Carta (":/img/3_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/3_of_clubs.png"));        this->cartas->append(new Carta (":/img/4_of_spades.png"));
    this->cartas->append(new Carta (":/img/10_of_diamonds.png"));    this->cartas->append(new Carta (":/img/4_of_spades.png"));
    this->cartas->append(new Carta (":/img/king_of_clubs.png"));     this->cartas->append(new Carta (":/img/9_of_hearts.png"));
    this->cartas->append(new Carta (":/img/2_of_hearts.png"));       this->cartas->append(new Carta (":/img/5_of_hearts.png"));
    this->cartas->append(new Carta (":/img/4_of_clubs.png"));        this->cartas->append(new Carta (":/img/4_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/2_of_clubs.png"));        this->cartas->append(new Carta (":/img/5_of_spades.png"));
    this->cartas->append(new Carta (":/img/9_of_diamonds.png"));     this->cartas->append(new Carta (":/img/3_of_spades.png"));
    this->cartas->append(new Carta (":/img/ace_of_clubs.png"));      this->cartas->append(new Carta (":/img/10_of_hearts.png"));
    this->cartas->append(new Carta (":/img/3_of_hearts.png"));       this->cartas->append(new Carta (":/img/4_of_hearts.png"));
    this->cartas->append(new Carta (":/img/3_of_clubs.png"));        this->cartas->append(new Carta (":/img/5_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/ace_of_hearts.png"));     this->cartas->append(new Carta (":/img/6_of_spades.png"));
    this->cartas->append(new Carta (":/img/8_of_diamonds.png"));     this->cartas->append(new Carta (":/img/2_of_spades.png"));
    this->cartas->append(new Carta (":/img/ace_of_diamonds.png"));   this->cartas->append(new Carta (":/img/queen_of_hearts.png"));
    this->cartas->append(new Carta (":/img/king_of_hearts.png"));    this->cartas->append(new Carta (":/img/ace_of_hearts.png"));
    this->cartas->append(new Carta (":/img/2_of_clubs.png"));        this->cartas->append(new Carta (":/img/6_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/king_of_hearts.png"));    this->cartas->append(new Carta (":/img/7_of_spades.png"));
    this->cartas->append(new Carta (":/img/7_of_diamonds.png"));     this->cartas->append(new Carta (":/img/2_of_hearts.png"));
    this->cartas->append(new Carta (":/img/king_of_diamonds.png"));  this->cartas->append(new Carta (":/img/queen_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/10_of_diamonds.png"));    this->cartas->append(new Carta (":/img/9_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/8_of_diamonds.png"));     this->cartas->append(new Carta (":/img/7_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/queen_of_hearts.png"));   this->cartas->append(new Carta (":/img/8_of_spades.png"));
    this->cartas->append(new Carta (":/img/6_of_diamonds.png"));     this->cartas->append(new Carta (":/img/3_of_hearts.png"));
    this->cartas->append(new Carta (":/img/4_of_hearts.png"));       this->cartas->append(new Carta (":/img/5_of_hearts.png"));
    this->cartas->append(new Carta (":/img/6_of_hearts.png"));       this->cartas->append(new Carta (":/img/7_of_hearts.png"));
    this->cartas->append(new Carta (":/img/8_of_hearts.png"));       this->cartas->append(new Carta (":/img/9_of_hearts.png"));
    this->cartas->append(new Carta (":/img/10_of_hearts.png"));      this->cartas->append(new Carta (":/img/9_of_spades.png"));
    this->cartas->append(new Carta (":/img/5_of_diamonds.png"));     this->cartas->append(new Carta (":/img/4_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/3_of_diamonds.png"));     this->cartas->append(new Carta (":/img/2_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/ace_of_spades.png"));     this->cartas->append(new Carta (":/img/king_of_spades.png"));
    this->cartas->append(new Carta (":/img/queen_of_spades.png"));   this->cartas->append(new Carta (":/img/10_of_spades.png"));
    //this->cartas = cartas;
}

void Controladora::menuInicio()
{
    Boton *boton_2_Jugadores = new Boton(":/img/botonJugador.png",100,400);
    connect(boton_2_Jugadores, SIGNAL(clicked()), this, SLOT(tablero_2_Jugadores()));
    scene->addItem(boton_2_Jugadores);

    Boton *boton_3_Jugadores = new Boton(":/img/botonJugador.png",500,400);
    connect(boton_3_Jugadores, SIGNAL(clicked()), this, SLOT(tipoTablero3()));
    scene->addItem(boton_3_Jugadores);

    Boton *boton_4_Jugadores = new Boton(":/img/botonJugador.png",900,400);
    connect(boton_4_Jugadores, SIGNAL(clicked()), this, SLOT(tipoTablero4()));
    scene->addItem(boton_4_Jugadores);
}

void Controladora::creaManoJugador()
{
    if(this->numeroJugadores < 4)
    {
        this->cartaMano_1 = new Boton(this->jugadores->elements[0]->mano->elements[0]->getNombre(),460,800);
        connect(cartaMano_1, SIGNAL(clicked()), this, SLOT(mano1()));
        cartaMano_1->setRotation(90);
        scene->addItem(cartaMano_1);

        this->cartaMano_2 = new Boton(this->jugadores->elements[0]->mano->elements[1]->getNombre(),560,800);
        connect(cartaMano_2, SIGNAL(clicked()), this, SLOT(mano2()));
        cartaMano_2->setRotation(90);
        scene->addItem(cartaMano_2);

        this->cartaMano_3 = new Boton(this->jugadores->elements[0]->mano->elements[2]->getNombre(),660,800);
        connect(cartaMano_3, SIGNAL(clicked()), this, SLOT(mano3()));
        cartaMano_3->setRotation(90);
        scene->addItem(cartaMano_3);

        this->cartaMano_4 = new Boton(this->jugadores->elements[0]->mano->elements[3]->getNombre(),760,800);
        connect(cartaMano_4, SIGNAL(clicked()), this, SLOT(mano4()));
        cartaMano_4->setRotation(90);
        scene->addItem(cartaMano_4);

        this->cartaMano_5 = new Boton(this->jugadores->elements[0]->mano->elements[4]->getNombre(),860,800);
        connect(cartaMano_5, SIGNAL(clicked()), this, SLOT(mano5()));
        cartaMano_5->setRotation(90);
        scene->addItem(cartaMano_5);

        this->cartaMano_6 = new Boton(this->jugadores->elements[0]->mano->elements[5]->getNombre(),960,800);
        connect(cartaMano_6, SIGNAL(clicked()), this, SLOT(mano6()));
        cartaMano_6->setRotation(90);
        scene->addItem(cartaMano_6);

        this->cartaMano_7 = new Boton(this->jugadores->elements[0]->mano->elements[6]->getNombre(),1060,800);
        connect(cartaMano_7, SIGNAL(clicked()), this, SLOT(mano7()));
        cartaMano_7->setRotation(90);
        scene->addItem(cartaMano_7);
    }
    else
    {
        this->cartaMano_1 = new Boton(this->jugadores->elements[0]->mano->elements[0]->getNombre(),510,800);
        connect(cartaMano_1, SIGNAL(clicked()), this, SLOT(mano1()));
        cartaMano_1->setRotation(90);
        scene->addItem(cartaMano_1);

        this->cartaMano_2 = new Boton(this->jugadores->elements[0]->mano->elements[1]->getNombre(),610,800);
        connect(cartaMano_2, SIGNAL(clicked()), this, SLOT(mano2()));
        cartaMano_2->setRotation(90);
        scene->addItem(cartaMano_2);

        this->cartaMano_3 = new Boton(this->jugadores->elements[0]->mano->elements[2]->getNombre(),710,800);
        connect(cartaMano_3, SIGNAL(clicked()), this, SLOT(mano3()));
        cartaMano_3->setRotation(90);
        scene->addItem(cartaMano_3);

        this->cartaMano_4 = new Boton(this->jugadores->elements[0]->mano->elements[3]->getNombre(),810,800);
        connect(cartaMano_4, SIGNAL(clicked()), this, SLOT(mano4()));
        cartaMano_4->setRotation(90);
        scene->addItem(cartaMano_4);

        this->cartaMano_5 = new Boton(this->jugadores->elements[0]->mano->elements[4]->getNombre(),910,800);
        connect(cartaMano_5, SIGNAL(clicked()), this, SLOT(mano5()));
        cartaMano_5->setRotation(90);
        scene->addItem(cartaMano_5);

        this->cartaMano_6 = new Boton(this->jugadores->elements[0]->mano->elements[5]->getNombre(),1010,800);
        connect(cartaMano_6, SIGNAL(clicked()), this, SLOT(mano6()));
        cartaMano_6->setRotation(90);
        scene->addItem(cartaMano_6);
    }
}

void Controladora::setImagen(QString pImagen){imagen = pImagen;}

void Controladora::creaJugadores()
{
    for(int i=0;i<this->numeroJugadores;i++) {this->jugadores->append(new Jugador());}
    this->jugadores->goToStart();
}

void Controladora::reparteCartas()
{
    int numeroCartas;
    if(this->numeroJugadores < 4) {numeroCartas = 7;}
    else{numeroCartas = 6;}
    for(int i = 0; i < this->jugadores->getSize(); i++)
    {
        for (int j = 0; j < numeroCartas; j++){this->jugadores->elements[i]->mano->append(this->baraja->pop());}
    }
}

void Controladora::cargarMano()
{
    if(this->numeroJugadores<4)
    {
        this->cartaMano_1->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[0]->getNombre());
        this->cartaMano_2->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[1]->getNombre());
        this->cartaMano_3->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[2]->getNombre());
        this->cartaMano_4->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[3]->getNombre());
        this->cartaMano_5->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[4]->getNombre());
        this->cartaMano_6->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[5]->getNombre());
        this->cartaMano_7->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[6]->getNombre());
    }
    else
    {
        this->cartaMano_1->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[0]->getNombre());
        this->cartaMano_2->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[1]->getNombre());
        this->cartaMano_3->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[2]->getNombre());
        this->cartaMano_4->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[3]->getNombre());
        this->cartaMano_5->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[4]->getNombre());
        this->cartaMano_6->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[5]->getNombre());
    }
}

void Controladora::siguienteTurno()
{
    this->jugadores->next();
    cargarMano();
}

void Controladora::proximoPaso()
{
    if(this->manoClickeada != 0)
    {
        int colorFicha;
        if(this->numeroJugadores<4)
        {
            if(this->jugadores->getPos()==0)
            {
                colorFicha = 1;
            }
            if(this->jugadores->getPos()==1)
            {
                colorFicha = 2;
            }
            if(this->jugadores->getPos()==2)
            {
                colorFicha = 3;
            }
        }else
        {
            if(this->jugadores->getPos()==0)
            {
                colorFicha = 1;
            }
            if(this->jugadores->getPos()==1)
            {
                colorFicha =2;
            }
            if(this->jugadores->getPos()==2)
            {
                colorFicha = 1;
            }
            if(this->jugadores->getPos()==3)
            {
                colorFicha = 2;
            }
        }

        if(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]->getNombre()
                == this->cartas->elements[this->clickeado-1]->getNombre())
        {
            this->cartas->elements[this->clickeado-1]->setFichaPuesta(colorFicha);
            this->colocarFicha(colorFicha);
            this->siguienteTurno();
            this->manoClickeada=0;
        }
    }
}

void Controladora::colocarFicha(int pColor)
{
    QString color;
    if(pColor==1)
    {
        color = ":/img/fichaRoja.png";
    }else if(pColor==2)
    {
        color = ":/img/fichaAzul.png";
    }else if(pColor==3)
    {
        color = ":/img/fichaVerde.png";
    }
    CargarImagen(this->xActual,this->yActual,color);
}

ArrayStack<Carta*>* Controladora::barajarBaraja(ArrayStack<Carta*>* original)
{
    srand(time(NULL));
    barajaAleatoria = new ArrayStack<Carta*>(104);
    for(int i = 0; i < original->getSize(); i++){barajaAleatoria->push(original->elements[i]);}
    bool espacioUsado[104];
    for (int i=0;i<104;i++) {espacioUsado[i]=false;}
    int index=0;
    for (int i=0;i<104;i++)
    {
        do{index = 0 + rand() % (104 - 0);}
        while (espacioUsado[index]);
        barajaAleatoria->elements[i] = original->elements[index];
        espacioUsado[index]=true;
    }
    return barajaAleatoria;
}

ArrayList<Carta*>* Controladora::randomizarTablero(ArrayList<Carta*>* original)
{
    srand(time(NULL));
    tableroRandomizado = new ArrayList<Carta*>(96);
    for(int i = 0; i < original->getSize()-1; i++) {tableroRandomizado->append(original->elements[i]);}
    bool espacioUsado[96];
    for (int i=0;i<96;i++) {espacioUsado[i]=false;}
    int index=0;
    for (int i=0;i<96;i++)
    {
        do{index = 0 + rand() % (96 - 0);}
        while (espacioUsado[index]);
        tableroRandomizado->elements[i] = original->elements[index];
        espacioUsado[index]=true;
    }
    return tableroRandomizado;
}

void Controladora::creaTablero()
{
    int imagen = 0;
    int i = 220;
    int j = 20;
    Boton *tablero1 = new Boton(":/img/4esquinas.png",i,j);
    scene->addItem(tablero1);
    i = i+101;

    Boton *tablero2 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero2, SIGNAL(clicked()), this, SLOT(click1()));
    connect(tablero2, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero2);
    imagen++;
    i = i+101;

    Boton *tablero3 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero3, SIGNAL(clicked()), this, SLOT(click2()));
    connect(tablero3, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero3);
    imagen++;
    i = i+101;

    Boton *tablero4 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero4, SIGNAL(clicked()), this, SLOT(click3()));
    connect(tablero4, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero4);
    imagen++;
    i = i+101;

    Boton *tablero5 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero5, SIGNAL(clicked()), this, SLOT(click4()));
    connect(tablero5, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero5);
    imagen++;
    i = i+101;

    Boton *tablero6 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero6, SIGNAL(clicked()), this, SLOT(click5()));
    connect(tablero6, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero6);
    imagen++;
    i = i+101;

    Boton *tablero7 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero7, SIGNAL(clicked()), this, SLOT(click6()));
    connect(tablero7, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero7);
    imagen++;
    i = i+101;

    Boton *tablero8 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero8, SIGNAL(clicked()), this, SLOT(click7()));
    connect(tablero8, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero8);
    imagen++;
    i = i+101;

    Boton *tablero9 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero9, SIGNAL(clicked()), this, SLOT(click8()));
    connect(tablero9, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero9);
    imagen++;
    i = i+101;

    Boton *tablero10 = new Boton(":/img/4esquinas.png",i,j);
    scene->addItem(tablero10);
    i = 220;
    j = j+70;

    Boton *tablero11 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero11, SIGNAL(clicked()), this, SLOT(click9()));
    connect(tablero11, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero11);
    imagen++;
    i = i+101;

    Boton *tablero12 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero12, SIGNAL(clicked()), this, SLOT(click10()));
    connect(tablero12, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero12);
    imagen++;
    i = i+101;

    Boton *tablero13 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero13, SIGNAL(clicked()), this, SLOT(click11()));
    connect(tablero13, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero13);
    imagen++;
    i = i+101;

    Boton *tablero14 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero14, SIGNAL(clicked()), this, SLOT(click12()));
    connect(tablero14, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero14);
    imagen++;
    i = i+101;

    Boton *tablero15 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero15, SIGNAL(clicked()), this, SLOT(click13()));
    connect(tablero15, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero15);
    imagen++;
    i = i+101;

    Boton *tablero16 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero16, SIGNAL(clicked()), this, SLOT(click14()));
    connect(tablero16, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero16);
    imagen++;
    i = i+101;

    Boton *tablero17 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero17, SIGNAL(clicked()), this, SLOT(click15()));
    connect(tablero17, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero17);
    imagen++;
    i = i+101;

    Boton *tablero18 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero18, SIGNAL(clicked()), this, SLOT(click16()));
    connect(tablero18, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero18);
    imagen++;
    i = i+101;

    Boton *tablero19 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero19, SIGNAL(clicked()), this, SLOT(click17()));
    connect(tablero19, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero19);
    imagen++;
    i = i+101;

    Boton *tablero20 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero20, SIGNAL(clicked()), this, SLOT(click18()));
    connect(tablero20, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero20);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero21 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero21, SIGNAL(clicked()), this, SLOT(click19()));
    connect(tablero21, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero21);
    imagen++;
    i = i+101;

    Boton *tablero22 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero22, SIGNAL(clicked()), this, SLOT(click20()));
    connect(tablero22, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero22);
    imagen++;
    i = i+101;

    Boton *tablero23 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero23, SIGNAL(clicked()), this, SLOT(click21()));
    connect(tablero23, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero23);
    imagen++;
    i = i+101;

    Boton *tablero24 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero24, SIGNAL(clicked()), this, SLOT(click22()));
    connect(tablero24, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero24);
    imagen++;
    i = i+101;

    Boton *tablero25 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero25, SIGNAL(clicked()), this, SLOT(click23()));
    connect(tablero25, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero25);
    imagen++;
    i = i+101;

    Boton *tablero26 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero26, SIGNAL(clicked()), this, SLOT(click24()));
    connect(tablero26, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero26);
    imagen++;
    i = i+101;

    Boton *tablero27 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero27, SIGNAL(clicked()), this, SLOT(click25()));
    connect(tablero27, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero27);
    imagen++;
    i = i+101;

    Boton *tablero28 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero28, SIGNAL(clicked()), this, SLOT(click26()));
    connect(tablero28, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero28);
    imagen++;
    i = i+101;

    Boton *tablero29 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero29, SIGNAL(clicked()), this, SLOT(click27()));
    connect(tablero29, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero29);
    imagen++;
    i = i+101;

    Boton *tablero30 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero30, SIGNAL(clicked()), this, SLOT(click28()));
    connect(tablero30, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero30);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero31 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero31, SIGNAL(clicked()), this, SLOT(click29()));
    connect(tablero31, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero31);
    imagen++;
    i = i+101;

    Boton *tablero32 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero32, SIGNAL(clicked()), this, SLOT(click30()));
    connect(tablero32, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero32);
    imagen++;
    i = i+101;

    Boton *tablero33 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero33, SIGNAL(clicked()), this, SLOT(click31()));
    connect(tablero33, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero33);
    imagen++;
    i = i+101;

    Boton *tablero34 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero34, SIGNAL(clicked()), this, SLOT(click32()));
    connect(tablero34, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero34);
    imagen++;
    i = i+101;

    Boton *tablero35 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero35, SIGNAL(clicked()), this, SLOT(click33()));
    connect(tablero35, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero35);
    imagen++;
    i = i+101;

    Boton *tablero36 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero36, SIGNAL(clicked()), this, SLOT(click34()));
    connect(tablero36, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero36);
    imagen++;
    i = i+101;

    Boton *tablero37 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero37, SIGNAL(clicked()), this, SLOT(click35()));
    connect(tablero37, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero37);
    imagen++;
    i = i+101;

    Boton *tablero38 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero38, SIGNAL(clicked()), this, SLOT(click36()));
    connect(tablero38, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero38);
    imagen++;
    i = i+101;

    Boton *tablero39 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero39, SIGNAL(clicked()), this, SLOT(click37()));
    connect(tablero39, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero39);
    imagen++;
    i = i+101;

    Boton *tablero40 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero40, SIGNAL(clicked()), this, SLOT(click38()));
    connect(tablero40, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero40);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero41 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero41, SIGNAL(clicked()), this, SLOT(click39()));
    connect(tablero41, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero41);
    imagen++;
    i = i+101;

    Boton *tablero42 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero42, SIGNAL(clicked()), this, SLOT(click40()));
    connect(tablero42, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero42);
    imagen++;
    i = i+101;

    Boton *tablero43 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero43, SIGNAL(clicked()), this, SLOT(click41()));
    connect(tablero43, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero43);
    imagen++;
    i = i+101;

    Boton *tablero44 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero44, SIGNAL(clicked()), this, SLOT(click42()));
    connect(tablero44, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero44);
    imagen++;
    i = i+101;

    Boton *tablero45 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero45, SIGNAL(clicked()), this, SLOT(click43()));
    connect(tablero45, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero45);
    imagen++;
    i = i+101;

    Boton *tablero46 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero46, SIGNAL(clicked()), this, SLOT(click44()));
    connect(tablero46, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero46);
    imagen++;
    i = i+101;

    Boton *tablero47 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero47, SIGNAL(clicked()), this, SLOT(click45()));
    connect(tablero47, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero47);
    imagen++;
    i = i+101;

    Boton *tablero48 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero48, SIGNAL(clicked()), this, SLOT(click46()));
    connect(tablero48, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero48);
    imagen++;
    i = i+101;

    Boton *tablero49 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero49, SIGNAL(clicked()), this, SLOT(click47()));
    connect(tablero49, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero49);
    imagen++;
    i = i+101;

    Boton *tablero50 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero50, SIGNAL(clicked()), this, SLOT(click48()));
    connect(tablero50, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero50);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero51 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero51, SIGNAL(clicked()), this, SLOT(click49()));
    connect(tablero51, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero51);
    imagen++;
    i = i+101;

    Boton *tablero52 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero52, SIGNAL(clicked()), this, SLOT(click50()));
    connect(tablero52, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero52);
    imagen++;
    i = i+101;

    Boton *tablero53 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero53, SIGNAL(clicked()), this, SLOT(click51()));
    connect(tablero53, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero53);
    imagen++;
    i = i+101;

    Boton *tablero54 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero54, SIGNAL(clicked()), this, SLOT(click52()));
    connect(tablero54, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero54);
    imagen++;
    i = i+101;

    Boton *tablero55 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero55, SIGNAL(clicked()), this, SLOT(click53()));
    connect(tablero55, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero55);
    imagen++;
    i = i+101;

    Boton *tablero56 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero56, SIGNAL(clicked()), this, SLOT(click54()));
    connect(tablero56, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero56);
    imagen++;
    i = i+101;

    Boton *tablero57 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero57, SIGNAL(clicked()), this, SLOT(click55()));
    connect(tablero57, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero57);
    imagen++;
    i = i+101;

    Boton *tablero58 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero58, SIGNAL(clicked()), this, SLOT(click56()));
    connect(tablero58, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero58);
    imagen++;
    i = i+101;

    Boton *tablero59 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero59, SIGNAL(clicked()), this, SLOT(click57()));
    connect(tablero59, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero59);
    imagen++;
    i = i+101;

    Boton *tablero60 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero60, SIGNAL(clicked()), this, SLOT(click58()));
    connect(tablero60, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero60);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero61 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero61, SIGNAL(clicked()), this, SLOT(click59()));
    connect(tablero61, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero61);
    imagen++;
    i = i+101;

    Boton *tablero62 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero62, SIGNAL(clicked()), this, SLOT(click60()));
    connect(tablero62, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero62);
    imagen++;
    i = i+101;

    Boton *tablero63 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero63, SIGNAL(clicked()), this, SLOT(click61()));
    connect(tablero63, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero63);
    imagen++;
    i = i+101;

    Boton *tablero64 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero64, SIGNAL(clicked()), this, SLOT(click62()));
    connect(tablero64, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero64);
    imagen++;
    i = i+101;

    Boton *tablero65 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero65, SIGNAL(clicked()), this, SLOT(click63()));
    connect(tablero65, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero65);
    imagen++;
    i = i+101;

    Boton *tablero66 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero66, SIGNAL(clicked()), this, SLOT(click64()));
    connect(tablero66, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero66);
    imagen++;
    i = i+101;

    Boton *tablero67 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero67, SIGNAL(clicked()), this, SLOT(click65()));
    connect(tablero67, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero67);
    imagen++;
    i = i+101;

    Boton *tablero68 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero68, SIGNAL(clicked()), this, SLOT(click66()));
    connect(tablero68, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero68);
    imagen++;
    i = i+101;

    Boton *tablero69 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero69, SIGNAL(clicked()), this, SLOT(click67()));
    connect(tablero69, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero69);
    imagen++;
    i = i+101;

    Boton *tablero70 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero70, SIGNAL(clicked()), this, SLOT(click68()));
    connect(tablero70, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero70);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero71 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero71, SIGNAL(clicked()), this, SLOT(click69()));
    connect(tablero71, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero71);
    imagen++;
    i = i+101;

    Boton *tablero72 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero72, SIGNAL(clicked()), this, SLOT(click70()));
    connect(tablero72, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero72);
    imagen++;
    i = i+101;

    Boton *tablero73 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero73, SIGNAL(clicked()), this, SLOT(click71()));
    connect(tablero73, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero73);
    imagen++;
    i = i+101;

    Boton *tablero74 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero74, SIGNAL(clicked()), this, SLOT(click72()));
    connect(tablero74, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero74);
    imagen++;
    i = i+101;

    Boton *tablero75 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero75, SIGNAL(clicked()), this, SLOT(click73()));
    connect(tablero75, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero75);
    imagen++;
    i = i+101;

    Boton *tablero76 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero76, SIGNAL(clicked()), this, SLOT(click74()));
    connect(tablero76, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero76);
    imagen++;
    i = i+101;

    Boton *tablero77 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero77, SIGNAL(clicked()), this, SLOT(click75()));
    connect(tablero77, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero77);
    imagen++;
    i = i+101;

    Boton *tablero78 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero78, SIGNAL(clicked()), this, SLOT(click76()));
    connect(tablero78, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero78);
    imagen++;
    i = i+101;

    Boton *tablero79 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero79, SIGNAL(clicked()), this, SLOT(click77()));
    connect(tablero79, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero79);
    imagen++;
    i = i+101;

    Boton *tablero80 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero80, SIGNAL(clicked()), this, SLOT(click78()));
    connect(tablero80, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero80);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero81 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero81, SIGNAL(clicked()), this, SLOT(click79()));
    connect(tablero81, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero81);
    imagen++;
    i = i+101;

    Boton *tablero82 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero82, SIGNAL(clicked()), this, SLOT(click80()));
    connect(tablero82, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero82);
    imagen++;
    i = i+101;

    Boton *tablero83 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero83, SIGNAL(clicked()), this, SLOT(click81()));
    connect(tablero83, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero83);
    imagen++;
    i = i+101;

    Boton *tablero84 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero84, SIGNAL(clicked()), this, SLOT(click82()));
    connect(tablero84, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero84);
    imagen++;
    i = i+101;

    Boton *tablero85 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero85, SIGNAL(clicked()), this, SLOT(click83()));
    connect(tablero85, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero85);
    imagen++;
    i = i+101;

    Boton *tablero86 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero86, SIGNAL(clicked()), this, SLOT(click84()));
    connect(tablero86, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero86);
    imagen++;
    i = i+101;

    Boton *tablero87 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero87, SIGNAL(clicked()), this, SLOT(click85()));
    connect(tablero87, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero87);
    imagen++;
    i = i+101;

    Boton *tablero88 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero88, SIGNAL(clicked()), this, SLOT(click86()));
    connect(tablero88, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero88);
    imagen++;
    i = i+101;

    Boton *tablero89 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero89, SIGNAL(clicked()), this, SLOT(click87()));
    connect(tablero89, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero89);
    imagen++;
    i = i+101;

    Boton *tablero90 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero90, SIGNAL(clicked()), this, SLOT(click88()));
    connect(tablero90, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero90);
    imagen++;
    i = 220;
    j = j+70;

    Boton *tablero91 = new Boton(":/img/4esquinas.png",i,j);
    scene->addItem(tablero91);
    i = i+101;

    Boton *tablero92 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero92, SIGNAL(clicked()), this, SLOT(click89()));
    connect(tablero92, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero92);
    imagen++;
    i = i+101;

    Boton *tablero93 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero93, SIGNAL(clicked()), this, SLOT(click90()));
    connect(tablero93, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero93);
    imagen++;
    i = i+101;

    Boton *tablero94 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero94, SIGNAL(clicked()), this, SLOT(click91()));
    connect(tablero94, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero94);
    imagen++;
    i = i+101;

    Boton *tablero95 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero95, SIGNAL(clicked()), this, SLOT(click92()));
    connect(tablero95, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero95);
    imagen++;
    i = i+101;

    Boton *tablero96 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero96, SIGNAL(clicked()), this, SLOT(click93()));
    connect(tablero96, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero96);
    imagen++;
    i = i+101;

    Boton *tablero97 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero97, SIGNAL(clicked()), this, SLOT(click94()));
    connect(tablero97, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero97);
    imagen++;
    i = i+101;

    Boton *tablero98 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero98, SIGNAL(clicked()), this, SLOT(click95()));
    connect(tablero98, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero98);
    imagen++;
    i = i+101;

    Boton *tablero99 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero99, SIGNAL(clicked()), this, SLOT(click96()));
    connect(tablero99, SIGNAL(clicked()), this, SLOT(proximoPaso()));
    scene->addItem(tablero99);
    imagen++;
    i = i+101;

    Boton *tablero100 = new Boton(":/img/4esquinas.png",i,j);
    scene->addItem(tablero100);


    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Metodos SLOT////////////////////////////////////////////////////////////////////////
void Controladora::clean()
{
    //Limpia la scena
    scene->clear();
}

void Controladora::tablero_2_Jugadores()
{
    this->clean();

    Boton *tableroNormal = new Boton(":/img/botonJugador.png",100,400);
    connect(tableroNormal, SIGNAL(clicked()), this, SLOT(tableroNormal()));
    scene->addItem(tableroNormal);

    Boton *tableroAleatorio = new Boton(":/img/botonJugador.png",900,400);
    connect(tableroAleatorio, SIGNAL(clicked()), this, SLOT(tableroAleatorio()));
    scene->addItem(tableroAleatorio);

    this->numeroJugadores=2;
}

void Controladora::tipoTablero3()
{
    this->clean();

    Boton *tableroNormal = new Boton(":/img/botonJugador.png",100,400);
    connect(tableroNormal, SIGNAL(clicked()), this, SLOT(tableroNormal()));
    scene->addItem(tableroNormal);

    Boton *tableroAleatorio = new Boton(":/img/botonJugador.png",900,400);
    connect(tableroAleatorio, SIGNAL(clicked()), this, SLOT(tableroAleatorio()));
    scene->addItem(tableroAleatorio);

    this->numeroJugadores=3;
}

void Controladora::tipoTablero4()
{
    this->clean();

    Boton *tableroNormal = new Boton(":/img/botonJugador.png",100,400);
    connect(tableroNormal, SIGNAL(clicked()), this, SLOT(tableroNormal()));
    scene->addItem(tableroNormal);

    Boton *tableroAleatorio = new Boton(":/img/botonJugador.png",900,400);
    connect(tableroAleatorio, SIGNAL(clicked()), this, SLOT(tableroAleatorio()));
    scene->addItem(tableroAleatorio);

    this->numeroJugadores=4;
}

void Controladora::tableroNormal()
{
    this->clean();
    creaTablero();
    creaJugadores();
    reparteCartas();
    creaManoJugador();
}

void Controladora::tableroAleatorio()
{
    this->clean();
    nuevo = randomizarTablero(this->cartas);
    this->cartas = nuevo;
    creaTablero();
    creaJugadores();
    reparteCartas();
    creaManoJugador();
}

void Controladora::IniciarJuego()
{
    scene->clear();
    // Aqui se llaman los METODOS para crear cartas, el maso, los jugadores
    // y poner a ejecutar el juego o iniciarlo junto con todos los componenes que tiene
}
void Controladora::imprimir()
{
    Imagen *imagen = new Imagen(":/img/10_of_diamonds.png");
    imagen->setPos(0,0);
    scene->addItem(imagen);
}
void Controladora::click1(){this->clickeado=1;this->xActual=346;this->yActual=30;}
void Controladora::click2(){this->clickeado=2;this->xActual=447;this->yActual=30;}
void Controladora::click3(){this->clickeado=3;this->xActual=548;this->yActual=30;}
void Controladora::click4(){this->clickeado=4;this->xActual=649;this->yActual=30;}
void Controladora::click5(){this->clickeado=5;this->xActual=750;this->yActual=30;}
void Controladora::click6(){this->clickeado=6;this->xActual=851;this->yActual=30;}
void Controladora::click7(){this->clickeado=7;this->xActual=952;this->yActual=30;}
void Controladora::click8(){this->clickeado=8;this->xActual=1053;this->yActual=30;}

void Controladora::click9(){this->clickeado=9;this->xActual=245;this->yActual=100;}
void Controladora::click10(){this->clickeado=10;this->xActual=346;this->yActual=100;}
void Controladora::click11(){this->clickeado=11;this->xActual=447;this->yActual=100;}
void Controladora::click12(){this->clickeado=12;this->xActual=548;this->yActual=100;}
void Controladora::click13(){this->clickeado=13;this->xActual=649;this->yActual=100;}
void Controladora::click14(){this->clickeado=14;this->xActual=750;this->yActual=100;}
void Controladora::click15(){this->clickeado=15;this->xActual=851;this->yActual=100;}
void Controladora::click16(){this->clickeado=16;this->xActual=952;this->yActual=100;}
void Controladora::click17(){this->clickeado=17;this->xActual=1053;this->yActual=100;}
void Controladora::click18(){this->clickeado=18;this->xActual=1154;this->yActual=100;}

void Controladora::click19(){this->clickeado=19;this->xActual=245;this->yActual=170;}
void Controladora::click20(){this->clickeado=20;this->xActual=346;this->yActual=170;}
void Controladora::click21(){this->clickeado=21;this->xActual=447;this->yActual=170;}
void Controladora::click22(){this->clickeado=22;this->xActual=548;this->yActual=170;}
void Controladora::click23(){this->clickeado=23;this->xActual=649;this->yActual=170;}
void Controladora::click24(){this->clickeado=24;this->xActual=750;this->yActual=170;}
void Controladora::click25(){this->clickeado=25;this->xActual=851;this->yActual=170;}
void Controladora::click26(){this->clickeado=26;this->xActual=952;this->yActual=170;}
void Controladora::click27(){this->clickeado=27;this->xActual=1053;this->yActual=170;}
void Controladora::click28(){this->clickeado=28;this->xActual=1154;this->yActual=170;}

void Controladora::click29(){this->clickeado=29;this->xActual=245;this->yActual=240;}
void Controladora::click30(){this->clickeado=30;this->xActual=346;this->yActual=240;}
void Controladora::click31(){this->clickeado=31;this->xActual=447;this->yActual=240;}
void Controladora::click32(){this->clickeado=32;this->xActual=548;this->yActual=240;}
void Controladora::click33(){this->clickeado=33;this->xActual=649;this->yActual=240;}
void Controladora::click34(){this->clickeado=34;this->xActual=750;this->yActual=240;}
void Controladora::click35(){this->clickeado=35;this->xActual=851;this->yActual=240;}
void Controladora::click36(){this->clickeado=36;this->xActual=952;this->yActual=240;}
void Controladora::click37(){this->clickeado=37;this->xActual=1053;this->yActual=240;}
void Controladora::click38(){this->clickeado=38;this->xActual=1154;this->yActual=240;}

void Controladora::click39(){this->clickeado=39;this->xActual=245;this->yActual=310;}
void Controladora::click40(){this->clickeado=40;this->xActual=346;this->yActual=310;}
void Controladora::click41(){this->clickeado=41;this->xActual=447;this->yActual=310;}
void Controladora::click42(){this->clickeado=42;this->xActual=548;this->yActual=310;}
void Controladora::click43(){this->clickeado=43;this->xActual=649;this->yActual=310;}
void Controladora::click44(){this->clickeado=44;this->xActual=750;this->yActual=310;}
void Controladora::click45(){this->clickeado=45;this->xActual=851;this->yActual=310;}
void Controladora::click46(){this->clickeado=46;this->xActual=952;this->yActual=310;}
void Controladora::click47(){this->clickeado=47;this->xActual=1053;this->yActual=310;}
void Controladora::click48(){this->clickeado=48;this->xActual=1154;this->yActual=310;}

void Controladora::click49(){this->clickeado=49;this->xActual=245;this->yActual=380;}
void Controladora::click50(){this->clickeado=50;this->xActual=346;this->yActual=380;}
void Controladora::click51(){this->clickeado=51;this->xActual=447;this->yActual=380;}
void Controladora::click52(){this->clickeado=52;this->xActual=548;this->yActual=380;}
void Controladora::click53(){this->clickeado=53;this->xActual=649;this->yActual=380;}
void Controladora::click54(){this->clickeado=54;this->xActual=750;this->yActual=380;}
void Controladora::click55(){this->clickeado=55;this->xActual=851;this->yActual=380;}
void Controladora::click56(){this->clickeado=56;this->xActual=952;this->yActual=380;}
void Controladora::click57(){this->clickeado=57;this->xActual=1053;this->yActual=380;}
void Controladora::click58(){this->clickeado=58;this->xActual=1154;this->yActual=380;}

void Controladora::click59(){this->clickeado=59;this->xActual=245;this->yActual=450;}
void Controladora::click60(){this->clickeado=60;this->xActual=346;this->yActual=450;}
void Controladora::click61(){this->clickeado=61;this->xActual=447;this->yActual=450;}
void Controladora::click62(){this->clickeado=62;this->xActual=548;this->yActual=450;}
void Controladora::click63(){this->clickeado=63;this->xActual=649;this->yActual=450;}
void Controladora::click64(){this->clickeado=64;this->xActual=750;this->yActual=450;}
void Controladora::click65(){this->clickeado=65;this->xActual=851;this->yActual=450;}
void Controladora::click66(){this->clickeado=66;this->xActual=952;this->yActual=450;}
void Controladora::click67(){this->clickeado=67;this->xActual=1053;this->yActual=450;}
void Controladora::click68(){this->clickeado=68;this->xActual=1154;this->yActual=450;}

void Controladora::click69(){this->clickeado=69;this->xActual=245;this->yActual=520;}
void Controladora::click70(){this->clickeado=70;this->xActual=346;this->yActual=520;}
void Controladora::click71(){this->clickeado=71;this->xActual=447;this->yActual=520;}
void Controladora::click72(){this->clickeado=72;this->xActual=548;this->yActual=520;}
void Controladora::click73(){this->clickeado=73;this->xActual=649;this->yActual=520;}
void Controladora::click74(){this->clickeado=74;this->xActual=750;this->yActual=520;}
void Controladora::click75(){this->clickeado=75;this->xActual=851;this->yActual=520;}
void Controladora::click76(){this->clickeado=76;this->xActual=952;this->yActual=520;}
void Controladora::click77(){this->clickeado=77;this->xActual=1053;this->yActual=520;}
void Controladora::click78(){this->clickeado=78;this->xActual=1154;this->yActual=520;}

void Controladora::click79(){this->clickeado=79;this->xActual=245;this->yActual=590;}
void Controladora::click80(){this->clickeado=80;this->xActual=346;this->yActual=590;}
void Controladora::click81(){this->clickeado=81;this->xActual=447;this->yActual=590;}
void Controladora::click82(){this->clickeado=82;this->xActual=548;this->yActual=590;}
void Controladora::click83(){this->clickeado=83;this->xActual=649;this->yActual=590;}
void Controladora::click84(){this->clickeado=84;this->xActual=750;this->yActual=590;}
void Controladora::click85(){this->clickeado=85;this->xActual=851;this->yActual=590;}
void Controladora::click86(){this->clickeado=86;this->xActual=952;this->yActual=590;}
void Controladora::click87(){this->clickeado=87;this->xActual=1053;this->yActual=590;}
void Controladora::click88(){this->clickeado=88;this->xActual=1154;this->yActual=590;}

void Controladora::click89(){this->clickeado=89;this->xActual=346;this->yActual=660;}
void Controladora::click90(){this->clickeado=90;this->xActual=447;this->yActual=660;}
void Controladora::click91(){this->clickeado=91;this->xActual=548;this->yActual=660;}
void Controladora::click92(){this->clickeado=92;this->xActual=649;this->yActual=660;}
void Controladora::click93(){this->clickeado=93;this->xActual=750;this->yActual=660;}
void Controladora::click94(){this->clickeado=94;this->xActual=851;this->yActual=660;}
void Controladora::click95(){this->clickeado=95;this->xActual=952;this->yActual=660;}
void Controladora::click96(){this->clickeado=96;this->xActual=1053;this->yActual=660;}


void Controladora::mano1(){this->manoClickeada=1;}
void Controladora::mano2(){this->manoClickeada=2;}
void Controladora::mano3(){this->manoClickeada=3;}
void Controladora::mano4(){this->manoClickeada=4;}
void Controladora::mano5(){this->manoClickeada=5;}
void Controladora::mano6(){this->manoClickeada=6;}
void Controladora::mano7(){this->manoClickeada=7;}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

