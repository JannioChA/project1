#include "ArrayStack.h"
#include <Carta.h>
#include <Boton.h>

using namespace std;

template <class A>
ArrayStack<A>::ArrayStack()
{
    max=1024;
    size=0;
    pos=0;
    elements=new A[max];
}

template <class A>
ArrayStack<A>::ArrayStack(int pMax)
{
    max=pMax;
    size=0;
    pos=0;
    elements=new A[pMax];
}

template <class A>
A ArrayStack<A>::getValue(){
    if(pos<0 || pos>size){
        throw runtime_error("Index out of bounds");
    }
    return elements[pos-1];
}

template <class A>
int ArrayStack<A>::getPos(){
    return pos;
}

template <class A>
int ArrayStack<A>::getSize(){
    return size;
}

template <class A>
void ArrayStack<A>::goToStart(){
    pos=0;
}

template <class A>
void ArrayStack<A>::goToEnd(){
    pos=size+1;
}

template <class A>
void ArrayStack<A>::goToPos(int pos){
    if(pos>size || pos<0){
        throw runtime_error("Index out of bounds");
    }
    pos=pos;
}

template <class A>
void ArrayStack<A>::next(){
    if(pos>size){
        throw runtime_error("Index out of bounds");
    }
    pos++;
}

template <class A>
void ArrayStack<A>::previous(){
    if(pos<=0){
        throw runtime_error("Index out of bounds");
    }
    pos--;
}

template <class A>
void ArrayStack<A>::push(A pElement){
    if(size==max){
        throw runtime_error("Stack Full");
    }
    elements[size]=pElement;
    size++;
}

//Pos apuntando al elemento a eliminar
template <class A>
A ArrayStack<A>::pop(){
    pos = size-1;
    if(size==0){
        //throw runtime_error("Empty Stack");
        cout << "Empty Stack!";
    }
    else {
        A deleted=elements[pos-1];
        for(int i=pos-1;i<size;i++){
            elements[i]=elements[i+1];
        }
        size--;
        return (deleted);
    }
}

//template <class A>
/*void ArrayList<A>::printList(){
    cout << "(";
    for(int i=0;i<size;i++){
        cout<<elements[i];
        if(i<size-1)
        {
            cout<<"<-";
        }
    }
    cout << ")";
}*/

template <class A>
ArrayStack<A>::~ArrayStack()
{
   size=0;
   pos=0;
   delete[] elements;
}
template class ArrayStack<int>;
template class ArrayStack<QString>;
template class ArrayStack<Boton*>;
template class ArrayStack<Carta*>;
