#ifndef ARRAYLIST_H
#define ARRAYLIST_H
#include <stdexcept>
#include "carta.h"
#include <iostream>

template <class A> class ArrayList
{
    public:
        ArrayList();
        ArrayList(int pMax);
        A getValue();
        int getPos();
        int getSize();
        void goToStart();
        void goToEnd();
        void goToPos(int pos);
        void next();
        void previous();
        void append(A pElement);
        void insertar(A pElement);
        A remove();
        void printList();
        ~ArrayList();
        A* elements;

    protected:

        int size;
        int max;
        int pos;


};
#endif // ARRAYLIST_H
