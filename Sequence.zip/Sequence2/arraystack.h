#ifndef ARRAYSTACK_H
#define ARRAYSTACK_H
#include <stdexcept>
#include "carta.h"
#include <iostream>

template <class A> class ArrayStack
{
    public:
        ArrayStack();
        ArrayStack(int pMax);
        A getValue();
        int getPos();
        int getSize();
        void goToStart();
        void goToEnd();
        void goToPos(int pos);
        void next();
        void previous();
        void push(A pElement);
        A pop();
        void printList();
        ~ArrayStack();
        A* elements;

    protected:
        int size;
        int max;
        int pos;


};

#endif // ARRAYSTACK_H
