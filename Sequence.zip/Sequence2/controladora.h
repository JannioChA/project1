#ifndef CONTROLADORA_H
#define CONTROLADORA_H

#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsRectItem>
#include "imagen.h"
#include "boton.h"
#include "jugador.h"
#include <QDebug>
#include "iostream"
#include "arraylist.h"
#include "carraylist.h"
#include "arraystack.h"

using namespace std;

class Controladora: public QGraphicsView
{
    Q_OBJECT
public:
    Controladora();
    void Scena();
    void CargarImagen(int i,int j,QString imagen);
    void creaListaCartas();
    void creaTablero();
    void menuInicio();
    void creaBaraja();
    void creaManoJugador();
    void creaJugadores();
    void reparteCartas();
    void cargarMano();
    void siguienteTurno();
    void colocarFicha(int pColor);
    int matrizToInt(int i,int j);
    bool verificarSecuenciaHorizontal();
    bool verificarSecuenciaVertical();
    bool verificarSecuenciaDiagonal();
    bool validaHorizontal(int pos);
    bool validaVertical(int pos);
    bool validaDiagonalDerecha(int pos);
    bool validaDiagonalIzquierda(int pos);
    int clickeado;
    int numeroJugadores;
    int manoClickeada;
    int xActual;
    int yActual;
    ArrayList<Carta*>* randomizarTablero(ArrayList<Carta*>* original);
    ArrayList<Carta*>* getCartas();
    ArrayStack<Carta*>* barajarBaraja(ArrayStack<Carta*>* original);
    ArrayList<Carta*>* tableroRandomizado;
    ArrayStack<Carta*>* barajaAleatoria;
    ArrayList<Carta*>* nuevo;
    ArrayList<Carta*>* cartas;
    ArrayStack<Carta*>* baraja;
    ArrayStack<Carta*>* cementerio;
    CArrayList<Jugador*>* jugadores;
    Boton *cementerioTablero;

    Boton *tablero1;    Boton *tablero2;    Boton *tablero3;    Boton *tablero4;    Boton *tablero5;    Boton *tablero6;
    Boton *tablero7;    Boton *tablero8;    Boton *tablero9;    Boton *tablero10;   Boton *tablero11;    Boton *tablero12;
    Boton *tablero13;   Boton *tablero14;   Boton *tablero15;   Boton *tablero16;   Boton *tablero17;    Boton *tablero18;
    Boton *tablero19;   Boton *tablero20;   Boton *tablero21;   Boton *tablero22;   Boton *tablero23;    Boton *tablero24;
    Boton *tablero25;   Boton *tablero26;   Boton *tablero27;   Boton *tablero28;   Boton *tablero29;    Boton *tablero30;
    Boton *tablero31;   Boton *tablero32;   Boton *tablero33;   Boton *tablero34;   Boton *tablero35;    Boton *tablero36;
    Boton *tablero37;   Boton *tablero38;   Boton *tablero39;   Boton *tablero40;   Boton *tablero41;    Boton *tablero42;
    Boton *tablero43;   Boton *tablero44;   Boton *tablero45;   Boton *tablero46;   Boton *tablero47;    Boton *tablero48;
    Boton *tablero49;   Boton *tablero50;   Boton *tablero51;   Boton *tablero52;   Boton *tablero53;    Boton *tablero54;
    Boton *tablero55;   Boton *tablero56;   Boton *tablero57;   Boton *tablero58;   Boton *tablero59;    Boton *tablero60;
    Boton *tablero61;   Boton *tablero62;   Boton *tablero63;   Boton *tablero64;   Boton *tablero65;    Boton *tablero66;
    Boton *tablero67;   Boton *tablero68;   Boton *tablero69;   Boton *tablero70;   Boton *tablero71;    Boton *tablero72;
    Boton *tablero73;   Boton *tablero74;   Boton *tablero75;   Boton *tablero76;   Boton *tablero77;    Boton *tablero78;
    Boton *tablero79;   Boton *tablero80;   Boton *tablero81;   Boton *tablero82;   Boton *tablero83;    Boton *tablero84;
    Boton *tablero85;   Boton *tablero86;   Boton *tablero87;   Boton *tablero88;   Boton *tablero89;    Boton *tablero90;
    Boton *tablero91;   Boton *tablero92;   Boton *tablero93;   Boton *tablero94;   Boton *tablero95;    Boton *tablero96;
    Boton *tablero97;   Boton *tablero98;   Boton *tablero99;   Boton *tablero100;  Boton *cartaMano_1;  Boton *cartaMano_2;
    Boton *cartaMano_3; Boton *cartaMano_4; Boton *cartaMano_5; Boton *cartaMano_6; Boton *cartaMano_7;

    QGraphicsScene* scene;

public slots:
    void quitarFicha();
    void clean();
    void tablero_2_Jugadores();
    void tablero_3_Jugadores();
    void tablero_4_Jugadores();
    void tableroNormal();
    void tableroAleatorio();
    void validacionJugada();
    void mano1();
    void mano2();
    void mano3();
    void mano4();
    void mano5();
    void mano6();
    void mano7();
    void click1();    void click2();    void click3();    void click4();    void click5();    void click6();    void click7();    void click8();
    void click9();    void click10();   void click11();   void click12();   void click13();   void click14();   void click15();   void click16();
    void click17();   void click18();   void click19();   void click20();   void click21();   void click22();   void click23();   void click24();
    void click25();   void click26();   void click27();   void click28();   void click29();   void click30();   void click31();   void click32();
    void click33();   void click34();   void click35();   void click36();   void click37();   void click38();   void click39();   void click40();
    void click41();   void click42();   void click43();   void click44();   void click45();   void click46();   void click47();   void click48();
    void click49();   void click50();   void click51();   void click52();   void click53();   void click54();   void click55();   void click56();
    void click57();   void click58();   void click59();   void click60();   void click61();   void click62();   void click63();   void click64();
    void click65();   void click66();   void click67();   void click68();   void click69();   void click70();   void click71();   void click72();
    void click73();   void click74();   void click75();   void click76();   void click77();   void click78();   void click79();   void click80();
    void click81();   void click82();   void click83();   void click84();   void click85();   void click86();   void click87();   void click88();
    void click89();   void click90();   void click91();   void click92();   void click93();   void click94();   void click95();   void click96();
};

#endif // CONTROLADORA_H
