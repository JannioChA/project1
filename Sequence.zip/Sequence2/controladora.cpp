#include <time.h>
#include "controladora.h"
#include "imagen.h"
#include "boton.h"
#include "carta.h"
#include "jugador.h"
#include "arraylist.h"
#include "carraylist.h"
#include "arraystack.h"
#define TABLERO_MAX_SIZE 96
#define BARAJA_MAX_SIZE 104
#define CEMENTERIO_MAX_SIZE 104
#define JUGADORES_MAX_SIZE 4

Controladora::Controladora()
{
    this->xActual=0;//Guarda el valor de la carta que seleccionó el jugador en el tablero
    this->yActual=0;//Guarda el valor de la carta que seleccionó el jugador en el tablero
    this->manoClickeada=0;//Guarda el valor de la carta que seleccionó el jugador de su mano
    this->cartas = new ArrayList<Carta*>(TABLERO_MAX_SIZE);
    this->baraja = new ArrayStack<Carta*>(BARAJA_MAX_SIZE);
    this->jugadores = new CArrayList<Jugador*>(JUGADORES_MAX_SIZE);
    this->cementerio = new ArrayStack<Carta*>(CEMENTERIO_MAX_SIZE);
    Scena();                                    //Crea una nueva escena
    creaListaCartas();                          //Crea las cartas que son necesarias para el tablero
    creaBaraja();                               //Crea el stack de las cartas necesarias para la baraja
    CargarImagen(580,100,":/img/LOGO.png");     //Carga el logo del juego en la pantalla de bienvenida
    menuInicio();
}

ArrayList<Carta*>* Controladora::getCartas(){return this->cartas;}

void Controladora::Scena()
{
    //Crea un escenario
    scene = new QGraphicsScene();
    scene->setSceneRect(0,0,1470,950);
    scene->setBackgroundBrush(Qt::blue);
    setFixedSize(1366,768);
    scene->setBackgroundBrush(QBrush(QImage(":/img/f.png"))); //Cambia el fondo de la scena
    setScene(scene);
}

void Controladora::CargarImagen(int i,int j,QString ubicacion)
{
    //Crea una imagen
    Imagen *imagen = new Imagen(ubicacion);
    imagen->setPos(i,j);
    scene->addItem(imagen);
}

void Controladora::creaBaraja()
{
    //Inserta en el ArrayStack las cartas de la baraja
    for(int i = 0; i < this->cartas->getSize(); i++) {this->baraja->push(this->cartas->elements[i]);}

    baraja->push(new Carta (":/img/jack_of_clubs2.png"));    baraja->push(new Carta (":/img/jack_of_diamonds2.png"));
    baraja->push(new Carta (":/img/jack_of_hearts2.png"));   baraja->push(new Carta (":/img/jack_of_spades2.png"));
    baraja->push(new Carta (":/img/jack_of_clubs2.png"));    baraja->push(new Carta (":/img/jack_of_diamonds2.png"));
    baraja->push(new Carta (":/img/jack_of_hearts2.png"));   baraja->push(new Carta (":/img/jack_of_spades2.png"));

    this->baraja = barajarBaraja(this->baraja);     //Randomiza la baraja(Barajar)
}

void Controladora::creaListaCartas()
{
    //Inserta las cartas que se utilizan para el tablero en el ArrayList de cartas

    this->cartas->append(new Carta (":/img/ace_of_clubs.png"));      this->cartas->append(new Carta (":/img/king_of_clubs.png"));
    this->cartas->append(new Carta (":/img/queen_of_clubs.png"));    this->cartas->append(new Carta (":/img/10_of_clubs.png"));
    this->cartas->append(new Carta (":/img/9_of_clubs.png"));        this->cartas->append(new Carta (":/img/8_of_clubs.png"));
    this->cartas->append(new Carta (":/img/7_of_clubs.png"));        this->cartas->append(new Carta (":/img/6_of_clubs.png"));
    this->cartas->append(new Carta (":/img/ace_of_diamonds.png"));   this->cartas->append(new Carta (":/img/7_of_spades.png"));
    this->cartas->append(new Carta (":/img/8_of_spades.png"));       this->cartas->append(new Carta (":/img/9_of_spades.png"));
    this->cartas->append(new Carta (":/img/10_of_spades.png"));      this->cartas->append(new Carta (":/img/queen_of_spades.png"));
    this->cartas->append(new Carta (":/img/king_of_spades.png"));    this->cartas->append(new Carta (":/img/ace_of_spades.png"));
    this->cartas->append(new Carta (":/img/5_of_clubs.png"));        this->cartas->append(new Carta (":/img/2_of_spades.png"));
    this->cartas->append(new Carta (":/img/king_of_diamonds.png"));  this->cartas->append(new Carta (":/img/6_of_spades.png"));
    this->cartas->append(new Carta (":/img/10_of_clubs.png"));       this->cartas->append(new Carta (":/img/9_of_clubs.png"));
    this->cartas->append(new Carta (":/img/8_of_clubs.png"));        this->cartas->append(new Carta (":/img/7_of_clubs.png"));
    this->cartas->append(new Carta (":/img/6_of_clubs.png"));        this->cartas->append(new Carta (":/img/2_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/4_of_clubs.png"));        this->cartas->append(new Carta (":/img/3_of_spades.png"));
    this->cartas->append(new Carta (":/img/queen_of_diamonds.png")); this->cartas->append(new Carta (":/img/5_of_spades.png"));
    this->cartas->append(new Carta (":/img/queen_of_clubs.png"));    this->cartas->append(new Carta (":/img/8_of_hearts.png"));
    this->cartas->append(new Carta (":/img/7_of_hearts.png"));       this->cartas->append(new Carta (":/img/6_of_hearts.png"));
    this->cartas->append(new Carta (":/img/5_of_clubs.png"));        this->cartas->append(new Carta (":/img/3_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/3_of_clubs.png"));        this->cartas->append(new Carta (":/img/4_of_spades.png"));
    this->cartas->append(new Carta (":/img/10_of_diamonds.png"));    this->cartas->append(new Carta (":/img/4_of_spades.png"));
    this->cartas->append(new Carta (":/img/king_of_clubs.png"));     this->cartas->append(new Carta (":/img/9_of_hearts.png"));
    this->cartas->append(new Carta (":/img/2_of_hearts.png"));       this->cartas->append(new Carta (":/img/5_of_hearts.png"));
    this->cartas->append(new Carta (":/img/4_of_clubs.png"));        this->cartas->append(new Carta (":/img/4_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/2_of_clubs.png"));        this->cartas->append(new Carta (":/img/5_of_spades.png"));
    this->cartas->append(new Carta (":/img/9_of_diamonds.png"));     this->cartas->append(new Carta (":/img/3_of_spades.png"));
    this->cartas->append(new Carta (":/img/ace_of_clubs.png"));      this->cartas->append(new Carta (":/img/10_of_hearts.png"));
    this->cartas->append(new Carta (":/img/3_of_hearts.png"));       this->cartas->append(new Carta (":/img/4_of_hearts.png"));
    this->cartas->append(new Carta (":/img/3_of_clubs.png"));        this->cartas->append(new Carta (":/img/5_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/ace_of_hearts.png"));     this->cartas->append(new Carta (":/img/6_of_spades.png"));
    this->cartas->append(new Carta (":/img/8_of_diamonds.png"));     this->cartas->append(new Carta (":/img/2_of_spades.png"));
    this->cartas->append(new Carta (":/img/ace_of_diamonds.png"));   this->cartas->append(new Carta (":/img/queen_of_hearts.png"));
    this->cartas->append(new Carta (":/img/king_of_hearts.png"));    this->cartas->append(new Carta (":/img/ace_of_hearts.png"));
    this->cartas->append(new Carta (":/img/2_of_clubs.png"));        this->cartas->append(new Carta (":/img/6_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/king_of_hearts.png"));    this->cartas->append(new Carta (":/img/7_of_spades.png"));
    this->cartas->append(new Carta (":/img/7_of_diamonds.png"));     this->cartas->append(new Carta (":/img/2_of_hearts.png"));
    this->cartas->append(new Carta (":/img/king_of_diamonds.png"));  this->cartas->append(new Carta (":/img/queen_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/10_of_diamonds.png"));    this->cartas->append(new Carta (":/img/9_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/8_of_diamonds.png"));     this->cartas->append(new Carta (":/img/7_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/queen_of_hearts.png"));   this->cartas->append(new Carta (":/img/8_of_spades.png"));
    this->cartas->append(new Carta (":/img/6_of_diamonds.png"));     this->cartas->append(new Carta (":/img/3_of_hearts.png"));
    this->cartas->append(new Carta (":/img/4_of_hearts.png"));       this->cartas->append(new Carta (":/img/5_of_hearts.png"));
    this->cartas->append(new Carta (":/img/6_of_hearts.png"));       this->cartas->append(new Carta (":/img/7_of_hearts.png"));
    this->cartas->append(new Carta (":/img/8_of_hearts.png"));       this->cartas->append(new Carta (":/img/9_of_hearts.png"));
    this->cartas->append(new Carta (":/img/10_of_hearts.png"));      this->cartas->append(new Carta (":/img/9_of_spades.png"));
    this->cartas->append(new Carta (":/img/5_of_diamonds.png"));     this->cartas->append(new Carta (":/img/4_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/3_of_diamonds.png"));     this->cartas->append(new Carta (":/img/2_of_diamonds.png"));
    this->cartas->append(new Carta (":/img/ace_of_spades.png"));     this->cartas->append(new Carta (":/img/king_of_spades.png"));
    this->cartas->append(new Carta (":/img/queen_of_spades.png"));   this->cartas->append(new Carta (":/img/10_of_spades.png"));
}

void Controladora::menuInicio()
{
    //Crea los primeros 3 botones de bienvenida
    Boton *boton_2_Jugadores = new Boton(":/img/botonJugador2.png",100,400);
    connect(boton_2_Jugadores, SIGNAL(clicked()), this, SLOT(tablero_2_Jugadores()));
    scene->addItem(boton_2_Jugadores);

    Boton *boton_3_Jugadores = new Boton(":/img/botonJugador3.png",500,400);
    connect(boton_3_Jugadores, SIGNAL(clicked()), this, SLOT(tablero_3_Jugadores()));
    scene->addItem(boton_3_Jugadores);

    Boton *boton_4_Jugadores = new Boton(":/img/botonJugador4.png",900,400);
    connect(boton_4_Jugadores, SIGNAL(clicked()), this, SLOT(tablero_4_Jugadores()));
    scene->addItem(boton_4_Jugadores);
}

void Controladora::creaManoJugador()
{
    //Crea los botones correspondientes a la mano del jugador, según el número de jugadores
    if(this->numeroJugadores < 3)
    {
        this->cartaMano_1 = new Boton(this->jugadores->elements[0]->mano->elements[0]->getNombre(),460,800);
        connect(cartaMano_1, SIGNAL(clicked()), this, SLOT(mano1()));
        cartaMano_1->setRotation(90);
        scene->addItem(cartaMano_1);

        this->cartaMano_2 = new Boton(this->jugadores->elements[0]->mano->elements[1]->getNombre(),560,800);
        connect(cartaMano_2, SIGNAL(clicked()), this, SLOT(mano2()));
        cartaMano_2->setRotation(90);
        scene->addItem(cartaMano_2);

        this->cartaMano_3 = new Boton(this->jugadores->elements[0]->mano->elements[2]->getNombre(),660,800);
        connect(cartaMano_3, SIGNAL(clicked()), this, SLOT(mano3()));
        cartaMano_3->setRotation(90);
        scene->addItem(cartaMano_3);

        this->cartaMano_4 = new Boton(this->jugadores->elements[0]->mano->elements[3]->getNombre(),760,800);
        connect(cartaMano_4, SIGNAL(clicked()), this, SLOT(mano4()));
        cartaMano_4->setRotation(90);
        scene->addItem(cartaMano_4);

        this->cartaMano_5 = new Boton(this->jugadores->elements[0]->mano->elements[4]->getNombre(),860,800);
        connect(cartaMano_5, SIGNAL(clicked()), this, SLOT(mano5()));
        cartaMano_5->setRotation(90);
        scene->addItem(cartaMano_5);

        this->cartaMano_6 = new Boton(this->jugadores->elements[0]->mano->elements[5]->getNombre(),960,800);
        connect(cartaMano_6, SIGNAL(clicked()), this, SLOT(mano6()));
        cartaMano_6->setRotation(90);
        scene->addItem(cartaMano_6);

        this->cartaMano_7 = new Boton(this->jugadores->elements[0]->mano->elements[6]->getNombre(),1060,800);
        connect(cartaMano_7, SIGNAL(clicked()), this, SLOT(mano7()));
        cartaMano_7->setRotation(90);
        scene->addItem(cartaMano_7);
    }
    else
    {
        this->cartaMano_1 = new Boton(this->jugadores->elements[0]->mano->elements[0]->getNombre(),510,800);
        connect(cartaMano_1, SIGNAL(clicked()), this, SLOT(mano1()));
        cartaMano_1->setRotation(90);
        scene->addItem(cartaMano_1);

        this->cartaMano_2 = new Boton(this->jugadores->elements[0]->mano->elements[1]->getNombre(),610,800);
        connect(cartaMano_2, SIGNAL(clicked()), this, SLOT(mano2()));
        cartaMano_2->setRotation(90);
        scene->addItem(cartaMano_2);

        this->cartaMano_3 = new Boton(this->jugadores->elements[0]->mano->elements[2]->getNombre(),710,800);
        connect(cartaMano_3, SIGNAL(clicked()), this, SLOT(mano3()));
        cartaMano_3->setRotation(90);
        scene->addItem(cartaMano_3);

        this->cartaMano_4 = new Boton(this->jugadores->elements[0]->mano->elements[3]->getNombre(),810,800);
        connect(cartaMano_4, SIGNAL(clicked()), this, SLOT(mano4()));
        cartaMano_4->setRotation(90);
        scene->addItem(cartaMano_4);

        this->cartaMano_5 = new Boton(this->jugadores->elements[0]->mano->elements[4]->getNombre(),910,800);
        connect(cartaMano_5, SIGNAL(clicked()), this, SLOT(mano5()));
        cartaMano_5->setRotation(90);
        scene->addItem(cartaMano_5);

        this->cartaMano_6 = new Boton(this->jugadores->elements[0]->mano->elements[5]->getNombre(),1010,800);
        connect(cartaMano_6, SIGNAL(clicked()), this, SLOT(mano6()));
        cartaMano_6->setRotation(90);
        scene->addItem(cartaMano_6);
    }
}

void Controladora::creaJugadores()
{
    for(int i=0;i<this->numeroJugadores;i++) {this->jugadores->append(new Jugador());}
    this->jugadores->goToStart();
}

void Controladora::reparteCartas()
{
    //Reparte las cartas a los jugadores dependiendo del número de estos
    int numeroCartas;
    if(this->numeroJugadores < 3) {numeroCartas = 7;}
    else{numeroCartas = 6;}
    for(int i = 0; i < this->jugadores->getSize(); i++)
    {
        for (int j = 0; j < numeroCartas; j++){this->jugadores->elements[i]->mano->append(this->baraja->pop());}
    }
}

void Controladora::cargarMano()
{
    //Actualiza la mano del jugador gráficamente para cada turno
    if(this->numeroJugadores<3)
    {
        this->cartaMano_1->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[0]->getNombre());
        this->cartaMano_2->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[1]->getNombre());
        this->cartaMano_3->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[2]->getNombre());
        this->cartaMano_4->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[3]->getNombre());
        this->cartaMano_5->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[4]->getNombre());
        this->cartaMano_6->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[5]->getNombre());
        this->cartaMano_7->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[6]->getNombre());
    }
    else
    {
        this->cartaMano_1->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[0]->getNombre());
        this->cartaMano_2->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[1]->getNombre());
        this->cartaMano_3->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[2]->getNombre());
        this->cartaMano_4->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[3]->getNombre());
        this->cartaMano_5->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[4]->getNombre());
        this->cartaMano_6->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[5]->getNombre());
    }
}

void Controladora::siguienteTurno()
{
    this->jugadores->next();
    cargarMano();
}

void Controladora::validacionJugada()
{
    //Este metodo es uno de los principales y se encarga de toda la parte lógica al realizar un turno por parte de un jugador

    QString jackClubs = ":/img/jack_of_clubs2.png";
    QString jackDiamonds = ":/img/jack_of_diamonds2.png";
    QString jackHearts = ":/img/jack_of_hearts2.png";
    QString jackSpades = ":/img/jack_of_spades2.png";

    if(this->manoClickeada != 0)                            //Verifica que haya presionado una carta de la mano
    {
        int colorFicha;                                     //Setea el color de la ficha según el jugador actual
        if(this->numeroJugadores<4)
        {
            if(this->jugadores->getPos()==0)
            {
                colorFicha = 1;
            }
            if(this->jugadores->getPos()==1)
            {
                colorFicha = 2;
            }
            if(this->jugadores->getPos()==2)
            {
                colorFicha = 3;
            }
        }else
        {
            if(this->jugadores->getPos()==0)
            {
                colorFicha = 1;
            }
            if(this->jugadores->getPos()==1)
            {
                colorFicha =2;
            }
            if(this->jugadores->getPos()==2)
            {
                colorFicha = 1;
            }
            if(this->jugadores->getPos()==3)
            {
                colorFicha = 2;
            }
         }

        //Pregunta si la carta en cuestión es una Jota de 1 ojo
        if(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]->getNombre()== jackHearts
           || this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]->getNombre()== jackSpades)
        {
            if(this->cartas->elements[this->clickeado-1]->getPerteneceSecuencia()==0)//Valida que no vaya a quitar una ficha de una secuencia ya armada
            {
                if(this->cartas->elements[this->clickeado-1]->getFichaPuesta() != colorFicha)//Valida que el jugador no vaya a quitar su propia ficha
                {
                    if(this->cartas->elements[this->clickeado-1]->getFichaPuesta() != 0)//Valida que haya una ficha en donde quiere quitarlas
                    {
                        this->cartas->elements[this->clickeado-1]->setFichaPuesta(0);//Setea el valor de fichaPuesta de la carta en 0
                        this->quitarFicha();//Quita la ficha gráficamente
                        //Añade la carta al cementerio o pila
                        this->cementerioTablero->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]->getNombre());
                        if(this->baraja->getSize() != 0)//Pregunta si la baraja no está vacía
                        {
                            this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]=this->baraja->pop();//Otorga una nueva carta al jugador
                        }
                        else
                        {
                            //En caso de tener la baraja vacía, toma las cartas de la pila, las mete en la baraja y la randomiza
                            for(int i=0;i<this->cementerio->getSize();i++)
                            {
                                this->baraja->push(this->cementerio->pop());
                            }
                            this->baraja = this->barajarBaraja(this->baraja);
                            this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]=this->baraja->pop();//Otorga una nueva carta al jugador
                        }

                        this->siguienteTurno();
                        this->manoClickeada=0;//Vuelve a setear manoClickeada en 0 para obligar al jugador a seleccionar una carta de su mano
                    }
                }
            }
        }else
        {
            //Pregunta si la carta es una Jota de 2 ojos
            if(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]->getNombre()== jackClubs
               || this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]->getNombre()== jackDiamonds)
            {
                if(this->cartas->elements[this->clickeado-1]->getFichaPuesta() == 0)//Verifica que donde va a poner no haya una ficha
                {
                    this->cartas->elements[this->clickeado-1]->setFichaPuesta(colorFicha);//Coloca la ficha lógicamente según el color del jugador actual
                    this->colocarFicha(colorFicha);//Coloca la ficha gráficamente
                    this->cementerioTablero->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]->getNombre());//Descarta la carta en el cementerio
                    if(this->baraja->getSize() != 0)//Pregunta si la baraja no está vacía
                    {
                        this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]=this->baraja->pop();//Otorga una nueva carta al jugador
                    }
                    else
                    {
                        //En caso de tener la baraja vacía, toma las cartas de la pila, las mete en la baraja y la randomiza
                        for(int i=0;i<this->cementerio->getSize();i++)
                        {
                            this->baraja->push(this->cementerio->pop());
                        }
                        this->baraja = this->barajarBaraja(this->baraja);
                    }
                    if(this->verificarSecuenciaHorizontal())//Pregunta si en el turno se armó una secuencia horizontal
                    {
                        this->jugadores->elements[this->jugadores->getPos()]->secuenciasArmadas++; //Suma una secuencia al jugador que la armó
                    }
                    if(this->verificarSecuenciaVertical())//Pregunta si en el turno se armó una secuencia vertical
                    {
                        this->jugadores->elements[this->jugadores->getPos()]->secuenciasArmadas++;//Suma una secuencia al jugador que la armó
                    }
                    if(this->verificarSecuenciaDiagonal())//Pregunta si en el turno se armó una secuencia diagonal
                    {
                        this->jugadores->elements[this->jugadores->getPos()]->secuenciasArmadas++;//Suma una secuencia al jugador que la armó
                    }
                    if(this->numeroJugadores==2)
                    {
                        //Hace las validaciones necesarias para verificar el gane de un jugador cuando son 2 jugadores
                        if(this->jugadores->elements[this->jugadores->getPos()]->secuenciasArmadas==2)
                        {
                            if(this->jugadores->getPos()==0)
                            {
                                scene->clear();
                                CargarImagen(600,400,":/img/ganadorRojo.png");
                            }else if(this->jugadores->getPos()==1)
                            {
                                scene->clear();
                                CargarImagen(600,400,":/img/ganadorAzul.png");
                            }
                        }else
                        {
                            this->siguienteTurno();
                            this->manoClickeada=0;
                        }
                    }else if(this->numeroJugadores==3)
                    {
                        //Hace las validaciones necesarias para verificar el gane de un jugador cuando son 3 jugadores
                        if(this->jugadores->elements[this->jugadores->getPos()]->secuenciasArmadas==1)
                        {
                            if(this->jugadores->getPos()==0)
                            {
                                scene->clear();
                                CargarImagen(600,400,":/img/ganadorRojo.png");
                            }else if(this->jugadores->getPos()==1)
                            {
                                scene->clear();
                                CargarImagen(600,400,":/img/ganadorAzul.png");
                            }else if(this->jugadores->getPos()==2)
                            {
                                scene->clear();
                                CargarImagen(600,400,":/img/ganadorVerde.png");
                            }
                        }else
                        {
                            this->siguienteTurno();
                            this->manoClickeada=0;
                        }
                    }else if(this->numeroJugadores==4)
                    {
                        //Hace las validaciones necesarias para verificar el gane de un equipo cuando son 4 jugadores
                        if((this->jugadores->elements[0]->secuenciasArmadas)+
                                (this->jugadores->elements[2]->secuenciasArmadas)==2)
                        {
                            scene->clear();
                            CargarImagen(600,400,":/img/ganadorRojo.png");
                        }else if((this->jugadores->elements[1]->secuenciasArmadas)+
                                 (this->jugadores->elements[3]->secuenciasArmadas)==2)
                        {
                            scene->clear();
                            CargarImagen(600,400,":/img/ganadorAzul.png");
                        }else
                        {
                            this->siguienteTurno();
                            this->manoClickeada=0;
                        }
                    }
                }
            }else  //El turno entra en esta categoría si no es ninguna de las Jotas osea es una carta normal
            {
                //Verifica que la carta de la mano coincida con la carta del tablero, además de que no tenga ficha puesta
                if(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]->getNombre()
                   == this->cartas->elements[this->clickeado-1]->getNombre() && this->cartas->elements[this->clickeado-1]->getFichaPuesta()==0)
                {
                    this->cartas->elements[this->clickeado-1]->setFichaPuesta(colorFicha);//Coloca la ficha lógicamente
                    this->colocarFicha(colorFicha);//Coloca la ficha gráficamente
                    //Descarta la carta usada en el cementerio o pila
                    this->cementerioTablero->setImagen(this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]->getNombre());
                    if(this->baraja->getSize() != 0)//Pregunta si la baraja no está vacía
                    {
                        this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]=this->baraja->pop();//Otorga una nueva carta al jugador
                    }
                    else
                    {
                        //En caso de tener la baraja vacía, toma las cartas de la pila, las mete en la baraja y la randomiza
                        for(int i=0;i<this->cementerio->getSize();i++)
                        {
                            this->baraja->push(this->cementerio->pop());
                        }
                        this->baraja = this->barajarBaraja(this->baraja);
                        this->jugadores->elements[this->jugadores->getPos()]->mano->elements[manoClickeada-1]=this->baraja->pop();//Otorga una nueva carta al jugador
                    }
                    if(this->verificarSecuenciaHorizontal())//Pregunta si en el turno se armó una secuencia horizontal
                    {
                        this->jugadores->elements[this->jugadores->getPos()]->secuenciasArmadas++;//Suma una secuencia al jugador que la armó
                    }
                    if(this->verificarSecuenciaVertical())//Pregunta si en el turno se armó una secuencia vertical
                    {
                        this->jugadores->elements[this->jugadores->getPos()]->secuenciasArmadas++;//Suma una secuencia al jugador que la armó
                    }
                    if(this->verificarSecuenciaDiagonal())//Pregunta si en el turno se armó una secuencia diagonal
                    {
                        this->jugadores->elements[this->jugadores->getPos()]->secuenciasArmadas++;//Suma una secuencia al jugador que la armó
                    }
                    if(this->numeroJugadores==2)
                    {
                        //Hace las validaciones necesarias para verificar el gane de un jugador cuando son 2 jugadores
                        if(this->jugadores->elements[this->jugadores->getPos()]->secuenciasArmadas==2)
                        {
                            if(this->jugadores->getPos()==0)
                            {
                                scene->clear();
                                CargarImagen(600,400,":/img/ganadorRojo.png");
                            }else if(this->jugadores->getPos()==1)
                            {
                                scene->clear();
                                CargarImagen(600,400,":/img/ganadorAzul.png");
                            }
                        }else
                        {
                            this->siguienteTurno();
                            this->manoClickeada=0;
                        }
                    }else if(this->numeroJugadores==3)
                    {
                        //Hace las validaciones necesarias para verificar el gane de un jugador cuando son 3 jugadores
                        if(this->jugadores->elements[this->jugadores->getPos()]->secuenciasArmadas==1)
                        {
                            if(this->jugadores->getPos()==0)
                            {
                                scene->clear();
                                CargarImagen(600,400,":/img/ganadorRojo.png");
                            }else if(this->jugadores->getPos()==1)
                            {
                                scene->clear();
                                CargarImagen(600,400,":/img/ganadorazul.png");
                            }else if(this->jugadores->getPos()==2)
                            {
                                scene->clear();
                                CargarImagen(600,400,":/img/ganadorVerde.png");
                            }
                        }else
                        {
                            this->siguienteTurno();
                            this->manoClickeada=0;
                        }
                    }else if(this->numeroJugadores==4)
                    {
                        //Hace las validaciones necesarias para verificar el gane de un equipo cuando son 4 jugadores
                        if((this->jugadores->elements[0]->secuenciasArmadas)+
                                (this->jugadores->elements[2]->secuenciasArmadas)==2)
                        {
                            scene->clear();
                            CargarImagen(600,400,":/img/ganadorRojo.png");
                        }else if((this->jugadores->elements[1]->secuenciasArmadas)+
                                 (this->jugadores->elements[3]->secuenciasArmadas)==2)
                        {
                            scene->clear();
                            CargarImagen(600,400,":/img/ganadorAzul.png");
                        }else
                        {
                            this->siguienteTurno();
                            this->manoClickeada=0;
                        }
                    }
                }
            }
        }
    }
}

int Controladora::matrizToInt(int i,int j)
{
    //Éste método recibe un i y un j y los convierte a la posición secuencial de la carta en el tablero
    //Sirve para visualizar el tablero como una matriz aunque no lo sea
    int resultado;
    resultado = j+(i*10)-1;
    if(i>0 && i<9)
    {
        resultado=resultado-1;
    }
    if(i==9)
    {
        resultado=resultado-2;
    }
    return resultado;
}

void Controladora::colocarFicha(int pColor)
{
    //Coloca una ficha gráficamente
    QString color;
    if(pColor==1)
    {
        color = ":/img/fichaRoja.png";
    }else if(pColor==2)
    {
        color = ":/img/fichaAzul.png";
    }else if(pColor==3)
    {
        color = ":/img/fichaVerde.png";
    }
    CargarImagen(this->xActual,this->yActual,color);
}

void Controladora::quitarFicha()
{
    //Éste método quita una ficha pero sólo en la parte gráfica, la lógica se hace por aparte
    if(this->clickeado==1){scene->removeItem(this->tablero2);scene->addItem(this->tablero2);}
    if(this->clickeado==2){scene->removeItem(this->tablero3);scene->addItem(this->tablero3);}
    if(this->clickeado==3){scene->removeItem(this->tablero4);scene->addItem(this->tablero4);}
    if(this->clickeado==4){scene->removeItem(this->tablero5);scene->addItem(this->tablero5);}
    if(this->clickeado==5){scene->removeItem(this->tablero6);scene->addItem(this->tablero6);}
    if(this->clickeado==6){scene->removeItem(this->tablero7);scene->addItem(this->tablero7);}
    if(this->clickeado==7){scene->removeItem(this->tablero8);scene->addItem(this->tablero8);}
    if(this->clickeado==8){scene->removeItem(this->tablero9);scene->addItem(this->tablero9);}
    if(this->clickeado==9){scene->removeItem(this->tablero11);scene->addItem(this->tablero11);}

    if(this->clickeado==10){scene->removeItem(this->tablero12);scene->addItem(this->tablero12);}
    if(this->clickeado==11){scene->removeItem(this->tablero13);scene->addItem(this->tablero13);}
    if(this->clickeado==12){scene->removeItem(this->tablero14);scene->addItem(this->tablero14);}
    if(this->clickeado==13){scene->removeItem(this->tablero15);scene->addItem(this->tablero15);}
    if(this->clickeado==14){scene->removeItem(this->tablero16);scene->addItem(this->tablero16);}
    if(this->clickeado==15){scene->removeItem(this->tablero17);scene->addItem(this->tablero17);}
    if(this->clickeado==16){scene->removeItem(this->tablero18);scene->addItem(this->tablero18);}
    if(this->clickeado==17){scene->removeItem(this->tablero19);scene->addItem(this->tablero19);}
    if(this->clickeado==18){scene->removeItem(this->tablero20);scene->addItem(this->tablero20);}
    if(this->clickeado==19){scene->removeItem(this->tablero21);scene->addItem(this->tablero21);}

    if(this->clickeado==20){scene->removeItem(this->tablero22);scene->addItem(this->tablero22);}
    if(this->clickeado==21){scene->removeItem(this->tablero23);scene->addItem(this->tablero23);}
    if(this->clickeado==22){scene->removeItem(this->tablero24);scene->addItem(this->tablero24);}
    if(this->clickeado==23){scene->removeItem(this->tablero25);scene->addItem(this->tablero25);}
    if(this->clickeado==24){scene->removeItem(this->tablero26);scene->addItem(this->tablero26);}
    if(this->clickeado==25){scene->removeItem(this->tablero27);scene->addItem(this->tablero27);}
    if(this->clickeado==26){scene->removeItem(this->tablero28);scene->addItem(this->tablero28);}
    if(this->clickeado==27){scene->removeItem(this->tablero29);scene->addItem(this->tablero29);}
    if(this->clickeado==28){scene->removeItem(this->tablero30);scene->addItem(this->tablero30);}
    if(this->clickeado==29){scene->removeItem(this->tablero31);scene->addItem(this->tablero31);}

    if(this->clickeado==30){scene->removeItem(this->tablero32);scene->addItem(this->tablero32);}
    if(this->clickeado==31){scene->removeItem(this->tablero33);scene->addItem(this->tablero33);}
    if(this->clickeado==32){scene->removeItem(this->tablero34);scene->addItem(this->tablero34);}
    if(this->clickeado==33){scene->removeItem(this->tablero35);scene->addItem(this->tablero35);}
    if(this->clickeado==34){scene->removeItem(this->tablero36);scene->addItem(this->tablero36);}
    if(this->clickeado==35){scene->removeItem(this->tablero37);scene->addItem(this->tablero37);}
    if(this->clickeado==36){scene->removeItem(this->tablero38);scene->addItem(this->tablero38);}
    if(this->clickeado==37){scene->removeItem(this->tablero39);scene->addItem(this->tablero39);}
    if(this->clickeado==38){scene->removeItem(this->tablero40);scene->addItem(this->tablero40);}
    if(this->clickeado==39){scene->removeItem(this->tablero41);scene->addItem(this->tablero41);}

    if(this->clickeado==40){scene->removeItem(this->tablero42);scene->addItem(this->tablero42);}
    if(this->clickeado==41){scene->removeItem(this->tablero43);scene->addItem(this->tablero43);}
    if(this->clickeado==42){scene->removeItem(this->tablero44);scene->addItem(this->tablero44);}
    if(this->clickeado==43){scene->removeItem(this->tablero45);scene->addItem(this->tablero45);}
    if(this->clickeado==44){scene->removeItem(this->tablero46);scene->addItem(this->tablero46);}
    if(this->clickeado==45){scene->removeItem(this->tablero47);scene->addItem(this->tablero47);}
    if(this->clickeado==46){scene->removeItem(this->tablero48);scene->addItem(this->tablero48);}
    if(this->clickeado==47){scene->removeItem(this->tablero49);scene->addItem(this->tablero49);}
    if(this->clickeado==48){scene->removeItem(this->tablero50);scene->addItem(this->tablero50);}
    if(this->clickeado==49){scene->removeItem(this->tablero51);scene->addItem(this->tablero51);}

    if(this->clickeado==50){scene->removeItem(this->tablero52);scene->addItem(this->tablero52);}
    if(this->clickeado==51){scene->removeItem(this->tablero53);scene->addItem(this->tablero53);}
    if(this->clickeado==52){scene->removeItem(this->tablero54);scene->addItem(this->tablero54);}
    if(this->clickeado==53){scene->removeItem(this->tablero55);scene->addItem(this->tablero55);}
    if(this->clickeado==54){scene->removeItem(this->tablero56);scene->addItem(this->tablero56);}
    if(this->clickeado==55){scene->removeItem(this->tablero57);scene->addItem(this->tablero57);}
    if(this->clickeado==56){scene->removeItem(this->tablero58);scene->addItem(this->tablero58);}
    if(this->clickeado==57){scene->removeItem(this->tablero59);scene->addItem(this->tablero59);}
    if(this->clickeado==58){scene->removeItem(this->tablero60);scene->addItem(this->tablero60);}
    if(this->clickeado==59){scene->removeItem(this->tablero61);scene->addItem(this->tablero61);}

    if(this->clickeado==60){scene->removeItem(this->tablero62);scene->addItem(this->tablero62);}
    if(this->clickeado==61){scene->removeItem(this->tablero63);scene->addItem(this->tablero63);}
    if(this->clickeado==62){scene->removeItem(this->tablero64);scene->addItem(this->tablero64);}
    if(this->clickeado==63){scene->removeItem(this->tablero65);scene->addItem(this->tablero65);}
    if(this->clickeado==64){scene->removeItem(this->tablero66);scene->addItem(this->tablero66);}
    if(this->clickeado==65){scene->removeItem(this->tablero67);scene->addItem(this->tablero67);}
    if(this->clickeado==66){scene->removeItem(this->tablero68);scene->addItem(this->tablero68);}
    if(this->clickeado==67){scene->removeItem(this->tablero69);scene->addItem(this->tablero69);}
    if(this->clickeado==68){scene->removeItem(this->tablero70);scene->addItem(this->tablero70);}
    if(this->clickeado==69){scene->removeItem(this->tablero71);scene->addItem(this->tablero71);}

    if(this->clickeado==70){scene->removeItem(this->tablero72);scene->addItem(this->tablero72);}
    if(this->clickeado==71){scene->removeItem(this->tablero73);scene->addItem(this->tablero73);}
    if(this->clickeado==72){scene->removeItem(this->tablero74);scene->addItem(this->tablero74);}
    if(this->clickeado==73){scene->removeItem(this->tablero75);scene->addItem(this->tablero75);}
    if(this->clickeado==74){scene->removeItem(this->tablero76);scene->addItem(this->tablero76);}
    if(this->clickeado==75){scene->removeItem(this->tablero77);scene->addItem(this->tablero77);}
    if(this->clickeado==76){scene->removeItem(this->tablero78);scene->addItem(this->tablero78);}
    if(this->clickeado==77){scene->removeItem(this->tablero79);scene->addItem(this->tablero79);}
    if(this->clickeado==78){scene->removeItem(this->tablero80);scene->addItem(this->tablero80);}
    if(this->clickeado==79){scene->removeItem(this->tablero81);scene->addItem(this->tablero81);}

    if(this->clickeado==80){scene->removeItem(this->tablero82);scene->addItem(this->tablero82);}
    if(this->clickeado==81){scene->removeItem(this->tablero83);scene->addItem(this->tablero83);}
    if(this->clickeado==82){scene->removeItem(this->tablero84);scene->addItem(this->tablero84);}
    if(this->clickeado==83){scene->removeItem(this->tablero85);scene->addItem(this->tablero85);}
    if(this->clickeado==84){scene->removeItem(this->tablero86);scene->addItem(this->tablero86);}
    if(this->clickeado==85){scene->removeItem(this->tablero87);scene->addItem(this->tablero87);}
    if(this->clickeado==86){scene->removeItem(this->tablero88);scene->addItem(this->tablero88);}
    if(this->clickeado==87){scene->removeItem(this->tablero89);scene->addItem(this->tablero89);}
    if(this->clickeado==88){scene->removeItem(this->tablero90);scene->addItem(this->tablero90);}
    if(this->clickeado==89){scene->removeItem(this->tablero92);scene->addItem(this->tablero92);}

    if(this->clickeado==90){scene->removeItem(this->tablero93);scene->addItem(this->tablero93);}
    if(this->clickeado==91){scene->removeItem(this->tablero94);scene->addItem(this->tablero94);}
    if(this->clickeado==92){scene->removeItem(this->tablero95);scene->addItem(this->tablero95);}
    if(this->clickeado==93){scene->removeItem(this->tablero96);scene->addItem(this->tablero96);}
    if(this->clickeado==94){scene->removeItem(this->tablero97);scene->addItem(this->tablero97);}
    if(this->clickeado==95){scene->removeItem(this->tablero98);scene->addItem(this->tablero98);}
    if(this->clickeado==96){scene->removeItem(this->tablero99);scene->addItem(this->tablero99);}
}

ArrayStack<Carta*>* Controladora::barajarBaraja(ArrayStack<Carta*>* original)//Randomiza la baraja
{
    srand(time(NULL));
    barajaAleatoria = new ArrayStack<Carta*>(BARAJA_MAX_SIZE);//Crea una nueva baraja destino
    for(int i = 0; i < original->getSize(); i++){barajaAleatoria->push(original->elements[i]);}//Inserta todos los elementos de la baraja origen tal y como vienen
    bool espacioUsado[BARAJA_MAX_SIZE];//Crea un ArrayList de booleanos que se utiliza para no repetir usados
    for (int i=0;i<BARAJA_MAX_SIZE;i++) {espacioUsado[i]=false;}//Inicializa todos los valores en false
    int index=0;//Inicializa una variable índice
    for (int i=0;i<BARAJA_MAX_SIZE;i++)
    {
        do{index = 0 + rand() % (BARAJA_MAX_SIZE - 0);}//Genera aleatorios hasta encontrar uno que no se haya usado (Según arreglo de booleanos)
        while (espacioUsado[index]);
        barajaAleatoria->elements[i] = original->elements[index];//Realiza un swap de índices
        espacioUsado[index]=true;//Setea el valor booleano de ese índice en true
    }
    return barajaAleatoria;
}

ArrayList<Carta*>* Controladora::randomizarTablero(ArrayList<Carta*>* original)//Utilizado para generar el tablero aleatorio
{
    //Funciona exactamente como el método anterior
    srand(time(NULL));
    tableroRandomizado = new ArrayList<Carta*>(TABLERO_MAX_SIZE);
    for(int i = 0; i < original->getSize()-1; i++) {tableroRandomizado->append(original->elements[i]);}
    bool espacioUsado[TABLERO_MAX_SIZE];
    for (int i=0;i<TABLERO_MAX_SIZE;i++) {espacioUsado[i]=false;}
    int index=0;
    for (int i=0;i<TABLERO_MAX_SIZE;i++)
    {
        do{index = 0 + rand() % (TABLERO_MAX_SIZE - 0);}
        while (espacioUsado[index]);
        tableroRandomizado->elements[i] = original->elements[index];
        espacioUsado[index]=true;
    }
    return tableroRandomizado;
}

void Controladora::creaTablero() //Crea 100 botones, que son los utilizados en el tablero
{
    int imagen = 0;//Utilizado para sacar la imagen del botón según el arrayList de cartas
    int i = 220;//Utilizado para la posoción x del botón
    int j = 20;//Utilizado para la posoción y del botón
    this->tablero1 = new Boton(":/img/4esquinas.png",i,j);
    scene->addItem(tablero1);
    i = i+101;

    this->tablero2 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero2, SIGNAL(clicked()), this, SLOT(click1()));
    connect(tablero2, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero2);
    imagen++;
    i = i+101;

    this->tablero3 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero3, SIGNAL(clicked()), this, SLOT(click2()));
    connect(tablero3, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero3);
    imagen++;
    i = i+101;

    this->tablero4 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero4, SIGNAL(clicked()), this, SLOT(click3()));
    connect(tablero4, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero4);
    imagen++;
    i = i+101;

    this->tablero5 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero5, SIGNAL(clicked()), this, SLOT(click4()));
    connect(tablero5, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero5);
    imagen++;
    i = i+101;

    this->tablero6 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero6, SIGNAL(clicked()), this, SLOT(click5()));
    connect(tablero6, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero6);
    imagen++;
    i = i+101;

    this->tablero7 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero7, SIGNAL(clicked()), this, SLOT(click6()));
    connect(tablero7, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero7);
    imagen++;
    i = i+101;

    this->tablero8 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero8, SIGNAL(clicked()), this, SLOT(click7()));
    connect(tablero8, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero8);
    imagen++;
    i = i+101;

    this->tablero9 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero9, SIGNAL(clicked()), this, SLOT(click8()));
    connect(tablero9, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero9);
    imagen++;
    i = i+101;

    this->tablero10 = new Boton(":/img/4esquinas.png",i,j);
    scene->addItem(tablero10);
    i = 220;
    j = j+70;

    this->tablero11 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero11, SIGNAL(clicked()), this, SLOT(click9()));
    connect(tablero11, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero11);
    imagen++;
    i = i+101;

    this->tablero12 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero12, SIGNAL(clicked()), this, SLOT(click10()));
    connect(tablero12, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero12);
    imagen++;
    i = i+101;

    this->tablero13 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero13, SIGNAL(clicked()), this, SLOT(click11()));
    connect(tablero13, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero13);
    imagen++;
    i = i+101;

    this->tablero14 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero14, SIGNAL(clicked()), this, SLOT(click12()));
    connect(tablero14, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero14);
    imagen++;
    i = i+101;

    this->tablero15 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero15, SIGNAL(clicked()), this, SLOT(click13()));
    connect(tablero15, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero15);
    imagen++;
    i = i+101;

    this->tablero16 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero16, SIGNAL(clicked()), this, SLOT(click14()));
    connect(tablero16, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero16);
    imagen++;
    i = i+101;

    this->tablero17 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero17, SIGNAL(clicked()), this, SLOT(click15()));
    connect(tablero17, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero17);
    imagen++;
    i = i+101;

    this->tablero18 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero18, SIGNAL(clicked()), this, SLOT(click16()));
    connect(tablero18, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero18);
    imagen++;
    i = i+101;

    this->tablero19 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero19, SIGNAL(clicked()), this, SLOT(click17()));
    connect(tablero19, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero19);
    imagen++;
    i = i+101;

    this->tablero20 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero20, SIGNAL(clicked()), this, SLOT(click18()));
    connect(tablero20, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero20);
    imagen++;
    i = 220;
    j = j+70;

    this->tablero21 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero21, SIGNAL(clicked()), this, SLOT(click19()));
    connect(tablero21, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero21);
    imagen++;
    i = i+101;

    this->tablero22 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero22, SIGNAL(clicked()), this, SLOT(click20()));
    connect(tablero22, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero22);
    imagen++;
    i = i+101;

    this->tablero23 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero23, SIGNAL(clicked()), this, SLOT(click21()));
    connect(tablero23, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero23);
    imagen++;
    i = i+101;

    this->tablero24 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero24, SIGNAL(clicked()), this, SLOT(click22()));
    connect(tablero24, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero24);
    imagen++;
    i = i+101;

    this->tablero25 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero25, SIGNAL(clicked()), this, SLOT(click23()));
    connect(tablero25, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero25);
    imagen++;
    i = i+101;

    this->tablero26 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero26, SIGNAL(clicked()), this, SLOT(click24()));
    connect(tablero26, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero26);
    imagen++;
    i = i+101;

    this->tablero27 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero27, SIGNAL(clicked()), this, SLOT(click25()));
    connect(tablero27, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero27);
    imagen++;
    i = i+101;

    this->tablero28 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero28, SIGNAL(clicked()), this, SLOT(click26()));
    connect(tablero28, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero28);
    imagen++;
    i = i+101;

    this->tablero29 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero29, SIGNAL(clicked()), this, SLOT(click27()));
    connect(tablero29, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero29);
    imagen++;
    i = i+101;

    this->tablero30 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero30, SIGNAL(clicked()), this, SLOT(click28()));
    connect(tablero30, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero30);
    imagen++;
    i = 220;
    j = j+70;

    this->tablero31 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero31, SIGNAL(clicked()), this, SLOT(click29()));
    connect(tablero31, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero31);
    imagen++;
    i = i+101;

    this->tablero32 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero32, SIGNAL(clicked()), this, SLOT(click30()));
    connect(tablero32, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero32);
    imagen++;
    i = i+101;

    this->tablero33 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero33, SIGNAL(clicked()), this, SLOT(click31()));
    connect(tablero33, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero33);
    imagen++;
    i = i+101;

    this->tablero34 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero34, SIGNAL(clicked()), this, SLOT(click32()));
    connect(tablero34, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero34);
    imagen++;
    i = i+101;

    this->tablero35 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero35, SIGNAL(clicked()), this, SLOT(click33()));
    connect(tablero35, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero35);
    imagen++;
    i = i+101;

    this->tablero36 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero36, SIGNAL(clicked()), this, SLOT(click34()));
    connect(tablero36, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero36);
    imagen++;
    i = i+101;

    this->tablero37 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero37, SIGNAL(clicked()), this, SLOT(click35()));
    connect(tablero37, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero37);
    imagen++;
    i = i+101;

    this->tablero38 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero38, SIGNAL(clicked()), this, SLOT(click36()));
    connect(tablero38, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero38);
    imagen++;
    i = i+101;

    this->tablero39 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero39, SIGNAL(clicked()), this, SLOT(click37()));
    connect(tablero39, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero39);
    imagen++;
    i = i+101;

    this->tablero40 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero40, SIGNAL(clicked()), this, SLOT(click38()));
    connect(tablero40, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero40);
    imagen++;
    i = 220;
    j = j+70;

    this->tablero41 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero41, SIGNAL(clicked()), this, SLOT(click39()));
    connect(tablero41, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero41);
    imagen++;
    i = i+101;

    this->tablero42 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero42, SIGNAL(clicked()), this, SLOT(click40()));
    connect(tablero42, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero42);
    imagen++;
    i = i+101;

    this->tablero43 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero43, SIGNAL(clicked()), this, SLOT(click41()));
    connect(tablero43, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero43);
    imagen++;
    i = i+101;

    this->tablero44 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero44, SIGNAL(clicked()), this, SLOT(click42()));
    connect(tablero44, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero44);
    imagen++;
    i = i+101;

    this->tablero45 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero45, SIGNAL(clicked()), this, SLOT(click43()));
    connect(tablero45, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero45);
    imagen++;
    i = i+101;

    this->tablero46 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero46, SIGNAL(clicked()), this, SLOT(click44()));
    connect(tablero46, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero46);
    imagen++;
    i = i+101;

    this->tablero47 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero47, SIGNAL(clicked()), this, SLOT(click45()));
    connect(tablero47, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero47);
    imagen++;
    i = i+101;

    this->tablero48 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero48, SIGNAL(clicked()), this, SLOT(click46()));
    connect(tablero48, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero48);
    imagen++;
    i = i+101;

    this->tablero49 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero49, SIGNAL(clicked()), this, SLOT(click47()));
    connect(tablero49, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero49);
    imagen++;
    i = i+101;

    this->tablero50 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero50, SIGNAL(clicked()), this, SLOT(click48()));
    connect(tablero50, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero50);
    imagen++;
    i = 220;
    j = j+70;

    this->tablero51 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero51, SIGNAL(clicked()), this, SLOT(click49()));
    connect(tablero51, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero51);
    imagen++;
    i = i+101;

    this->tablero52 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero52, SIGNAL(clicked()), this, SLOT(click50()));
    connect(tablero52, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero52);
    imagen++;
    i = i+101;

    this->tablero53 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero53, SIGNAL(clicked()), this, SLOT(click51()));
    connect(tablero53, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero53);
    imagen++;
    i = i+101;

    this->tablero54 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero54, SIGNAL(clicked()), this, SLOT(click52()));
    connect(tablero54, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero54);
    imagen++;
    i = i+101;

    this->tablero55 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero55, SIGNAL(clicked()), this, SLOT(click53()));
    connect(tablero55, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero55);
    imagen++;
    i = i+101;

    this->tablero56 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero56, SIGNAL(clicked()), this, SLOT(click54()));
    connect(tablero56, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero56);
    imagen++;
    i = i+101;

    this->tablero57 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero57, SIGNAL(clicked()), this, SLOT(click55()));
    connect(tablero57, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero57);
    imagen++;
    i = i+101;

    this->tablero58 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero58, SIGNAL(clicked()), this, SLOT(click56()));
    connect(tablero58, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero58);
    imagen++;
    i = i+101;

    this->tablero59 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero59, SIGNAL(clicked()), this, SLOT(click57()));
    connect(tablero59, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero59);
    imagen++;
    i = i+101;

    this->tablero60 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero60, SIGNAL(clicked()), this, SLOT(click58()));
    connect(tablero60, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero60);
    imagen++;
    i = 220;
    j = j+70;

    this->tablero61 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero61, SIGNAL(clicked()), this, SLOT(click59()));
    connect(tablero61, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero61);
    imagen++;
    i = i+101;

    this->tablero62 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero62, SIGNAL(clicked()), this, SLOT(click60()));
    connect(tablero62, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero62);
    imagen++;
    i = i+101;

    this->tablero63 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero63, SIGNAL(clicked()), this, SLOT(click61()));
    connect(tablero63, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero63);
    imagen++;
    i = i+101;

    this->tablero64 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero64, SIGNAL(clicked()), this, SLOT(click62()));
    connect(tablero64, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero64);
    imagen++;
    i = i+101;

    this->tablero65 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero65, SIGNAL(clicked()), this, SLOT(click63()));
    connect(tablero65, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero65);
    imagen++;
    i = i+101;

    this->tablero66 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero66, SIGNAL(clicked()), this, SLOT(click64()));
    connect(tablero66, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero66);
    imagen++;
    i = i+101;

    this->tablero67 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero67, SIGNAL(clicked()), this, SLOT(click65()));
    connect(tablero67, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero67);
    imagen++;
    i = i+101;

    this->tablero68 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero68, SIGNAL(clicked()), this, SLOT(click66()));
    connect(tablero68, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero68);
    imagen++;
    i = i+101;

    this->tablero69 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero69, SIGNAL(clicked()), this, SLOT(click67()));
    connect(tablero69, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero69);
    imagen++;
    i = i+101;

    this->tablero70 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero70, SIGNAL(clicked()), this, SLOT(click68()));
    connect(tablero70, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero70);
    imagen++;
    i = 220;
    j = j+70;

    this->tablero71 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero71, SIGNAL(clicked()), this, SLOT(click69()));
    connect(tablero71, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero71);
    imagen++;
    i = i+101;

    this->tablero72 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero72, SIGNAL(clicked()), this, SLOT(click70()));
    connect(tablero72, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero72);
    imagen++;
    i = i+101;

    this->tablero73 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero73, SIGNAL(clicked()), this, SLOT(click71()));
    connect(tablero73, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero73);
    imagen++;
    i = i+101;

    this->tablero74 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero74, SIGNAL(clicked()), this, SLOT(click72()));
    connect(tablero74, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero74);
    imagen++;
    i = i+101;

    this->tablero75 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero75, SIGNAL(clicked()), this, SLOT(click73()));
    connect(tablero75, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero75);
    imagen++;
    i = i+101;

    this->tablero76 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero76, SIGNAL(clicked()), this, SLOT(click74()));
    connect(tablero76, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero76);
    imagen++;
    i = i+101;

    this->tablero77 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero77, SIGNAL(clicked()), this, SLOT(click75()));
    connect(tablero77, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero77);
    imagen++;
    i = i+101;

    this->tablero78 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero78, SIGNAL(clicked()), this, SLOT(click76()));
    connect(tablero78, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero78);
    imagen++;
    i = i+101;

    this->tablero79 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero79, SIGNAL(clicked()), this, SLOT(click77()));
    connect(tablero79, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero79);
    imagen++;
    i = i+101;

    this->tablero80 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero80, SIGNAL(clicked()), this, SLOT(click78()));
    connect(tablero80, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero80);
    imagen++;
    i = 220;
    j = j+70;

    this->tablero81 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero81, SIGNAL(clicked()), this, SLOT(click79()));
    connect(tablero81, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero81);
    imagen++;
    i = i+101;

    this->tablero82 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero82, SIGNAL(clicked()), this, SLOT(click80()));
    connect(tablero82, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero82);
    imagen++;
    i = i+101;

    this->tablero83 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero83, SIGNAL(clicked()), this, SLOT(click81()));
    connect(tablero83, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero83);
    imagen++;
    i = i+101;

    this->tablero84 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero84, SIGNAL(clicked()), this, SLOT(click82()));
    connect(tablero84, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero84);
    imagen++;
    i = i+101;

    this->tablero85 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero85, SIGNAL(clicked()), this, SLOT(click83()));
    connect(tablero85, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero85);
    imagen++;
    i = i+101;

    this->tablero86 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero86, SIGNAL(clicked()), this, SLOT(click84()));
    connect(tablero86, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero86);
    imagen++;
    i = i+101;

    this->tablero87 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero87, SIGNAL(clicked()), this, SLOT(click85()));
    connect(tablero87, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero87);
    imagen++;
    i = i+101;

    this->tablero88 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero88, SIGNAL(clicked()), this, SLOT(click86()));
    connect(tablero88, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero88);
    imagen++;
    i = i+101;

    this->tablero89 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero89, SIGNAL(clicked()), this, SLOT(click87()));
    connect(tablero89, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero89);
    imagen++;
    i = i+101;

    this->tablero90 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero90, SIGNAL(clicked()), this, SLOT(click88()));
    connect(tablero90, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero90);
    imagen++;
    i = 220;
    j = j+70;

    this->tablero91 = new Boton(":/img/4esquinas.png",i,j);
    scene->addItem(tablero91);
    i = i+101;

    this->tablero92 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero92, SIGNAL(clicked()), this, SLOT(click89()));
    connect(tablero92, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero92);
    imagen++;
    i = i+101;

    this->tablero93 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero93, SIGNAL(clicked()), this, SLOT(click90()));
    connect(tablero93, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero93);
    imagen++;
    i = i+101;

    this->tablero94 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero94, SIGNAL(clicked()), this, SLOT(click91()));
    connect(tablero94, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero94);
    imagen++;
    i = i+101;

    this->tablero95 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero95, SIGNAL(clicked()), this, SLOT(click92()));
    connect(tablero95, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero95);
    imagen++;
    i = i+101;

    this->tablero96 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero96, SIGNAL(clicked()), this, SLOT(click93()));
    connect(tablero96, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero96);
    imagen++;
    i = i+101;

    this->tablero97 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero97, SIGNAL(clicked()), this, SLOT(click94()));
    connect(tablero97, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero97);
    imagen++;
    i = i+101;

    this->tablero98 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero98, SIGNAL(clicked()), this, SLOT(click95()));
    connect(tablero98, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero98);
    imagen++;
    i = i+101;

    this->tablero99 = new Boton(this->cartas->elements[imagen]->getNombre(),i,j);
    connect(tablero99, SIGNAL(clicked()), this, SLOT(click96()));
    connect(tablero99, SIGNAL(clicked()), this, SLOT(validacionJugada()));
    scene->addItem(tablero99);
    imagen++;
    i = i+101;

    this->tablero100 = new Boton(":/img/4esquinas.png",i,j);
    scene->addItem(tablero100);

    Boton *barajaTablero = new Boton(":/img/4esquinas.png",130,300);
    barajaTablero->setRotation(90);
    scene->addItem(barajaTablero);

    this->cementerioTablero = new Boton(":/img/4esquinas.png",1370,300);
    cementerioTablero->setRotation(90);
    scene->addItem(cementerioTablero);
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////Metodos SLOT////////////////////////////////////////////////////////////////////////
void Controladora::clean()
{
    //Limpia la scena
    scene->clear();
}

void Controladora::tablero_2_Jugadores()//Es el slot para la creación de un tablero cuando se seleccionaron 2 jugadores
{
    this->clean();

    Boton *tableroNormal = new Boton(":/img/tableroNormal.png",100,400);//Crea y muestra el botón para preguntar el tipo de tablero
    connect(tableroNormal, SIGNAL(clicked()), this, SLOT(tableroNormal()));
    scene->addItem(tableroNormal);

    Boton *tableroAleatorio = new Boton(":/img/tableroAleatorio.png",900,400);//Crea y muestra el botón para preguntar el tipo de tablero
    connect(tableroAleatorio, SIGNAL(clicked()), this, SLOT(tableroAleatorio()));
    scene->addItem(tableroAleatorio);

    this->numeroJugadores=2;
}

void Controladora::tablero_3_Jugadores()//Es el slot para la creación de un tablero cuando se seleccionaron 3 jugadores
{
    this->clean();

    Boton *tableroNormal = new Boton(":/img/tableroNormal.png",100,400);//Crea y muestra el botón para preguntar el tipo de tablero
    connect(tableroNormal, SIGNAL(clicked()), this, SLOT(tableroNormal()));
    scene->addItem(tableroNormal);

    Boton *tableroAleatorio = new Boton(":/img/tableroAleatorio.png",900,400);//Crea y muestra el botón para preguntar el tipo de tablero
    connect(tableroAleatorio, SIGNAL(clicked()), this, SLOT(tableroAleatorio()));
    scene->addItem(tableroAleatorio);

    this->numeroJugadores=3;
}

void Controladora::tablero_4_Jugadores()//Es el slot para la creación de un tablero cuando se seleccionaron 4 jugadores
{
    this->clean();

    Boton *tableroNormal = new Boton(":/img/tableroNormal.png",100,400);//Crea y muestra el botón para preguntar el tipo de tablero
    connect(tableroNormal, SIGNAL(clicked()), this, SLOT(tableroNormal()));
    scene->addItem(tableroNormal);

    Boton *tableroAleatorio = new Boton(":/img/tableroAleatorio.png",900,400);//Crea y muestra el botón para preguntar el tipo de tablero
    connect(tableroAleatorio, SIGNAL(clicked()), this, SLOT(tableroAleatorio()));
    scene->addItem(tableroAleatorio);

    this->numeroJugadores=4;
}

void Controladora::tableroNormal()//Genera el tablero en su orden original, así como las estructuras necesarias para jugar
{
    this->clean();
    creaTablero();
    creaJugadores();
    reparteCartas();
    creaManoJugador();
}

void Controladora::tableroAleatorio()//Genera el tablero en su orden original, así como las estructuras necesarias para jugar
{
    this->clean();
    nuevo = randomizarTablero(this->cartas);
    this->cartas = nuevo;
    creaTablero();
    creaJugadores();
    reparteCartas();
    creaManoJugador();
}

//Todos los siguientes son slots correspondientes al click de uno de los botones
//Dan su posición en X y en Y, además de su posición convertida al ArrayList de cartas
void Controladora::click1(){this->clickeado=1;this->xActual=346;this->yActual=30;}
void Controladora::click2(){this->clickeado=2;this->xActual=447;this->yActual=30;}
void Controladora::click3(){this->clickeado=3;this->xActual=548;this->yActual=30;}
void Controladora::click4(){this->clickeado=4;this->xActual=649;this->yActual=30;}
void Controladora::click5(){this->clickeado=5;this->xActual=750;this->yActual=30;}
void Controladora::click6(){this->clickeado=6;this->xActual=851;this->yActual=30;}
void Controladora::click7(){this->clickeado=7;this->xActual=952;this->yActual=30;}
void Controladora::click8(){this->clickeado=8;this->xActual=1053;this->yActual=30;}

void Controladora::click9(){this->clickeado=9;this->xActual=245;this->yActual=100;}
void Controladora::click10(){this->clickeado=10;this->xActual=346;this->yActual=100;}
void Controladora::click11(){this->clickeado=11;this->xActual=447;this->yActual=100;}
void Controladora::click12(){this->clickeado=12;this->xActual=548;this->yActual=100;}
void Controladora::click13(){this->clickeado=13;this->xActual=649;this->yActual=100;}
void Controladora::click14(){this->clickeado=14;this->xActual=750;this->yActual=100;}
void Controladora::click15(){this->clickeado=15;this->xActual=851;this->yActual=100;}
void Controladora::click16(){this->clickeado=16;this->xActual=952;this->yActual=100;}
void Controladora::click17(){this->clickeado=17;this->xActual=1053;this->yActual=100;}
void Controladora::click18(){this->clickeado=18;this->xActual=1154;this->yActual=100;}

void Controladora::click19(){this->clickeado=19;this->xActual=245;this->yActual=170;}
void Controladora::click20(){this->clickeado=20;this->xActual=346;this->yActual=170;}
void Controladora::click21(){this->clickeado=21;this->xActual=447;this->yActual=170;}
void Controladora::click22(){this->clickeado=22;this->xActual=548;this->yActual=170;}
void Controladora::click23(){this->clickeado=23;this->xActual=649;this->yActual=170;}
void Controladora::click24(){this->clickeado=24;this->xActual=750;this->yActual=170;}
void Controladora::click25(){this->clickeado=25;this->xActual=851;this->yActual=170;}
void Controladora::click26(){this->clickeado=26;this->xActual=952;this->yActual=170;}
void Controladora::click27(){this->clickeado=27;this->xActual=1053;this->yActual=170;}
void Controladora::click28(){this->clickeado=28;this->xActual=1154;this->yActual=170;}

void Controladora::click29(){this->clickeado=29;this->xActual=245;this->yActual=240;}
void Controladora::click30(){this->clickeado=30;this->xActual=346;this->yActual=240;}
void Controladora::click31(){this->clickeado=31;this->xActual=447;this->yActual=240;}
void Controladora::click32(){this->clickeado=32;this->xActual=548;this->yActual=240;}
void Controladora::click33(){this->clickeado=33;this->xActual=649;this->yActual=240;}
void Controladora::click34(){this->clickeado=34;this->xActual=750;this->yActual=240;}
void Controladora::click35(){this->clickeado=35;this->xActual=851;this->yActual=240;}
void Controladora::click36(){this->clickeado=36;this->xActual=952;this->yActual=240;}
void Controladora::click37(){this->clickeado=37;this->xActual=1053;this->yActual=240;}
void Controladora::click38(){this->clickeado=38;this->xActual=1154;this->yActual=240;}

void Controladora::click39(){this->clickeado=39;this->xActual=245;this->yActual=310;}
void Controladora::click40(){this->clickeado=40;this->xActual=346;this->yActual=310;}
void Controladora::click41(){this->clickeado=41;this->xActual=447;this->yActual=310;}
void Controladora::click42(){this->clickeado=42;this->xActual=548;this->yActual=310;}
void Controladora::click43(){this->clickeado=43;this->xActual=649;this->yActual=310;}
void Controladora::click44(){this->clickeado=44;this->xActual=750;this->yActual=310;}
void Controladora::click45(){this->clickeado=45;this->xActual=851;this->yActual=310;}
void Controladora::click46(){this->clickeado=46;this->xActual=952;this->yActual=310;}
void Controladora::click47(){this->clickeado=47;this->xActual=1053;this->yActual=310;}
void Controladora::click48(){this->clickeado=48;this->xActual=1154;this->yActual=310;}

void Controladora::click49(){this->clickeado=49;this->xActual=245;this->yActual=380;}
void Controladora::click50(){this->clickeado=50;this->xActual=346;this->yActual=380;}
void Controladora::click51(){this->clickeado=51;this->xActual=447;this->yActual=380;}
void Controladora::click52(){this->clickeado=52;this->xActual=548;this->yActual=380;}
void Controladora::click53(){this->clickeado=53;this->xActual=649;this->yActual=380;}
void Controladora::click54(){this->clickeado=54;this->xActual=750;this->yActual=380;}
void Controladora::click55(){this->clickeado=55;this->xActual=851;this->yActual=380;}
void Controladora::click56(){this->clickeado=56;this->xActual=952;this->yActual=380;}
void Controladora::click57(){this->clickeado=57;this->xActual=1053;this->yActual=380;}
void Controladora::click58(){this->clickeado=58;this->xActual=1154;this->yActual=380;}

void Controladora::click59(){this->clickeado=59;this->xActual=245;this->yActual=450;}
void Controladora::click60(){this->clickeado=60;this->xActual=346;this->yActual=450;}
void Controladora::click61(){this->clickeado=61;this->xActual=447;this->yActual=450;}
void Controladora::click62(){this->clickeado=62;this->xActual=548;this->yActual=450;}
void Controladora::click63(){this->clickeado=63;this->xActual=649;this->yActual=450;}
void Controladora::click64(){this->clickeado=64;this->xActual=750;this->yActual=450;}
void Controladora::click65(){this->clickeado=65;this->xActual=851;this->yActual=450;}
void Controladora::click66(){this->clickeado=66;this->xActual=952;this->yActual=450;}
void Controladora::click67(){this->clickeado=67;this->xActual=1053;this->yActual=450;}
void Controladora::click68(){this->clickeado=68;this->xActual=1154;this->yActual=450;}

void Controladora::click69(){this->clickeado=69;this->xActual=245;this->yActual=520;}
void Controladora::click70(){this->clickeado=70;this->xActual=346;this->yActual=520;}
void Controladora::click71(){this->clickeado=71;this->xActual=447;this->yActual=520;}
void Controladora::click72(){this->clickeado=72;this->xActual=548;this->yActual=520;}
void Controladora::click73(){this->clickeado=73;this->xActual=649;this->yActual=520;}
void Controladora::click74(){this->clickeado=74;this->xActual=750;this->yActual=520;}
void Controladora::click75(){this->clickeado=75;this->xActual=851;this->yActual=520;}
void Controladora::click76(){this->clickeado=76;this->xActual=952;this->yActual=520;}
void Controladora::click77(){this->clickeado=77;this->xActual=1053;this->yActual=520;}
void Controladora::click78(){this->clickeado=78;this->xActual=1154;this->yActual=520;}

void Controladora::click79(){this->clickeado=79;this->xActual=245;this->yActual=590;}
void Controladora::click80(){this->clickeado=80;this->xActual=346;this->yActual=590;}
void Controladora::click81(){this->clickeado=81;this->xActual=447;this->yActual=590;}
void Controladora::click82(){this->clickeado=82;this->xActual=548;this->yActual=590;}
void Controladora::click83(){this->clickeado=83;this->xActual=649;this->yActual=590;}
void Controladora::click84(){this->clickeado=84;this->xActual=750;this->yActual=590;}
void Controladora::click85(){this->clickeado=85;this->xActual=851;this->yActual=590;}
void Controladora::click86(){this->clickeado=86;this->xActual=952;this->yActual=590;}
void Controladora::click87(){this->clickeado=87;this->xActual=1053;this->yActual=590;}
void Controladora::click88(){this->clickeado=88;this->xActual=1154;this->yActual=590;}

void Controladora::click89(){this->clickeado=89;this->xActual=346;this->yActual=660;}
void Controladora::click90(){this->clickeado=90;this->xActual=447;this->yActual=660;}
void Controladora::click91(){this->clickeado=91;this->xActual=548;this->yActual=660;}
void Controladora::click92(){this->clickeado=92;this->xActual=649;this->yActual=660;}
void Controladora::click93(){this->clickeado=93;this->xActual=750;this->yActual=660;}
void Controladora::click94(){this->clickeado=94;this->xActual=851;this->yActual=660;}
void Controladora::click95(){this->clickeado=95;this->xActual=952;this->yActual=660;}
void Controladora::click96(){this->clickeado=96;this->xActual=1053;this->yActual=660;}

//Éstos últimos son los slots correspondientes a los botones de la mano de jugador
void Controladora::mano1(){this->manoClickeada=1;}
void Controladora::mano2(){this->manoClickeada=2;}
void Controladora::mano3(){this->manoClickeada=3;}
void Controladora::mano4(){this->manoClickeada=4;}
void Controladora::mano5(){this->manoClickeada=5;}
void Controladora::mano6(){this->manoClickeada=6;}
void Controladora::mano7(){this->manoClickeada=7;}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool Controladora::validaHorizontal(int pos)
//Recibe un entero correspondiente a la carta y verifica si forma una secuencia con las siguientes 4 cartas
//También verifica que la carta no esté siendo usada en una secuencia ya creada
{
    if(this->cartas->elements[pos]->getFichaPuesta()!=0 && this->cartas->elements[pos]->getPerteneceSecuencia()==false
            && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+1]->getFichaPuesta()
            && this->cartas->elements[pos+1]->getPerteneceSecuencia()==false
            && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+2]->getFichaPuesta()
            && this->cartas->elements[pos+2]->getPerteneceSecuencia()==false
            && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+3]->getFichaPuesta()
            && this->cartas->elements[pos+3]->getPerteneceSecuencia()==false
            && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+4]->getFichaPuesta()
            && this->cartas->elements[pos+4]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[pos]->setPerteneceSecuencia(true);
        this->cartas->elements[pos+1]->setPerteneceSecuencia(true);
        this->cartas->elements[pos+2]->setPerteneceSecuencia(true);
        this->cartas->elements[pos+3]->setPerteneceSecuencia(true);
        this->cartas->elements[pos+4]->setPerteneceSecuencia(true);
        return true;
    }
    return false;
}

bool Controladora::validaVertical(int pos)
//Recibe un entero correspondiente a la carta y verifica si forma una secuencia con las siguientes 4 cartas verticales
//También verifica que la carta no esté siendo usada en una secuencia ya creada
{
    if(pos<8)//Cuando la carta está en la primera columna hay una excepción por los comodines o jokers
    {
        if(this->cartas->elements[pos]->getFichaPuesta()!=0 && this->cartas->elements[pos]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+9]->getFichaPuesta()
                && this->cartas->elements[pos+9]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+19]->getFichaPuesta()
                && this->cartas->elements[pos+19]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+29]->getFichaPuesta()
                && this->cartas->elements[pos+29]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+39]->getFichaPuesta()
                && this->cartas->elements[pos+39]->getPerteneceSecuencia()==false)
        {
            this->cartas->elements[pos]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+9]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+19]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+29]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+39]->setPerteneceSecuencia(true);
            return true;
        }
    }
    else
    {
        if(this->cartas->elements[pos]->getFichaPuesta()!=0 && this->cartas->elements[pos]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+10]->getFichaPuesta()
                && this->cartas->elements[pos+10]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+20]->getFichaPuesta()
                && this->cartas->elements[pos+20]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+30]->getFichaPuesta()
                && this->cartas->elements[pos+30]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+40]->getFichaPuesta()
                && this->cartas->elements[pos+40]->getPerteneceSecuencia()==false)
        {
            this->cartas->elements[pos]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+10]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+20]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+30]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+40]->setPerteneceSecuencia(true);
            return true;
        }
    }
    return false;
}

bool Controladora::validaDiagonalDerecha(int pos)
//Recibe un entero correspondiente a la carta y verifica si forma una secuencia con las siguientes 4 cartas en diagonal hacia la derecha
//También verifica que la carta no esté siendo usada en una secuencia ya creada
{
    if(pos<8)//Cuando la carta está en la primera columna hay una excepción por los comodines o jokers
    {
        if(this->cartas->elements[pos]->getFichaPuesta()!=0 && this->cartas->elements[pos]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+10]->getFichaPuesta()
                && this->cartas->elements[pos+10]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+21]->getFichaPuesta()
                && this->cartas->elements[pos+21]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+32]->getFichaPuesta()
                && this->cartas->elements[pos+32]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+43]->getFichaPuesta()
                && this->cartas->elements[pos+43]->getPerteneceSecuencia()==false)
        {
            this->cartas->elements[pos]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+10]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+21]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+32]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+43]->setPerteneceSecuencia(true);
            return true;
        }
    }
    else if(pos>47)//Cuando la carta está en la mitad del tablero hay una excepción por los comodines o jokers
    {
        if(this->cartas->elements[pos]->getFichaPuesta()!=0 && this->cartas->elements[pos]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+11]->getFichaPuesta()
                && this->cartas->elements[pos+11]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+22]->getFichaPuesta()
                && this->cartas->elements[pos+22]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+33]->getFichaPuesta()
                && this->cartas->elements[pos+33]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+43]->getFichaPuesta()
                && this->cartas->elements[pos+43]->getPerteneceSecuencia()==false)
        {
            this->cartas->elements[pos]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+11]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+22]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+33]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+43]->setPerteneceSecuencia(true);
            return true;
        }
    }
    else
    {
        if(this->cartas->elements[pos]->getFichaPuesta()!=0 && this->cartas->elements[pos]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+11]->getFichaPuesta()
                && this->cartas->elements[pos+11]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+22]->getFichaPuesta()
                && this->cartas->elements[pos+22]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+33]->getFichaPuesta()
                && this->cartas->elements[pos+33]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+44]->getFichaPuesta()
                && this->cartas->elements[pos+44]->getPerteneceSecuencia()==false)
        {
            this->cartas->elements[pos]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+11]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+22]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+33]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+44]->setPerteneceSecuencia(true);
            return true;
        }
    }
    return false;
}

bool Controladora::validaDiagonalIzquierda(int pos)
//Recibe un entero correspondiente a la carta y verifica si forma una secuencia con las siguientes 4 cartas en diagonal hacia la izquierda
//También verifica que la carta no esté siendo usada en una secuencia ya creada
{
    if(pos<8)//Cuando la carta está en la primera columna hay una excepción por los comodines o jokers
    {
        if(this->cartas->elements[pos]->getFichaPuesta()!=0 && this->cartas->elements[pos]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+8]->getFichaPuesta()
                && this->cartas->elements[pos+8]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+17]->getFichaPuesta()
                && this->cartas->elements[pos+17]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+26]->getFichaPuesta()
                && this->cartas->elements[pos+26]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+35]->getFichaPuesta()
                && this->cartas->elements[pos+35]->getPerteneceSecuencia()==false)
        {
            this->cartas->elements[pos]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+8]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+17]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+26]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+35]->setPerteneceSecuencia(true);
            return true;
        }
    }
    else if(pos>47)//Cuando la carta está en la mitad del tablero hay una excepción por los comodines o jokers
    {
        if(this->cartas->elements[pos]->getFichaPuesta()!=0 && this->cartas->elements[pos]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+9]->getFichaPuesta()
                && this->cartas->elements[pos+9]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+18]->getFichaPuesta()
                && this->cartas->elements[pos+18]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+27]->getFichaPuesta()
                && this->cartas->elements[pos+27]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+35]->getFichaPuesta()
                && this->cartas->elements[pos+35]->getPerteneceSecuencia()==false)
        {
            this->cartas->elements[pos]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+9]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+18]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+27]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+35]->setPerteneceSecuencia(true);
            return true;
        }
    }else
    {
        if(this->cartas->elements[pos]->getFichaPuesta()!=0 && this->cartas->elements[pos]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+9]->getFichaPuesta()
                && this->cartas->elements[pos+9]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+18]->getFichaPuesta()
                && this->cartas->elements[pos+18]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+27]->getFichaPuesta()
                && this->cartas->elements[pos+27]->getPerteneceSecuencia()==false
                && this->cartas->elements[pos]->getFichaPuesta()== this->cartas->elements[pos+36]->getFichaPuesta()
                && this->cartas->elements[pos+36]->getPerteneceSecuencia()==false)
        {
            this->cartas->elements[pos]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+9]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+18]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+27]->setPerteneceSecuencia(true);
            this->cartas->elements[pos+36]->setPerteneceSecuencia(true);
            return true;
        }
    }
    return false;
}

bool Controladora::verificarSecuenciaHorizontal()//Verifica si en el juego se creó una secuencia horizontal
{
    //Verifica primera fila
    if(this->cartas->elements[matrizToInt(0,1)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(0,1)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(0,1)]->getFichaPuesta()== this->cartas->elements[matrizToInt(0,2)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(0,2)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(0,1)]->getFichaPuesta()== this->cartas->elements[matrizToInt(0,3)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(0,3)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(0,1)]->getFichaPuesta()== this->cartas->elements[matrizToInt(0,4)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(0,4)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(0,1)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(0,2)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(0,3)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(0,4)]->setPerteneceSecuencia(true);
        return true;
    }
    if(validaHorizontal(matrizToInt(0,2))){return true;}
    if(validaHorizontal(matrizToInt(0,3))){return true;}
    if(validaHorizontal(matrizToInt(0,4))){return true;}
    if(this->cartas->elements[matrizToInt(0,5)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(0,5)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(0,5)]->getFichaPuesta()== this->cartas->elements[matrizToInt(0,6)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(0,6)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(0,5)]->getFichaPuesta()== this->cartas->elements[matrizToInt(0,7)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(0,7)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(0,5)]->getFichaPuesta()== this->cartas->elements[matrizToInt(0,8)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(0,8)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(0,5)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(0,6)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(0,7)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(0,8)]->setPerteneceSecuencia(true);
        return true;
    }

    //Verifica segunda fila
    if(validaHorizontal(matrizToInt(1,0))){return true;}
    if(validaHorizontal(matrizToInt(1,1))){return true;}
    if(validaHorizontal(matrizToInt(1,2))){return true;}
    if(validaHorizontal(matrizToInt(1,3))){return true;}
    if(validaHorizontal(matrizToInt(1,4))){return true;}
    if(validaHorizontal(matrizToInt(1,5))){return true;}

    //Verifica tercera fila
    if(validaHorizontal(matrizToInt(2,0))){return true;}
    if(validaHorizontal(matrizToInt(2,1))){return true;}
    if(validaHorizontal(matrizToInt(2,2))){return true;}
    if(validaHorizontal(matrizToInt(2,3))){return true;}
    if(validaHorizontal(matrizToInt(2,4))){return true;}
    if(validaHorizontal(matrizToInt(2,5))){return true;}

    //Verifica cuarta fila
    if(validaHorizontal(matrizToInt(3,0))){return true;}
    if(validaHorizontal(matrizToInt(3,1))){return true;}
    if(validaHorizontal(matrizToInt(3,2))){return true;}
    if(validaHorizontal(matrizToInt(3,3))){return true;}
    if(validaHorizontal(matrizToInt(3,4))){return true;}
    if(validaHorizontal(matrizToInt(3,5))){return true;}

    //Verifica quinta fila
    if(validaHorizontal(matrizToInt(4,0))){return true;}
    if(validaHorizontal(matrizToInt(4,1))){return true;}
    if(validaHorizontal(matrizToInt(4,2))){return true;}
    if(validaHorizontal(matrizToInt(4,3))){return true;}
    if(validaHorizontal(matrizToInt(4,4))){return true;}
    if(validaHorizontal(matrizToInt(4,5))){return true;}

    //Verifica sexta fila
    if(validaHorizontal(matrizToInt(5,0))){return true;}
    if(validaHorizontal(matrizToInt(5,1))){return true;}
    if(validaHorizontal(matrizToInt(5,2))){return true;}
    if(validaHorizontal(matrizToInt(5,3))){return true;}
    if(validaHorizontal(matrizToInt(5,4))){return true;}
    if(validaHorizontal(matrizToInt(5,5))){return true;}

    //Verifica setima fila
    if(validaHorizontal(matrizToInt(6,0))){return true;}
    if(validaHorizontal(matrizToInt(6,1))){return true;}
    if(validaHorizontal(matrizToInt(6,2))){return true;}
    if(validaHorizontal(matrizToInt(6,3))){return true;}
    if(validaHorizontal(matrizToInt(6,4))){return true;}
    if(validaHorizontal(matrizToInt(6,5))){return true;}

    //Verifica octava fila
    if(validaHorizontal(matrizToInt(7,0))){return true;}
    if(validaHorizontal(matrizToInt(7,1))){return true;}
    if(validaHorizontal(matrizToInt(7,2))){return true;}
    if(validaHorizontal(matrizToInt(7,3))){return true;}
    if(validaHorizontal(matrizToInt(7,4))){return true;}
    if(validaHorizontal(matrizToInt(7,5))){return true;}

    //Verifica novena fila
    if(validaHorizontal(matrizToInt(8,0))){return true;}
    if(validaHorizontal(matrizToInt(8,1))){return true;}
    if(validaHorizontal(matrizToInt(8,2))){return true;}
    if(validaHorizontal(matrizToInt(8,3))){return true;}
    if(validaHorizontal(matrizToInt(8,4))){return true;}
    if(validaHorizontal(matrizToInt(8,5))){return true;}

    //Verifica decima fila
    if(this->cartas->elements[matrizToInt(9,1)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(9,1)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(9,1)]->getFichaPuesta()== this->cartas->elements[matrizToInt(9,2)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(9,2)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(9,1)]->getFichaPuesta()== this->cartas->elements[matrizToInt(9,3)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(9,3)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(9,1)]->getFichaPuesta()== this->cartas->elements[matrizToInt(9,4)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(9,4)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(9,1)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(9,2)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(9,3)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(9,4)]->setPerteneceSecuencia(true);
        return true;
    }
    if(validaHorizontal(matrizToInt(9,2))){return true;}
    if(validaHorizontal(matrizToInt(9,3))){return true;}
    if(validaHorizontal(matrizToInt(9,4))){return true;}
    if(this->cartas->elements[matrizToInt(9,5)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(9,5)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(9,5)]->getFichaPuesta()== this->cartas->elements[matrizToInt(9,6)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(9,6)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(9,5)]->getFichaPuesta()== this->cartas->elements[matrizToInt(9,7)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(9,7)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(9,5)]->getFichaPuesta()== this->cartas->elements[matrizToInt(9,8)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(9,8)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(9,5)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(9,6)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(9,7)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(9,8)]->setPerteneceSecuencia(true);
        return true;
    }
    return false;
}

bool Controladora::verificarSecuenciaVertical()//Verifica si en el juego se creó una secuencia vertical
{
    //Verifica primera columna
    if(this->cartas->elements[matrizToInt(1,0)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(1,0)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,0)]->getFichaPuesta()== this->cartas->elements[matrizToInt(2,0)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(2,0)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,0)]->getFichaPuesta()== this->cartas->elements[matrizToInt(3,0)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(3,0)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,0)]->getFichaPuesta()== this->cartas->elements[matrizToInt(4,0)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(4,0)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(1,0)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(2,0)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(3,0)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(4,0)]->setPerteneceSecuencia(true);
        return true;
    }
    if(validaVertical(matrizToInt(2,0))){return true;}
    if(validaVertical(matrizToInt(3,0))){return true;}
    if(validaVertical(matrizToInt(4,0))){return true;}
    if(this->cartas->elements[matrizToInt(5,0)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(5,0)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,0)]->getFichaPuesta()== this->cartas->elements[matrizToInt(6,0)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(6,0)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,0)]->getFichaPuesta()== this->cartas->elements[matrizToInt(7,0)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(7,0)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,0)]->getFichaPuesta()== this->cartas->elements[matrizToInt(8,0)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(8,0)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(5,0)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(6,0)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(7,0)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(8,0)]->setPerteneceSecuencia(true);
        return true;
    }

    //Verifica segunda columna
    if(validaVertical(matrizToInt(0,1))){return true;}
    if(validaVertical(matrizToInt(1,1))){return true;}
    if(validaVertical(matrizToInt(2,1))){return true;}
    if(validaVertical(matrizToInt(3,1))){return true;}
    if(validaVertical(matrizToInt(4,1))){return true;}
    if(validaVertical(matrizToInt(5,1))){return true;}

    //Verifica tercera columna
    if(validaVertical(matrizToInt(0,2))){return true;}
    if(validaVertical(matrizToInt(1,2))){return true;}
    if(validaVertical(matrizToInt(2,2))){return true;}
    if(validaVertical(matrizToInt(3,2))){return true;}
    if(validaVertical(matrizToInt(4,2))){return true;}
    if(validaVertical(matrizToInt(5,2))){return true;}

    //Verifica cuarta columna
    if(validaVertical(matrizToInt(0,3))){return true;}
    if(validaVertical(matrizToInt(1,3))){return true;}
    if(validaVertical(matrizToInt(2,3))){return true;}
    if(validaVertical(matrizToInt(3,3))){return true;}
    if(validaVertical(matrizToInt(4,3))){return true;}
    if(validaVertical(matrizToInt(5,3))){return true;}

    //Verifica quinta columna
    if(validaVertical(matrizToInt(0,4))){return true;}
    if(validaVertical(matrizToInt(1,4))){return true;}
    if(validaVertical(matrizToInt(2,4))){return true;}
    if(validaVertical(matrizToInt(3,4))){return true;}
    if(validaVertical(matrizToInt(4,4))){return true;}
    if(validaVertical(matrizToInt(5,4))){return true;}

    //Verifica sexta columna
    if(validaVertical(matrizToInt(0,5))){return true;}
    if(validaVertical(matrizToInt(1,5))){return true;}
    if(validaVertical(matrizToInt(2,5))){return true;}
    if(validaVertical(matrizToInt(3,5))){return true;}
    if(validaVertical(matrizToInt(4,5))){return true;}
    if(validaVertical(matrizToInt(5,5))){return true;}

    //Verifica setima columna
    if(validaVertical(matrizToInt(0,6))){return true;}
    if(validaVertical(matrizToInt(1,6))){return true;}
    if(validaVertical(matrizToInt(2,6))){return true;}
    if(validaVertical(matrizToInt(3,6))){return true;}
    if(validaVertical(matrizToInt(4,6))){return true;}
    if(validaVertical(matrizToInt(5,6))){return true;}

    //Verifica octava columna
    if(validaVertical(matrizToInt(0,7))){return true;}
    if(validaVertical(matrizToInt(1,7))){return true;}
    if(validaVertical(matrizToInt(2,7))){return true;}
    if(validaVertical(matrizToInt(3,7))){return true;}
    if(validaVertical(matrizToInt(4,7))){return true;}
    if(validaVertical(matrizToInt(5,7))){return true;}

    //Verifica novena columna
    if(validaVertical(matrizToInt(0,8))){return true;}
    if(validaVertical(matrizToInt(1,8))){return true;}
    if(validaVertical(matrizToInt(2,8))){return true;}
    if(validaVertical(matrizToInt(3,8))){return true;}
    if(validaVertical(matrizToInt(4,8))){return true;}
    if(validaVertical(matrizToInt(5,8))){return true;}

    //Verifica decima columna
    if(this->cartas->elements[matrizToInt(1,9)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(1,9)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,9)]->getFichaPuesta()== this->cartas->elements[matrizToInt(2,9)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(2,9)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,9)]->getFichaPuesta()== this->cartas->elements[matrizToInt(3,9)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(3,9)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,9)]->getFichaPuesta()== this->cartas->elements[matrizToInt(4,9)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(4,9)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(1,9)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(2,9)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(3,9)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(4,9)]->setPerteneceSecuencia(true);
        return true;
    }
    if(validaVertical(matrizToInt(2,9))){return true;}
    if(validaVertical(matrizToInt(3,9))){return true;}
    if(validaVertical(matrizToInt(4,9))){return true;}
    if(this->cartas->elements[matrizToInt(5,9)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(5,9)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,9)]->getFichaPuesta()== this->cartas->elements[matrizToInt(6,9)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(6,9)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,9)]->getFichaPuesta()== this->cartas->elements[matrizToInt(7,9)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(7,9)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,9)]->getFichaPuesta()== this->cartas->elements[matrizToInt(8,9)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(8,9)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(5,9)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(6,9)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(7,9)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(8,9)]->setPerteneceSecuencia(true);
        return true;
    }
    return false;
}

bool Controladora::verificarSecuenciaDiagonal()//Verifica si en el juego se creó una secuencia diagonal
{
    //Valida las diagonales posibles en la primera fila
    if(this->cartas->elements[matrizToInt(1,1)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(1,1)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,1)]->getFichaPuesta()== this->cartas->elements[matrizToInt(2,2)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(2,2)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,1)]->getFichaPuesta()== this->cartas->elements[matrizToInt(3,3)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(3,3)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,1)]->getFichaPuesta()== this->cartas->elements[matrizToInt(4,4)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(4,4)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(1,1)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(2,2)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(3,3)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(4,4)]->setPerteneceSecuencia(true);
        return true;
    }
    if(validaDiagonalDerecha(matrizToInt(0,1))){return true;}
    if(validaDiagonalDerecha(matrizToInt(0,2))){return true;}
    if(validaDiagonalDerecha(matrizToInt(0,3))){return true;}
    if(validaDiagonalDerecha(matrizToInt(0,4))){return true;}
    if(validaDiagonalDerecha(matrizToInt(0,5))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(0,4))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(0,5))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(0,6))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(0,7))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(0,8))){return true;}
    if(this->cartas->elements[matrizToInt(1,8)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(1,8)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,8)]->getFichaPuesta()== this->cartas->elements[matrizToInt(2,7)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(2,7)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,8)]->getFichaPuesta()== this->cartas->elements[matrizToInt(3,6)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(3,6)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(1,8)]->getFichaPuesta()== this->cartas->elements[matrizToInt(4,5)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(4,5)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(1,8)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(2,7)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(3,6)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(4,5)]->setPerteneceSecuencia(true);
        return true;
    }

    //Valida las diagonales posibles en la segunda fila
    if(validaDiagonalDerecha(matrizToInt(1,0))){return true;}
    if(validaDiagonalDerecha(matrizToInt(1,1))){return true;}
    if(validaDiagonalDerecha(matrizToInt(1,2))){return true;}
    if(validaDiagonalDerecha(matrizToInt(1,3))){return true;}
    if(validaDiagonalDerecha(matrizToInt(1,4))){return true;}
    if(validaDiagonalDerecha(matrizToInt(1,5))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(1,4))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(1,5))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(1,6))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(1,7))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(1,8))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(1,9))){return true;}

    //Valida las diagonales posibles en la tercera fila
    if(validaDiagonalDerecha(matrizToInt(2,0))){return true;}
    if(validaDiagonalDerecha(matrizToInt(2,1))){return true;}
    if(validaDiagonalDerecha(matrizToInt(2,2))){return true;}
    if(validaDiagonalDerecha(matrizToInt(2,3))){return true;}
    if(validaDiagonalDerecha(matrizToInt(2,4))){return true;}
    if(validaDiagonalDerecha(matrizToInt(2,5))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(2,4))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(2,5))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(2,6))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(2,7))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(2,8))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(2,9))){return true;}

    //Valida las diagonales posibles en la cuarta fila
    if(validaDiagonalDerecha(matrizToInt(3,0))){return true;}
    if(validaDiagonalDerecha(matrizToInt(3,1))){return true;}
    if(validaDiagonalDerecha(matrizToInt(3,2))){return true;}
    if(validaDiagonalDerecha(matrizToInt(3,3))){return true;}
    if(validaDiagonalDerecha(matrizToInt(3,4))){return true;}
    if(validaDiagonalDerecha(matrizToInt(3,5))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(3,4))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(3,5))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(3,6))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(3,7))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(3,8))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(3,9))){return true;}

    //Valida las diagonales posibles en la quinta fila
    if(validaDiagonalDerecha(matrizToInt(4,0))){return true;}
    if(validaDiagonalDerecha(matrizToInt(4,1))){return true;}
    if(validaDiagonalDerecha(matrizToInt(4,2))){return true;}
    if(validaDiagonalDerecha(matrizToInt(4,3))){return true;}
    if(validaDiagonalDerecha(matrizToInt(4,4))){return true;}
    if(validaDiagonalDerecha(matrizToInt(4,5))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(4,4))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(4,5))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(4,6))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(4,7))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(4,8))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(4,9))){return true;}

    //Valida las diagonales posibles en la sexta fila
    if(validaDiagonalDerecha(matrizToInt(5,0))){return true;}
    if(validaDiagonalDerecha(matrizToInt(5,1))){return true;}
    if(validaDiagonalDerecha(matrizToInt(5,2))){return true;}
    if(validaDiagonalDerecha(matrizToInt(5,3))){return true;}
    if(validaDiagonalDerecha(matrizToInt(5,4))){return true;}
    if(this->cartas->elements[matrizToInt(5,5)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(5,5)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,5)]->getFichaPuesta()== this->cartas->elements[matrizToInt(6,6)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(6,6)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,5)]->getFichaPuesta()== this->cartas->elements[matrizToInt(7,7)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(7,7)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,5)]->getFichaPuesta()== this->cartas->elements[matrizToInt(8,8)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(8,8)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(5,5)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(6,6)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(7,7)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(8,8)]->setPerteneceSecuencia(true);
        return true;
    }
    if(this->cartas->elements[matrizToInt(5,4)]->getFichaPuesta()!=0 && this->cartas->elements[matrizToInt(5,4)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,4)]->getFichaPuesta()== this->cartas->elements[matrizToInt(6,3)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(6,3)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,4)]->getFichaPuesta()== this->cartas->elements[matrizToInt(7,2)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(7,2)]->getPerteneceSecuencia()==false
            && this->cartas->elements[matrizToInt(5,4)]->getFichaPuesta()== this->cartas->elements[matrizToInt(8,1)]->getFichaPuesta()
            && this->cartas->elements[matrizToInt(8,1)]->getPerteneceSecuencia()==false)
    {
        this->cartas->elements[matrizToInt(5,4)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(6,3)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(7,2)]->setPerteneceSecuencia(true);
        this->cartas->elements[matrizToInt(8,1)]->setPerteneceSecuencia(true);
        return true;
    }
    if(validaDiagonalIzquierda(matrizToInt(5,5))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(5,6))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(5,7))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(5,8))){return true;}
    if(validaDiagonalIzquierda(matrizToInt(5,9))){return true;}
    return false;
}
