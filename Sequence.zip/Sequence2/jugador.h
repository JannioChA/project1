#ifndef JUGADOR_H
#define JUGADOR_H
#include "arraylist.h"


class Jugador
{
public:
    Jugador();
    ArrayList<Carta*>* mano;
    int secuenciasArmadas;
};

#endif // JUGADOR_H
