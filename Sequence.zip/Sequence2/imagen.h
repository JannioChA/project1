#ifndef IMAGEN_H
#define IMAGEN_H

#include <QGraphicsPixmapItem>
#include <QObject>
#include <QDebug>
#include "controladora.h"

class Imagen: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:

    // caso 1, solo crearla
    Imagen(QString ruta_imagen);
    QString img;
};

#endif // IMAGEN_H
