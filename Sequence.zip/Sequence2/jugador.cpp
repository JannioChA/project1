#include "jugador.h"

Jugador::Jugador()
{
    this->mano = new ArrayList<Carta*>(7);
    this->secuenciasArmadas = 0;
}

